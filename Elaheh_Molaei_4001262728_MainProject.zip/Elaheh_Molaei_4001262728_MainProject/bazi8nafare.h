#ifndef BAZI8NAFARE_H
#define BAZI8NAFARE_H

#include <QWidget>

namespace Ui {
class bazi8nafare;
}

class bazi8nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi8nafare(QWidget *parent = nullptr);
    ~bazi8nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi8nafare *ui;
};

#endif // BAZI8NAFARE_H
