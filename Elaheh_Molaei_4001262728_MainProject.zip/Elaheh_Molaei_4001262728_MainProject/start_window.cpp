#include "start_window.h"
#include "ui_start_window.h"
#include "QComboBox"
#include "bazi2nafare.h"
#include "bazi3nafare.h"
#include "bazi4nafare.h"
#include "bazi5nafare.h"
#include "bazi6nafare.h"
#include "bazi7nafare.h"
#include "bazi8nafare.h"
start_window::start_window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::start_window)
{
    ui->setupUi(this);
    ui->comboBox->addItem("2نفره");
    ui->comboBox->addItem("3نفره");
    ui->comboBox->addItem("4نفره");
    ui->comboBox->addItem("5نفره");
    ui->comboBox->addItem("6نفره");
    ui->comboBox->addItem("7نفره");
    ui->comboBox->addItem("8نفره");

    connect(ui->comboBox,SIGNAL(activated(int)),this,SLOT(selected_how_many_players(int)));


}

start_window::~start_window()
{
    delete ui;
}

void start_window::selected_how_many_players(int index)
{
    switch (index)
    {
    case 0:
    {
        bazi2nafare *w = new bazi2nafare;
        w->setWindowTitle("بازی 2 نفره");
        w->resize(2210,1055);
        w->show();
    };break;//case 0 yani entekhb 0 ome oon combo box yni 2 nfre
    //////////////////////////////////////////////////////////////////
    case 1:
    {
        bazi3nafare *w = new bazi3nafare;
        w->setWindowTitle("بازی 3 نفره");
        w->show();
    };break;//case 1 yani entekhb 1 ome oon combo box yni 3 nfre
    /////////////////////////////////////////////////////////////////
    case 2:
    {
        bazi4nafare *w = new bazi4nafare;
        w->setWindowTitle("بازی 4 نفره");
        w->show();
    };break;//case 2 yani entekhb 2 ome oon combo box yni 4 nfre
    /////////////////////////////////////////////////////////////////
    case 3:
    {
        bazi5nafare *w = new bazi5nafare;
        w->setWindowTitle("بازی 5 نفره");
        w->show();
        };break;//case 3 yani entekhb 3 ome oon combo box yni 5 nfre
    /////////////////////////////////////////////////////////////////
    case 4:
    {
        bazi6nafare *w = new bazi6nafare;
        w->setWindowTitle("بازی 6 نفره");
        w->show();
    };break;//case 4 yani entekhb 4 ome oon combo box yni 6 nfre
    ////////////////////////////////////////////////////////////////
    case 5:
    {
        bazi7nafare *w = new bazi7nafare;
        w->setWindowTitle("بازی 7 نفره");
        w->show();
    };break;//case 5 yani entekhb 5 ome oon combo box yni 7 nfre
    ///////////////////////////////////////////////////////////////
    case 6:
    {
        bazi8nafare *w =new bazi8nafare;
        w->setWindowTitle("بازی 8 نفره");
        w->show();
    };break;//case 6 yani entekhb 6 ome oon combo box yni 8 nfre
    }
}
