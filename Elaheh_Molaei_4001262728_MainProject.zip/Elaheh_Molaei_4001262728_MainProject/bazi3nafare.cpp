#include "bazi3nafare.h"
#include "ui_bazi3nafare.h"
#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//#include "start_window.h"// bara inlke az class hash btoonm estfade knm

bazi3nafare::bazi3nafare(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bazi3nafare)
{
    ui->setupUi(this);
    QSqlDatabase database ;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\dbmonopoly.db");
    database.open();

}

bazi3nafare::~bazi3nafare()
{
    delete ui;
}

void bazi3nafare::on_pushButton_clicked()
{
    QSqlQuery q;//baraye ertebat ba database i k bala moarrefi krdm
    q.exec("SELECT * FROM bazi3nafare");//ghablan goftam kodom file hala migam hamechi az kodom tabele in file (*) :yani hamechi
    QSqlQueryModel *m = new QSqlQueryModel;
    m->setQuery(q);

    ui->tableView->setModel(m);
}
