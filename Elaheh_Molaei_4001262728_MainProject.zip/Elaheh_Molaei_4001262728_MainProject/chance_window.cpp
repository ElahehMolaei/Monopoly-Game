#include "chance_window.h"
#include "ui_chance_window.h"

#include "mainheader.h" // bara inlke az class hash btoonm estfade knm

#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//#include "ui_bazi2nafare.h"// bara inlke az pushbuttone tush estfde knm


chance_window::chance_window(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chance_window)
{
    ui->setupUi(this);

    QSqlDatabase database ;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\dbmonopoly.db");
    database.open();

    ui->lineEdit->setPlaceholderText("اگر بازیکن 1 هستید بنویسید 1 اگر بازیکن 2 هستید بنویسید 2 و رو دکمه ی زیر کلیک کنید");
}

chance_window::~chance_window()
{
    delete ui;
}






