#include "bazi6nafare.h"
#include "ui_bazi6nafare.h"
#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//#include "start_window.h"// bara inlke az class hash btoonm estfade knm
bazi6nafare::bazi6nafare(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bazi6nafare)
{
    ui->setupUi(this);
    QSqlDatabase database ;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\dbmonopoly.db");
    database.open();

}

bazi6nafare::~bazi6nafare()
{
    delete ui;
}

void bazi6nafare::on_pushButton_clicked()
{
    QSqlQuery q;//baraye ertebat ba database i k bala moarrefi krdm
    q.exec("SELECT * FROM bazi6nafare");//ghablan goftam kodom file hala migam hamechi az kodom tabele in file (*) :yani hamechi
    QSqlQueryModel *m = new QSqlQueryModel;
    m->setQuery(q);

    ui->tableView->setModel(m);
}
