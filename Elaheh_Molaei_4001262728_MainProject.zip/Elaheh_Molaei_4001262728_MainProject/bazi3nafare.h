#ifndef BAZI3NAFARE_H
#define BAZI3NAFARE_H

#include <QWidget>

namespace Ui {
class bazi3nafare;
}

class bazi3nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi3nafare(QWidget *parent = nullptr);
    ~bazi3nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi3nafare *ui;
};

#endif // BAZI3NAFARE_H
