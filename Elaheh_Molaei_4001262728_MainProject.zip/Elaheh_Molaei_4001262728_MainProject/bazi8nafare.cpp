#include "bazi8nafare.h"
#include "ui_bazi8nafare.h"
#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
//#include "start_window.h"// bara inlke az class hash btoonm estfade knm
bazi8nafare::bazi8nafare(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bazi8nafare)
{
    ui->setupUi(this);
    QSqlDatabase database ;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\dbmonopoly.db");
    database.open();

}

bazi8nafare::~bazi8nafare()
{
    delete ui;
}

void bazi8nafare::on_pushButton_clicked()
{
    QSqlQuery q;//baraye ertebat ba database i k bala moarrefi krdm
    q.exec("SELECT * FROM bazi8nafare");//ghablan goftam kodom file hala migam hamechi az kodom tabele in file (*) :yani hamechi
    QSqlQueryModel *m = new QSqlQueryModel;
    m->setQuery(q);

    ui->tableView->setModel(m);
}
