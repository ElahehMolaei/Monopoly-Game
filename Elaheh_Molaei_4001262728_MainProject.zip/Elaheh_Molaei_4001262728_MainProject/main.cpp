#include "start_window.h"
#include <QApplication>
#include "time.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    start_window w;
    w.show();
    srand(time(NULL));
    return a.exec();
}
