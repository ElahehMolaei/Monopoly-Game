#ifndef BAZI7NAFARE_H
#define BAZI7NAFARE_H

#include <QWidget>

namespace Ui {
class bazi7nafare;
}

class bazi7nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi7nafare(QWidget *parent = nullptr);
    ~bazi7nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi7nafare *ui;
};

#endif // BAZI7NAFARE_H
