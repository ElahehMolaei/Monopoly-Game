#ifndef MAINHEADER_H
#define MAINHEADER_H

#endif // MAINHEADER_H

#include "QString"
 ///////////////////////////////////////////////////////////////////////////////////

class cells{
public:

    //static int moneyp[8];//={1500,1500,1500,1500,1500,1500,1500,1500}; //moneyp[0]  pool haye player1 ro xakhire mikone
    QString player[8]={ "go", "go", "go", "go", "go", "go", "go", "go"};

    QString definecell[40]=
    {
        "go",  //cell[0]
        "mediterranean_avenue",//cell[1]
        "coummunity_Chest1",//cell[2]
        "Baltic_avenue",//cell[3]
        "income_tax",//cell[4]
        "reading_railroad",//cell[5]
        "oriental_avenue",//cell[6]
        "chance1",//cell[7]
        "vermont_avenue",//cell[8]
        "connecticut_avenue",//cell[9]
        "just_visiting_in_jail", //cell[10]->age az cell[30]biam be in cell, in cell, bayad beshe in jail!
        "st_charles_place_avenue",//cell[11]
        "electric_compony",//cell[12]
        "states_avenue",//cell[13]
        "virginia_avenue",//cell[14]
        "pennsylvania_railroad",//cell[15]
        "st_james_place_avenue",//cell[16]
        "coummunity_Chest2",//cell[17]
        "tennessee_avenue",//cell[18]
        "newyork_avenue",//cell[19]
        "free_parking",//cell[20]
        "kentucky_avenue",//cell[21]
        "chance2",//cell[22]
        "indiana_avenue",//cell[23]
        "illinois_avenue",//cell[24]
        "bo_railroad",//cell[25]
        "atlantic_avenue",//cell[26]
        "ventor_avenue",//cell[27]
        "water_works",//cell[28]
        "marvin_gardens_avenue",//cell[29]
        "go_to_jail",//cell[30]
        "pacific_avenue",//cell[31]
        "north_carolina_avenue",//cell[32]
        "coummunity_Chest3",//cell[33]
        "pennsylvania_avenue",//cell[34]
        "shortline_railroad",//cell[35]
        "chance3",//cell[36]
        "park_place_avenue",//cell[37]
        "luxury_tax",//cell[38]
        "boardwalk_avenue"//cell[39]
    };


    /*void f(QString c)
    {
        if(c==definecell[0])
        else if (c==definecell[1])
        else if (c==definecell[2])
        else if (c==definecell[3])
        else if (c==definecell[4])
        else if (c==definecell[5])
        else if (c==definecell[6])
        else if (c==definecell[7])
        else if (c==definecell[8])
        else if (c==definecell[9])
        else if (c==definecell[10])
        else if (c==definecell[11])
        else if (c==definecell[12])
        else if (c==definecell[13])
        else if (c==definecell[14])
        else if (c==definecell[15])
        else if (c==definecell[16])
        else if (c==definecell[17])
        else if (c==definecell[18])
        else if (c==definecell[19])
        else if (c==definecell[20])
        else if (c==definecell[21])
        else if (c==definecell[22])
        else if (c==definecell[23])
        else if (c==definecell[24])
        else if (c==definecell[25])
        else if (c==definecell[26])
        else if (c==definecell[27])
        else if (c==definecell[28])
        else if (c==definecell[29])
        else if (c==definecell[30])
        else if (c==definecell[31])
        else if (c==definecell[32])
        else if (c==definecell[33])
        else if (c==definecell[34])
        else if (c==definecell[35])
        else if (c==definecell[36])
        else if (c==definecell[37])
        else if (c==definecell[38])
        else if (c==definecell[39])

    }*/
    int find_x_mokhtasat(QString c)
    {
        if(c==definecell[0])            return  630;
        else if (c==definecell[1])      return  550;
        else if (c==definecell[2])      return  500;
        else if (c==definecell[3])      return  450;
        else if (c==definecell[4])      return  400;
        else if (c==definecell[5])      return  350;
        else if (c==definecell[6])      return  290;
        else if (c==definecell[7])      return  240;
        else if (c==definecell[8])      return  190;
        else if (c==definecell[9])      return  140;
        else if (c==definecell[10])     return  60;

        else if (c==definecell[11])     return  60;
        else if (c==definecell[12])     return  60;
        else if (c==definecell[13])     return  60;
        else if (c==definecell[14])     return  60;
        else if (c==definecell[15])     return  60;
        else if (c==definecell[16])     return  60;
        else if (c==definecell[17])     return  60;
        else if (c==definecell[18])     return  60;
        else if (c==definecell[19])     return  60;

        else if (c==definecell[20])     return  60;
        else if (c==definecell[21])     return  140;
        else if (c==definecell[22])     return  190;
        else if (c==definecell[23])     return  240;
        else if (c==definecell[24])     return  290;
        else if (c==definecell[25])     return  350;
        else if (c==definecell[26])     return  400;
        else if (c==definecell[27])     return  450;
        else if (c==definecell[28])     return  500;
        else if (c==definecell[29])     return  550;
        else if (c==definecell[30])     return  630;

        else if (c==definecell[31])     return  630;
        else if (c==definecell[32])     return  630;
        else if (c==definecell[33])     return  630;
        else if (c==definecell[34])     return  630;
        else if (c==definecell[35])     return  630;
        else if (c==definecell[36])     return  630;
        else if (c==definecell[37])     return  630;
        else if (c==definecell[38])     return  630;
        else if (c==definecell[39])     return  630;
    }
    int find_y_mokhtasat(QString c)
    {
        if(c==definecell[0])            return  660;
        else if (c==definecell[1])      return  660;
        else if (c==definecell[2])      return  660;
        else if (c==definecell[3])      return  660;
        else if (c==definecell[4])      return  660;
        else if (c==definecell[5])      return  660;
        else if (c==definecell[6])      return  660;
        else if (c==definecell[7])      return  660;
        else if (c==definecell[8])      return  660;
        else if (c==definecell[9])      return  660;
        else if (c==definecell[10])     return  660;

        else if (c==definecell[11])     return  580;
        else if (c==definecell[12])     return  530;
        else if (c==definecell[13])     return  480;
        else if (c==definecell[14])     return  430;
        else if (c==definecell[15])     return  370;
        else if (c==definecell[16])     return  320;
        else if (c==definecell[17])     return  270;
        else if (c==definecell[18])     return  220;
        else if (c==definecell[19])     return  160;

        else if (c==definecell[20])     return  80;
        else if (c==definecell[21])     return  80;
        else if (c==definecell[22])     return  80;
        else if (c==definecell[23])     return  80;
        else if (c==definecell[24])     return  80;
        else if (c==definecell[25])     return  80;
        else if (c==definecell[26])     return  80;
        else if (c==definecell[27])     return  80;
        else if (c==definecell[28])     return  80;
        else if (c==definecell[29])     return  80;
        else if (c==definecell[30])     return  80;

        else if (c==definecell[31])     return  160;
        else if (c==definecell[32])     return  220;
        else if (c==definecell[33])     return  270;
        else if (c==definecell[34])     return  320;
        else if (c==definecell[35])     return  370;
        else if (c==definecell[36])     return  430;
        else if (c==definecell[37])     return  480;
        else if (c==definecell[38])     return  530;
        else if (c==definecell[39])     return  580;
    }


};

 ///////////////////////////////////////////////////////////////////////////////////

class chances{
public:
    int chance[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    QString chance_url(int r)
    {
        //image: url(:/new/prefix1/mainchance10.jpeg);
        QString urll = "image: url(:/new/prefix1/mainchance" +QString::number(r) +".jpeg);";
        return (urll);
    }

};
 ///////////////////////////////////////////////////////////////////////////////////
class anjomanes{
public:
    int anjoman[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    QString anjoman_url(int r)
    {
        //image: url(:/new/prefix1/mainanjoman10.jpeg);
        QString urll = "image: url(:/new/prefix1/mainanjoman" +QString::number(r) +".jpeg);";
        return (urll);
    }
};
 ///////////////////////////////////////////////////////////////////////////////////












