#ifndef START_WINDOW_H
#define START_WINDOW_H

#include <QMainWindow>



namespace Ui {
class start_window;
}

class start_window : public QMainWindow
{
    Q_OBJECT

public:
    explicit start_window(QWidget *parent = nullptr);
    ~start_window();

public slots:
    void selected_how_many_players(int);


private:
    Ui::start_window *ui;
};

#endif // START_WINDOW_H
