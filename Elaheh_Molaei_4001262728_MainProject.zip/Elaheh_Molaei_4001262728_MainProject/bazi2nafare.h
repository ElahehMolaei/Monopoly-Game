#ifndef BAZI2NAFARE_H
#define BAZI2NAFARE_H

#include <QWidget>



namespace Ui {
class bazi2nafare;
}

class bazi2nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi2nafare(QWidget *parent = nullptr);
    ~bazi2nafare();
public slots:
    void emalechance(int r, int i);
    void emaleanjoman(int r,int i);
    void selectwhichincometaxp1(int index);
    void selectwhichincometaxp2(int index);
    void select_kharid_ya_mozayede_bargh_p1(int index);
    void select_kharid_ya_mozayede_bargh_p2(int index);
    void select_kharid_ya_mozayede_ab_p1(int index);
    void select_kharid_ya_mozayede_ab_p2(int index);
    void select_kharid_ya_mozayede_istgah_reading_p1(int index);
    void select_kharid_ya_mozayede_istgah_reading_p2(int index);
    void select_kharid_ya_mozayede_istgah_pensilvania_p1(int index);
    void select_kharid_ya_mozayede_istgah_pensilvania_p2(int index);
    void select_kharid_ya_mozayede_istgah_bando_p1(int index);
    void select_kharid_ya_mozayede_istgah_bando_p2(int index);
    void taqire_theme_bazi(int index);
    void select_kharid_ya_mozayede_istgah_shortline_p1(int index);
    void select_kharid_ya_mozayede_istgah_shortline_p2(int index);
    void select_kharid_ya_mozayede_khiaban_meditarane_p1(int index);
    void select_kharid_ya_mozayede_khiaban_meditarane_p2(int index);
    void select_kharid_ya_mozayede_khiaban_baltic_p1(int index);
    void select_kharid_ya_mozayede_khiaban_baltic_p2(int index);
    void khanesazi_p1(QString index);
    void khanesazi_p2(QString index);
    void select_kharid_ya_mozayede_qale_park_p1(int index);
    void select_kharid_ya_mozayede_qale_park_p2(int index);
    void select_kharid_ya_mozayede_khiaban_boardwalk_p1(int index);
    void select_kharid_ya_mozayede_khiaban_boardwalk_p2(int index);
    void select_kharid_ya_mozayede_khiaban_oriental_p1(int index);
    void select_kharid_ya_mozayede_khiaban_oriental_p2(int index);
    void select_kharid_ya_mozayede_khiaban_vermont_p1(int index);
    void select_kharid_ya_mozayede_khiaban_vermont_p2(int index);
    void select_kharid_ya_mozayede_khiaban_conecticut_p1(int index);
    void select_kharid_ya_mozayede_khiaban_conecticut_p2(int index);
    void select_kharid_ya_mozayede_qale_charls_p1(int index);
    void select_kharid_ya_mozayede_qale_charls_p2(int index);
    void select_kharid_ya_mozayede_khiaban_stats_p1(int index);
    void select_kharid_ya_mozayede_khiaban_stats_p2(int index);
    void select_kharid_ya_mozayede_khiaban_virginia_p1(int index);
    void select_kharid_ya_mozayede_khiaban_virginia_p2(int index);
    void select_kharid_ya_mozayede_qale_jims_p1(int index);
    void select_kharid_ya_mozayede_qale_jims_p2(int index);
    void select_kharid_ya_mozayede_khiaban_tenesi_p1(int index);
    void select_kharid_ya_mozayede_khiaban_tenesi_p2(int index);
    void select_kharid_ya_mozayede_khiaban_newyork_p1(int index);
    void select_kharid_ya_mozayede_khiaban_newyork_p2(int index);
    void select_kharid_ya_mozayede_khiaban_kentucky_p1(int index);
    void select_kharid_ya_mozayede_khiaban_kentucky_p2(int index);
    void select_kharid_ya_mozayede_khiaban_indiana_p1(int index);
    void select_kharid_ya_mozayede_khiaban_indiana_p2(int index);
    void select_kharid_ya_mozayede_khiaban_ilinois_p1(int index);
    void select_kharid_ya_mozayede_khiaban_ilinois_p2(int index);
    void select_kharid_ya_mozayede_khiaban_atlantic_p1(int index);
    void select_kharid_ya_mozayede_khiaban_atlantic_p2(int index);
    void select_kharid_ya_mozayede_khiaban_ventor_p1(int index);
    void select_kharid_ya_mozayede_khiaban_ventor_p2(int index);
    void select_kharid_ya_mozayede_khiaban_marvin_p1(int index);
    void select_kharid_ya_mozayede_khiaban_marvin_p2(int index);
    void select_kharid_ya_mozayede_khiaban_pasific_p1(int index);
    void select_kharid_ya_mozayede_khiaban_pacific_p2(int index);
    void select_kharid_ya_mozayede_khiaban_northcarolina_p1(int index);
    void select_kharid_ya_mozayede_khiaban_northcarolina_p2(int index);
    void select_kharid_ya_mozayede_khiaban_pensilvania_p1(int index);
    void select_kharid_ya_mozayede_khiaban_pensilvania_p2(int index);
    void hotelsazi_p1(QString index);
    void hotelsazi_p2(QString index);
    void see_sanad(int index);
    void khorojazzendan_p1(int index);
    void khorojazzendan_p2(int index);

private slots:


    void on_start_pushButton_clicked();

    void on_tasrizip1_pushButton_clicked();

    void on_tasrizip2_pushButton_clicked();
    void f(QString c, int j);

    void on_chance_pushButton_clicked();

    void on_anjoman_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_20_clicked();

    void on_pushButton_21_clicked();

    void on_pushButton_22_clicked();

    void on_pushButton_23_clicked();

    void on_pushButton_24_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_26_clicked();

    void on_pushButton_27_clicked();

    void on_pushButton_28_clicked();

    void on_pushButton_29_clicked();

    void on_pushButton_30_clicked();

    void on_pushButton_31_clicked();

    void on_pushButton_32_clicked();

private:
    Ui::bazi2nafare *ui;
};

#endif // BAZI2NAFARE_H
