#ifndef BAZI4NAFARE_H
#define BAZI4NAFARE_H

#include <QWidget>

namespace Ui {
class bazi4nafare;
}

class bazi4nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi4nafare(QWidget *parent = nullptr);
    ~bazi4nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi4nafare *ui;
};

#endif // BAZI4NAFARE_H
