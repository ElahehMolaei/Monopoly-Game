#ifndef BAZI6NAFARE_H
#define BAZI6NAFARE_H

#include <QWidget>

namespace Ui {
class bazi6nafare;
}

class bazi6nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi6nafare(QWidget *parent = nullptr);
    ~bazi6nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi6nafare *ui;
};

#endif // BAZI6NAFARE_H
