#include "bazi2nafare.h"
#include "ui_bazi2nafare.h"

/*#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
*/
#include "mainheader.h" // bara inlke az class hash btoonm estfade knm

#include "QMessageBox"

#include "QLineEdit"

#include "QGridLayout"
#include "QHBoxLayout"
#include "QVBoxLayout"

#include "QPixmap"
#include "QLabel"
#include "QMovie"
#include "QBitmap"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
cells ob1;
cells ob2;
int cel1 = 0;
int cel2 = 0;
int tasdoobl1=0;
int tasdoobl2=0;
int tedadbaretasrizip1 = 0;//bara khoroj az zendan
int tedadbaretasrizip2 = 0;//bara khoroj az zendan
int malek_sherkate_bargh=99;//99 yani dar avale bazi malek nadarad  100 yani malek drd
int name_maleke_bargh=-1;
int malek_sherkate_ab = 99;
int name_maleke_ab=-1;

int malek_istgah_reading = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_istgah_reading = -1 ;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe

int malek_istgah_pensilvania = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_istgah_pensilvania = -1 ;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe

int malek_istgah_bo = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_istgah_bo = -1 ;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe

int malek_istgah_shortline = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_istgah_shortline = -1 ;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe

int malek_khiaban_meditarane = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_meditarane = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_meditarane = 0;
int tedad_hotelhaye_meditarane = 0;

int malek_khiaban_baltic = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_baltic = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_baltic = 0;
int tedad_hotelhaye_baltic = 0;

int malek_qale_park = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_qale_park = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_qale_park = 0;
int tedad_hotelhaye_qale_park = 0;

int malek_khiaban_boardwalk = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_boardwalk = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_boardwalk = 0;
int tedad_hotelhaye_boardwalk = 0;

int malek_khiaban_oriental = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_oriental = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_oriental = 0;
int tedad_hotelhaye_oriental = 0;

int malek_khiaban_vermont = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_vermont = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_vermont = 0;
int tedad_hotelhaye_vermont = 0;

int malek_khiaban_conecticut = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_conecticut = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_conecticut = 0;
int tedad_hotelhaye_conecticut = 0;

int malek_qale_charls = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_qale_charls = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_qale_charls = 0;
int tedad_hotelhaye_qale_charls = 0;

int malek_khiaban_stats = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_stats = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_stats = 0;
int tedad_hotelhaye_stats = 0;

int malek_khiaban_virginia = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_virginia = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_virginia = 0;
int tedad_hotelhaye_virginia = 0;

int malek_qale_jims = 99;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_qale_jims = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_qale_jims = 0;
int tedad_hotelhaye_qale_jims = 0;

int malek_khiaban_tenesi = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_tenesi = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_tenesi = 0;
int tedad_hotelhaye_tenesi = 0;

int malek_khiaban_newyork = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_newyork = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_newyork = 0;
int tedad_hotelhaye_newyork = 0;

int malek_khiaban_kentucky = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_kentucky = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_kentucky = 0;
int tedad_hotelhaye_kentucky = 0;

int malek_khiaban_indiana = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_indiana = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_indiana = 0;
int tedad_hotelhaye_indiana = 0;

int malek_khiaban_ilinois = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_ilinois = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_ilinois = 0;
int tedad_hotelhaye_ilinois = 0;

int malek_khiaban_atlantic = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_atlantic = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_atlantic = 0;
int tedad_hotelhaye_atlantic = 0;

int malek_khiaban_ventor = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_ventor = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_ventor = 0;
int tedad_hotelhaye_ventor = 0;

int malek_khiaban_marvin = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_marvin = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_marvin = 0;
int tedad_hotelhaye_marvin = 0;

int malek_khiaban_pacific = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_pacific = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_pacific = 0;
int tedad_hotelhaye_pacific = 0;

int malek_khiaban_northcarolina = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_northcarolina = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_northcarolina = 0;
int tedad_hotelhaye_northcarolina = 0;

int malek_khiaban_pensilvania = 99 ;// 99 yani malek ndre dar shoroe bazi ..vaqti 100 beshe yani malek dre
int name_malek_khiaban_pensilvania = -1;//-1 yani kasi malekesh nis ...1 yani player 1 malekeshe o 2 yani bazikone 2 malekeshe
int tedad_khanehaye_pensilvania = 0;
int tedad_hotelhaye_pensilvania = 0;

int injail_p1 = -1; //yani player 1 dar zendan nist age 1 she yani hast
int injail_p2  = -1; // yani player 2 dar zendan nist age 2 she yani hast

int chancekhorojazzendanp1 = -1;// player 1 kart chance khoroj az zendan ndrd age 1 bshe yani dre
int chancekhorojazzendanp2 = -1;// player 2 kart chance khoroj az zendan ndrd age 2 bshe yani dre
int chestkhorojazzendanp1 = -1;// player 1 kart anjoman khoroj az zendan ndrd age 1 bshe yani dre
int chestkhorojazzendanp2 = -1;// player 2 kart anjoman khoroj az zendan ndrd age 2 bshe yani dre



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bazi2nafare::bazi2nafare(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bazi2nafare)
{
    ui->setupUi(this);

   /* QSqlDatabase database ;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\dbmonopoly.db");
    database.open();*/

    ui->groupBox_2->hide();
    ui->pushButton->hide();
    ui->mohrep1->hide();
    ui->mohrep2->hide();


    ui->lineEdit->setText("15000");
    ui->lineEdit_2->setText("15000");
    ui->lineEdit->setEnabled(false);
    ui->lineEdit_2->setEnabled(false);



    ui->groupBox_3->setEnabled(false);
    ui->groupBox_4->setEnabled(false);
    ui->groupBox_5->hide();
    ui->groupBox_6->hide();

    ui->groupBox_7->hide();
    ui->groupBox_8->hide();
    ui->groupBox_9->hide();

    ui->groupBox_10->hide();
    ui->groupBox_11->hide();
    ui->groupBox_12->hide();

    ui->groupBox_13->hide();
    ui->groupBox_14->hide();
    ui->groupBox_15->hide();

    ui->groupBox_16->hide();
    ui->groupBox_17->hide();
    ui->groupBox_18->hide();

    ui->groupBox_19->hide();
    ui->groupBox_20->hide();
    ui->groupBox_21->hide();

    ui->groupBox_23->hide();
    ui->groupBox_24->hide();
    ui->groupBox_25->hide();

    ui->groupBox_26->hide();
    ui->groupBox_27->hide();
    ui->groupBox_28->hide();

    ui->groupBox_29->hide();
    ui->groupBox_30->hide();
    ui->groupBox_31->hide();

    ui->groupBox_33->hide();
    ui->groupBox_34->hide();
    ui->groupBox_35->hide();

    ui->groupBox_36->hide();
    ui->groupBox_37->hide();
    ui->groupBox_38->hide();

    ui->groupBox_39->hide();
    ui->groupBox_40->hide();
    ui->groupBox_41->hide();

    ui->groupBox_42->hide();
    ui->groupBox_43->hide();
    ui->groupBox_44->hide();

    ui->groupBox_45->hide();
    ui->groupBox_46->hide();
    ui->groupBox_47->hide();

    ui->groupBox_48->hide();
    ui->groupBox_49->hide();
    ui->groupBox_50->hide();

    ui->groupBox_51->hide();
    ui->groupBox_52->hide();
    ui->groupBox_53->hide();

    ui->groupBox_54->hide();
    ui->groupBox_55->hide();
    ui->groupBox_56->hide();

    ui->groupBox_57->hide();
    ui->groupBox_58->hide();
    ui->groupBox_59->hide();


    ui->groupBox_60->hide();
    ui->groupBox_61->hide();
    ui->groupBox_62->hide();

    ui->groupBox_63->hide();
    ui->groupBox_64->hide();
    ui->groupBox_65->hide();

    ui->groupBox_66->hide();
    ui->groupBox_67->hide();
    ui->groupBox_68->hide();

    ui->groupBox_69->hide();
    ui->groupBox_70->hide();
    ui->groupBox_71->hide();

    ui->groupBox_72->hide();
    ui->groupBox_73->hide();
    ui->groupBox_74->hide();

    ui->groupBox_75->hide();
    ui->groupBox_76->hide();
    ui->groupBox_77->hide();

    ui->groupBox_78->hide();
    ui->groupBox_79->hide();
    ui->groupBox_80->hide();

    ui->groupBox_81->hide();
    ui->groupBox_82->hide();
    ui->groupBox_83->hide();

    ui->groupBox_84->hide();
    ui->groupBox_85->hide();
    ui->groupBox_86->hide();

    ui->groupBox_87->hide();
    ui->groupBox_88->hide();
    ui->groupBox_89->hide();

    ui->groupBox_90->hide();
    ui->groupBox_91->hide();
    ui->groupBox_92->hide();

    ui->groupBox_96->hide();
    ui->groupBox_97->hide();
    ui->groupBox_98->hide();
     ui->groupBox_99->hide();


    ui->lineEdit_3->setPlaceholderText("اگر بازیکن 1 هستید بنویسید 1 اگر 2 هستید بنویسید 2");
    ui->lineEdit_3->setValidator(new QIntValidator());//baraye inke faqat adad betoone bede!ya 1 ya 2 //faqat adad

    ui->lineEdit_4->setPlaceholderText("اگر بازیکن 1 هستید بنویسید 1 اگر 2 هستید بنویسید 2");
    ui->lineEdit_4->setValidator(new QIntValidator());//faqat adad

    ui->lineEdit_5->setValidator(new QIntValidator());//faqat adad
    ui->lineEdit_6->setValidator(new QIntValidator());//faghat adad

    ui->lineEdit_7->setValidator(new QIntValidator());//faqat adad
    ui->lineEdit_8->setValidator(new QIntValidator());//faghat adad

    ui->comboBox->addItem("200$میدهم");
    ui->comboBox->addItem("10% میدهم");

    ui->comboBox_2->addItem("200$میدهم");
    ui->comboBox_2->addItem("10% میدهم");

    ui->comboBox_3->addItem("میخواهم مالک شرکت برق بشم");
    ui->comboBox_3->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_4->addItem("میخواهم مالک شرکت برق بشم");
    ui->comboBox_4->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_5->addItem("میخواهم مالک شرکت آب بشم");
    ui->comboBox_5->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_6->addItem("میخواهم مالک شرکت آب بشم");
    ui->comboBox_6->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_7->addItem("می خواهم مالک ایستگاه ردینگ بشم");
    ui->comboBox_7->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_8->addItem("می خواهم مالک ایستگاه ردینگ بشم");
    ui->comboBox_8->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_9->addItem("می خواهم مالک ایستگاه پنسیلوانیا بشم");
    ui->comboBox_9->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_10->addItem("می خواهم مالک ایستگاه پنسیلوانیا بشم");
    ui->comboBox_10->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_11->addItem("می خواهم مالک ایستگاه بی اند او بشم");
    ui->comboBox_11->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_12->addItem("می خواهم مالک ایستگاه بی اند او بشم");
    ui->comboBox_12->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_14->addItem("می خواهم مالک ایستگاه شورت لاین بشم");
    ui->comboBox_14->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_15->addItem("می خواهم مالک ایستگاه شورت لاین بشم");
    ui->comboBox_15->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_16->addItem("می خواهم مالک خیابان مدیترانه بشم");
    ui->comboBox_16->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_17->addItem("می خواهم مالک خیابان مدیترانه بشم");
    ui->comboBox_17->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_18->addItem("می خواهم مالک خیابان بالتیک بشم");
    ui->comboBox_18->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_19->addItem("می خواهم مالک خیابان بالتیک بشم");
    ui->comboBox_19->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_23->addItem("می خواهم مالک قلعه پارک بشم");
    ui->comboBox_23->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_24->addItem("می خواهم مالک قلعه پارک بشم");
    ui->comboBox_24->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_25->addItem("می خواهم مالک خیابان بوردواک بشم");
    ui->comboBox_25->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_26->addItem("می خواهم مالک خیابان بوردواک بشم");
    ui->comboBox_26->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_27->addItem("می خواهم مالک خیابان اورینتال بشم");
    ui->comboBox_27->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_28->addItem("می خواهم مالک خیابان اورینتال بشم");
    ui->comboBox_28->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_29->addItem("می خواهم مالک خیابان ورمونت بشم");
    ui->comboBox_29->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_30->addItem("می خواهم مالک خیابان ورمونت بشم");
    ui->comboBox_30->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_31->addItem("می خواهم مالک خیابان کانکتیکات بشم");
    ui->comboBox_31->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_32->addItem("می خواهم مالک خیابان کانکتیکات بشم");
    ui->comboBox_32->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_33->addItem("می خواهم مالک قلعه چارلز بشم");
    ui->comboBox_33->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_34->addItem("می خواهم مالک قلعه چارلز بشم");
    ui->comboBox_34->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_35->addItem("می خواهم مالک خیابان استیتس بشم");
    ui->comboBox_35->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_36->addItem("می خواهم مالک خیابان استیتس بشم");
    ui->comboBox_36->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_37->addItem("می خواهم مالک خیابان ویرجینیا بشم");
    ui->comboBox_37->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_38->addItem("می خواهم مالک خیابان ویرجینیا بشم");
    ui->comboBox_38->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_39->addItem("می خواهم مالک قلعه جیمز بشم");
    ui->comboBox_39->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_40->addItem("می خواهم مالک قلعه جیمز بشم");
    ui->comboBox_40->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_41->addItem("می خواهم مالک خیابان تنسی بشم");
    ui->comboBox_41->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_42->addItem("می خواهم مالک خیابان تنسی بشم");
    ui->comboBox_42->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_43->addItem("می خواهم مالک خیابان نیویورک بشم");
    ui->comboBox_43->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_44->addItem("می خواهم مالک خیابان نیویورک بشم");
    ui->comboBox_44->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_45->addItem("می خواهم مالک خیابان کنتاکی بشم");
    ui->comboBox_45->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_46->addItem("می خواهم مالک خیابان کنتاکی بشم");
    ui->comboBox_46->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_47->addItem("می خواهم مالک خیابان ایندیانا بشم");
    ui->comboBox_47->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_48->addItem("می خواهم مالک خیابان ایندیانا بشم");
    ui->comboBox_48->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_49->addItem("می خواهم مالک خیابان ایلی نویز بشم");
    ui->comboBox_49->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_50->addItem("می خواهم مالک خیابان ایلی نویز بشم");
    ui->comboBox_50->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_51->addItem("می خواهم مالک خیابان آتلانتیک بشم");
    ui->comboBox_51->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_52->addItem("می خواهم مالک خیابان آتلانتیک بشم");
    ui->comboBox_52->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_53->addItem("می خواهم مالک خیابان ونتور بشم");
    ui->comboBox_53->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_54->addItem("می خواهم مالک خیابان ونتور بشم");
    ui->comboBox_54->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_55->addItem("می خواهم مالک باغ ماروین بشم");
    ui->comboBox_55->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_56->addItem("می خواهم مالک باغ ماروین بشم");
    ui->comboBox_56->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_57->addItem("می خواهم مالک خیابان پاسیفیک بشم");
    ui->comboBox_57->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_58->addItem("می خواهم مالک خیابان پاسیفیک بشم");
    ui->comboBox_58->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_59->addItem("می خواهم مالک خیابان کارولینای شمالی بشم");
    ui->comboBox_59->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_60->addItem("می خواهم مالک خیابان کارولینای شمالی بشم");
    ui->comboBox_60->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_61->addItem("می خواهم مالک خیابان پنسیلوانیا بشم");
    ui->comboBox_61->addItem("بانک لطفا آن را به مزایده بگذار");

    ui->comboBox_62->addItem("می خواهم مالک خیابان پنسیلوانیا بشم");
    ui->comboBox_62->addItem("بانک لطفا آن را به مزایده بگذار");



    ui->comboBox_13->addItem("خاکستری");
    ui->comboBox_13->addItem("سرخابی");
    ui->comboBox_13->addItem("قهوه ای");
    ui->comboBox_13->addItem("سبز");
    ui->comboBox_13->addItem("بنفش");
    ui->comboBox_13->addItem("سبز خاص");
    ui->comboBox_13->addItem("صورتی");
    ui->comboBox_13->addItem("نارنجی");
    ui->comboBox_13->addItem("زرد");
    ui->comboBox_13->addItem("آبی");
    ui->comboBox_13->addItem("پیش فرض");

    //asnad :

    ui->comboBox_65->addItem("شرکت برق");
    ui->comboBox_65->addItem("شرکت آب");
    ui->comboBox_65->addItem("ایستگاه ردینگ");
    ui->comboBox_65->addItem("ایستگاه پنسیلوانیا");
    ui->comboBox_65->addItem("ایستگاه بی اند او");
    ui->comboBox_65->addItem("ایستگاه شورت لاین");
    ui->comboBox_65->addItem("خیابان مدیترانه");
    ui->comboBox_65->addItem("خیابان بالتیک");
    ui->comboBox_65->addItem("قلعه پارک");
    ui->comboBox_65->addItem("خیابان بوردواک");
    ui->comboBox_65->addItem("خیابان اورینتال");
    ui->comboBox_65->addItem("خیابان ورمونت");
    ui->comboBox_65->addItem("خیابان کانکتیکات");
    ui->comboBox_65->addItem("قلعه چارلز");
    ui->comboBox_65->addItem("خیابان استیتس");
    ui->comboBox_65->addItem("خیابان ویرجینیا");
    ui->comboBox_65->addItem("قلعه جیمز");
    ui->comboBox_65->addItem("خیابان تنسی");
    ui->comboBox_65->addItem("خیابان نیویورک");
    ui->comboBox_65->addItem("خیابان کنتاکی");
    ui->comboBox_65->addItem("خیابان ایندیانا");
    ui->comboBox_65->addItem("خیابان ایلی نویز");
    ui->comboBox_65->addItem("خیابان ونتور");
    ui->comboBox_65->addItem("باغ ماروین");
    ui->comboBox_65->addItem("خیابان پاسیفیک");
    ui->comboBox_65->addItem("خیابان کارلینای شمالی");
    ui->comboBox_65->addItem("خیابان پنسیلوانیا");
    ui->comboBox_65->addItem("خیابان آتلانتیک");


    ui->comboBox_66->addItem("پنجاه دلار می پردازم");
    ui->comboBox_66->addItem("از کارت شانس خروج از زندانم استفاده می کنم");
    ui->comboBox_66->addItem("از کارت انجمن خروج از زندانم استفاده می کنم");
    ui->comboBox_66->addItem("می خواهم تاس بریزم");

    ui->comboBox_67->addItem("پنجاه دلار می پردازم");
    ui->comboBox_67->addItem("از کارت شانس خروج از زندانم استفاده می کنم");
    ui->comboBox_67->addItem("از کارت انجمن خروج از زندانم استفاده می کنم");
    ui->comboBox_67->addItem("می خواهم تاس بریزم");






    ui->label_11->hide();
    ui->label_12->hide();
    ui->label_13->hide();
    ui->label_16->hide();
    ui->label_17->hide();
    ui->label_18->hide();
    ui->label_19->hide();
    ui->label_22->hide();
    ui->label_25->hide();
    ui->label_27->hide();
    ui->label_26->hide();
    ui->label_30->hide();
    ui->label_33->hide();
    ui->label_34->hide();
    ui->label_38->hide();
    ui->label_39->hide();
    ui->label_42->hide();
    ui->label_43->hide();
    ui->label_51->hide();
    ui->label_52->hide();
    ui->label_55->hide();
    ui->label_56->hide();
    ui->label_63->hide();
    ui->label_64->hide();
    ui->label_69->hide();
    ui->label_70->hide();
    ui->label_75->hide();
    ui->label_76->hide();
    ui->label_81->hide();
    ui->label_82->hide();
    ui->label_87->hide();
    ui->label_88->hide();
    ui->label_93->hide();
    ui->label_94->hide();
    ui->label_99->hide();
    ui->label_100->hide();
    ui->label_105->hide();
    ui->label_106->hide();
    ui->label_111->hide();
    ui->label_112->hide();
    ui->label_117->hide();
    ui->label_118->hide();
    ui->label_123->hide();
    ui->label_124->hide();
    ui->label_129->hide();
    ui->label_130->hide();
    ui->label_135->hide();
    ui->label_136->hide();
    ui->label_141->hide();
    ui->label_142->hide();
    ui->label_147->hide();
    ui->label_148->hide();
    ui->label_153->hide();
    ui->label_154->hide();
    ui->label_159->hide();
    ui->label_160->hide();
    ui->label_165->hide();
    ui->label_166->hide();

    connect(ui->comboBox,SIGNAL(activated(int)),this,SLOT(selectwhichincometaxp1(int)));
    connect(ui->comboBox_2,SIGNAL(activated(int)),this,SLOT(selectwhichincometaxp2(int)));

    connect(ui->comboBox_3,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_bargh_p1(int)));
    connect(ui->comboBox_4,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_bargh_p2(int)));

    connect(ui->comboBox_5,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_ab_p1(int)));
    connect(ui->comboBox_6,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_ab_p2(int)));

    connect(ui->comboBox_7,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_reading_p1(int)));
    connect(ui->comboBox_8,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_reading_p2(int)));

    connect(ui->comboBox_9,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_pensilvania_p1(int)));
    connect(ui->comboBox_10,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_pensilvania_p2(int)));

    connect(ui->comboBox_11,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_bando_p1(int)));
    connect(ui->comboBox_12,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_bando_p2(int)));

    connect(ui->comboBox_13,SIGNAL(activated(int)),this,SLOT(taqire_theme_bazi(int)));

    connect(ui->comboBox_14,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_shortline_p1(int)));
    connect(ui->comboBox_15,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_istgah_shortline_p2(int)));

    connect(ui->comboBox_16,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_meditarane_p1(int)));
    connect(ui->comboBox_17,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_meditarane_p2(int)));

    connect(ui->comboBox_18,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_baltic_p1(int)));
    connect(ui->comboBox_19,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_baltic_p2(int)));

    connect(ui->comboBox_20,SIGNAL(activated(QString)),this,SLOT(khanesazi_p1(QString)));
    connect(ui->comboBox_21,SIGNAL(activated(QString)),this,SLOT(khanesazi_p2(QString)));

    connect(ui->comboBox_23,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_park_p1(int)));
    connect(ui->comboBox_24,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_park_p2(int)));

    connect(ui->comboBox_25,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_boardwalk_p1(int)));
    connect(ui->comboBox_26,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_boardwalk_p2(int)));

    connect(ui->comboBox_27,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_oriental_p1(int)));
    connect(ui->comboBox_28,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_oriental_p2(int)));

    connect(ui->comboBox_29,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_vermont_p1(int)));
    connect(ui->comboBox_30,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_vermont_p2(int)));

    connect(ui->comboBox_31,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_conecticut_p1(int)));
    connect(ui->comboBox_32,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_conecticut_p2(int)));

    connect(ui->comboBox_33,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_charls_p1(int)));
    connect(ui->comboBox_34,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_charls_p2(int)));

    connect(ui->comboBox_35,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_stats_p1(int)));
    connect(ui->comboBox_36,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_stats_p2(int)));

    connect(ui->comboBox_37,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_virginia_p1(int)));
    connect(ui->comboBox_38,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_virginia_p2(int)));

    connect(ui->comboBox_39,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_jims_p1(int)));
    connect(ui->comboBox_40,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_qale_jims_p2(int)));

    connect(ui->comboBox_41,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_tenesi_p1(int)));
    connect(ui->comboBox_42,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_tenesi_p2(int)));

    connect(ui->comboBox_43,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_newyork_p1(int)));
    connect(ui->comboBox_44,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_newyork_p2(int)));

    connect(ui->comboBox_45,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_kentucky_p1(int)));
    connect(ui->comboBox_46,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_kentucky_p2(int)));

    connect(ui->comboBox_47,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_indiana_p1(int)));
    connect(ui->comboBox_48,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_indiana_p2(int)));

    connect(ui->comboBox_49,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_ilinois_p1(int)));
    connect(ui->comboBox_50,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_ilinois_p2(int)));

    connect(ui->comboBox_51,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_atlantic_p1(int)));
    connect(ui->comboBox_52,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_atlantic_p2(int)));

    connect(ui->comboBox_53,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_ventor_p1(int)));
    connect(ui->comboBox_54,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_ventor_p2(int)));

    connect(ui->comboBox_55,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_marvin_p1(int)));
    connect(ui->comboBox_56,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_marvin_p2(int)));

    connect(ui->comboBox_57,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_pasific_p1(int)));
    connect(ui->comboBox_58,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_pasific_p2(int)));

    connect(ui->comboBox_59,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_northcarolina_p1(int)));
    connect(ui->comboBox_60,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_northcarolina_p2(int)));

    connect(ui->comboBox_61,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_pensilvania_p1(int)));
    connect(ui->comboBox_62,SIGNAL(activated(int)),this,SLOT(select_kharid_ya_mozayede_khiaban_pensilvania_p2(int)));

    connect(ui->comboBox_63,SIGNAL(activated(QString)),this,SLOT(hotelsazi_p1(QString)));
    connect(ui->comboBox_64,SIGNAL(activated(QString)),this,SLOT(hotelsazi_p2(QString)));

     connect(ui->comboBox_65,SIGNAL(activated(int)),this,SLOT(see_sanad(int)));

     connect(ui->comboBox_66,SIGNAL(activated(int)),this,SLOT(khorojazzendan_p1(int)));
     connect(ui->comboBox_67,SIGNAL(activated(int)),this,SLOT(khorojazzendan_p2(int)));


    /* QMovie *movie = new QMovie("monopoly.gif");
     ui->label_230->setMovie(movie);
     movie->start();*/


}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bazi2nafare::~bazi2nafare()
{
    delete ui;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::emalechance(int r, int i)
{
    double moneyp1 , moneyp2;
   cells ob;
    if(i==1)
    {
        if(r==0)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=50;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==1)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=50;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==2)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=200;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==3)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=100;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==4)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=100;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==5)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=200;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==6)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=50;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==7)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=500;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==8)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=300;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==9)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=300;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==10)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=150;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        //******************************
       else if(r==11)
        {
            QMessageBox::information(this,"شانس","بازیکن 1 شما کارت شانس خروج از زندان را گرفتید ");
            chancekhorojazzendanp1=1;
            ui->label_218->setText("دارد");
        }
        //******************************
        else if(r==12)
        {
            ui->mohrep1->move(60,660);//bere be zendan
            ob.player[0] = ob.definecell[10];
            cel1=10;
            injail_p1=1;// yani in jail hast va na just visiting!
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
        }
        else if(r==13)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=30;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==14)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=100;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==15)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=70;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
    }

    else if(i==2)
    {
        if(r==0)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=50;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==1)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=50;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==2)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==3)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=100;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==4)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=100;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==5)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==6)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=50;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==7)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=500;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==8)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=300;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==9)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=300;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==10)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=150;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        //******************************
        else if(r==11)
        {
            QMessageBox::information(this,"شانس","بازیکن 2 شما کارت شانس خروج از زندان را گرفتید ");
            chancekhorojazzendanp2=2;
            ui->label_219->setText("دارد");

        }
        //******************************
        else if(r==12)
        {
            ui->mohrep2->move(60,660);//bere be zendan
            ob.player[1] = ob.definecell[1];
            cel2=10;
            injail_p2=2;
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
        }
        else if(r==13)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=30;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==14)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=100;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==15)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=70;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
    }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::emaleanjoman(int r, int i)
{
    double moneyp1 , moneyp2;
    cells ob;
    if(i==1)
    {
        if(r==0)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=300;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==1)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=50;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==2)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=500;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==3)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=100;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==4)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=115;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==5)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=30;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==6)
        {
            ui->mohrep1->move(630,660);
            //ob.player[0] = ob.definecell[0];//bere be go
            cel1=0;
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=200;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==7)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=10;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==8)
        {
            ui->mohrep1->move(60,660);//bere be zendan
            ob.player[0] = ob.definecell[10];
            cel1=10;
            injail_p1=1;
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
        }
        else if(r==9)
        {
            QMessageBox::information(this,"شانس","بازیکن 1 شما کارت انجمن خروج از زندان را گرفتید ");
            chestkhorojazzendanp1=1;
            ui->label_224->setText("دارد");

        }
        else if(r==10)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=70;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==11)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=500;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==12)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=100;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==13)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=150;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==14)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=300;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(r==15)
        {
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=10;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
    }
    else if(i==2)
    {
        if(r==0)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=300;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==1)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=50;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==2)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=500;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==3)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=100;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==4)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=115;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==5)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=30;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==6)
        {
            ui->mohrep2->move(630,660);
            //ob.player[1] = ob.definecell[0];//bere be go
            cel2=0;
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==7)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=10;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==8)
        {
            ui->mohrep2->move(60,660);//bere be zendan
            ob.player[1] = ob.definecell[10];
            cel2=10;
            injail_p2=2;
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
        }
        else if(r==9)
        {
            QMessageBox::information(this,"شانس","بازیکن 2 شما کارت انجمن خروج از زندان را گرفتید ");
            chestkhorojazzendanp2=2;
            ui->label_225->setText("دارد");

        }
        else if(r==10)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=70;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==11)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=500;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==12)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=100;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==13)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=150;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==14)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=300;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
        else if(r==15)
        {
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=10;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::selectwhichincometaxp1(int index)
{
    double moneyp1;
    switch (index)
    {
        case 0:
        {
           moneyp1=ui->lineEdit->text().toInt();
           moneyp1-=200;
           ui->lineEdit->setText(QString::number(moneyp1));

        }break;
        case 1:
        {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=(moneyp1*0.1);
        ui->lineEdit->setText(QString::number(moneyp1));
        }break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::selectwhichincometaxp2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=200;
        ui->lineEdit_2->setText(QString::number(moneyp2));
    }break;
    case 1:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=(moneyp2*0.1);
        ui->lineEdit_2->setText(QString::number(moneyp2));
    }break;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_bargh_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=150;//gheymate kharide shrkate bargh
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_sherkate_bargh=100;
        name_maleke_bargh=1;
        ui->label_11->show();
    }break;
    case 1:
    {
        QMessageBox::information(this,"مزایده","بازیکن یک  شرکت برق را که مالک نداشت  را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت  پیشنهادی خود را وارد کند!");
        ui->groupBox_9->show();

    }break;

    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_bargh_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=150;//gheymate kharide shrkate bargh
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_sherkate_bargh=100;
        name_maleke_bargh=2;
        ui->label_12->show();
    }break;
    case 1:
    {
        QMessageBox::information(this,"مزایده","بازیکن دو  شرکت برق را که مالک نداشت  را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت  پیشنهادی خود را وارد کند!");
        ui->groupBox_9->show();
    }break;

    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_ab_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=150;//gheymate kharide shrkate bargh
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_sherkate_ab=100;
        name_maleke_ab=1;
        ui->label_17->show();
    }break;
    case 1:
    {
        QMessageBox::information(this,"مزایده","بازیکن یک  شرکت آب را که مالک نداشت  را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت  پیشنهادی خود را وارد کند!");
        ui->groupBox_12->show();

    }break;

    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_ab_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=150;//gheymate kharide shrkate bargh
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_sherkate_ab=100;
        name_maleke_ab=2;
        ui->label_18->show();
    }break;
    case 1:
    {
        QMessageBox::information(this,"مزایده","بازیکن دو  شرکت آب را که مالک نداشت  را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت  پیشنهادی خود را وارد کند!");
        ui->groupBox_12->show();
    }break;

    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_reading_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=200;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_reading=100;
        name_malek_istgah_reading=1;
        ui->label_19->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 ایستگاه ردینگ را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_15->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_reading_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=200;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_reading=100;
        name_malek_istgah_reading=2;
        ui->label_22->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 ایستگاه ردینگ را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_15->show();
    } break;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_pensilvania_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=200;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_pensilvania=100;
        name_malek_istgah_pensilvania=1;
        ui->label_25->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 ایستگاه پنسیلوانیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_18->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_pensilvania_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=200;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_pensilvania=100;
        name_malek_istgah_pensilvania=2;
        ui->label_27->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 ایستگاه پنسیلوانیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_18->show();
    } break;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_bando_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=200;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_bo=100;
        name_malek_istgah_bo=1;
        ui->label_26->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 ایستگاه بی اند او را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_21->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::select_kharid_ya_mozayede_istgah_bando_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=200;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_bo=100;
        name_malek_istgah_bo=2;
        ui->label_30->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 ایستگاه بی اند او را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_21->show();
    } break;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::select_kharid_ya_mozayede_istgah_shortline_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=200;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_shortline=100;
        name_malek_istgah_shortline=1;
        ui->label_33->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 ایستگاه شورت لاین را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_25->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_istgah_shortline_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=200;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_shortline=100;
        name_malek_istgah_shortline=2;
        ui->label_34->show();
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 ایستگاه شورت لاین را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_25->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_meditarane_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=60;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_meditarane=100;
        name_malek_khiaban_meditarane=1;
        ui->label_38->show();
        ui->comboBox_20->addItem("خیابان مدیترانه");
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان مدیترانه را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_28->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_meditarane_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=60;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_meditarane=100;
        name_malek_khiaban_meditarane=2;
        ui->label_39->show();
        ui->comboBox_21->addItem("خیابان مدیترانه");
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان مدیترانه را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_28->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_baltic_p1(int index)
{
    double moneyp1;
    switch (index)
    {
    case 0:
    {
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=60;//gheymate kharide istgah reading
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_baltic=100;
        name_malek_khiaban_baltic=1;
        ui->label_42->show();
        ui->comboBox_20->addItem("خیابان بالتیک");
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان بالتیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_31->show();
    } break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_baltic_p2(int index)
{
    double moneyp2;
    switch (index)
    {
    case 0:
    {
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=60;//gheymate kharide istgah reading
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_baltic=100;
        name_malek_khiaban_baltic=2;
        ui->label_43->show();
        ui->comboBox_21->addItem("خیابان بالتیک");
    } break;
    case 1:
    {
        QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان بالتیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
        ui->groupBox_31->show();
    } break;
    }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::khanesazi_p1(QString index)
{
    double moneyp1;
    if(index=="خیابان مدیترانه")
    {
        if(name_malek_khiaban_baltic==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre
            if(tedad_khanehaye_meditarane==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_meditarane<4)
            {

                if(tedad_khanehaye_meditarane==0)
                {
                    if(tedad_khanehaye_baltic==0||tedad_khanehaye_baltic==1)
                    {
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=10;
                        ui->lineEdit->setText(QString::number(moneyp1));
                        tedad_khanehaye_meditarane=1;
                        ui->label_48->setText(QString::number(1));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==1)
                {
                    if(tedad_khanehaye_baltic==1||tedad_khanehaye_baltic==2)
                    {
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=20;
                        ui->lineEdit->setText(QString::number(moneyp1));
                        tedad_khanehaye_meditarane=2;
                        ui->label_48->setText(QString::number(2));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==2)
                {
                    if(tedad_khanehaye_baltic==2||tedad_khanehaye_baltic==3)
                    {
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=60;
                        ui->lineEdit->setText(QString::number(moneyp1));
                        tedad_khanehaye_meditarane=3;
                        ui->label_48->setText(QString::number(3));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==3)
                {
                    if(tedad_khanehaye_baltic==3||tedad_khanehaye_baltic==4)
                    {
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=70;
                        ui->lineEdit->setText(QString::number(moneyp1));
                        tedad_khanehaye_meditarane=4;
                        ui->label_48->setText(QString::number(4));
                        ui->comboBox_63->addItem("خیابان مدیترانه");
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
            }
        }
        else if(name_malek_khiaban_baltic!=1)
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید مالک خیابان بالتیک هم باشید و به اصطلاح انحصار رنگ قهوه ای را داشته باشید تا بتوانید در مدیترانه یا بالتیک خانه بسازید لطفا بعد از خرید بالتیک تلاش کنید");
        }
    }
    /////
    else if(index=="خیابان بالتیک")
    {
        if(name_malek_khiaban_meditarane==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_baltic==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_baltic<4)
            {
               if(tedad_khanehaye_baltic==0)
               {
                   if(tedad_khanehaye_meditarane==0 || tedad_khanehaye_meditarane==1)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=20;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_baltic=1;
                       ui->label_50->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_baltic==1)
               {
                   if(tedad_khanehaye_meditarane==1 || tedad_khanehaye_meditarane==2)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=40;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_baltic=2;
                       ui->label_50->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_baltic==2)
               {
                   if(tedad_khanehaye_meditarane==2||tedad_khanehaye_meditarane==3)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=120;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_baltic=3;
                       ui->label_50->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_baltic==3)
               {
                   if(tedad_khanehaye_meditarane==3||tedad_khanehaye_meditarane==4)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=180;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_baltic=4;
                       ui->label_50->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان بالتیک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else if(name_malek_khiaban_meditarane!=1)
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید مالک خیابان مدیترانه هم باشید و به اصطلاح انحصار رنگ قهوه ای را داشته باشید تا بتوانید در مدیترانه یا بالتیک خانه بسازید لطفا بعد از خرید مدیترانه تلاش کنید");
        }
    }
    else if(index=="قلعه پارک")
    {
        if(name_malek_khiaban_boardwalk==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_park==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_park<4)
            {
               if(tedad_khanehaye_qale_park==0)
               {
                   if(tedad_khanehaye_boardwalk==0 || tedad_khanehaye_boardwalk==1)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_park=1;
                       ui->label_60->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==1)
               {
                   if(tedad_khanehaye_boardwalk==1 || tedad_khanehaye_boardwalk==2)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=325;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_park=2;
                       ui->label_60->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==2)
               {
                   if(tedad_khanehaye_boardwalk==2||tedad_khanehaye_boardwalk==3)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=600;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_park=3;
                       ui->label_60->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==3)
               {
                   if(tedad_khanehaye_boardwalk==3||tedad_khanehaye_boardwalk==4)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_park=4;
                       ui->label_60->setText(QString::number(4));
                       ui->comboBox_63->addItem("قلعه پارک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else if(name_malek_khiaban_boardwalk!=1)
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید مالک خیابان بوردواک هم باشید و به اصطلاح انحصار رنگ آبی را داشته باشید تا بتوانید در قلعه پارک یا بوردواک خانه بسازید لطفا بعد از خرید بوردواک تلاش کنید");
        }
    }
    else if(index=="خیابان بوردواک")
    {
        if(name_malek_qale_park==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_boardwalk==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_boardwalk<4)
            {
               if(tedad_khanehaye_boardwalk==0)
               {
                   if(tedad_khanehaye_qale_park==0 || tedad_khanehaye_qale_park==1)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_boardwalk=1;
                       ui->label_62->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==1)
               {
                   if(tedad_khanehaye_qale_park==1 || tedad_khanehaye_qale_park==2)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=400;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_boardwalk=2;
                       ui->label_62->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==2)
               {
                   if(tedad_khanehaye_qale_park==2||tedad_khanehaye_qale_park==3)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=800;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_boardwalk=3;
                       ui->label_62->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==3)
               {
                   if(tedad_khanehaye_qale_park==3||tedad_khanehaye_qale_park==4)
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=300;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_boardwalk=4;
                       ui->label_62->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان بوردواک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else if(name_malek_qale_park!=1)
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید مالک قلعه پارک هم باشید و به اصطلاح انحصار رنگ آبی را داشته باشید تا بتوانید در قلعه پارک یا بوردواک خانه بسازید لطفا بعد از خرید قلعه پارک تلاش کنید");
        }
    }
    ///////////
    else if(index=="خیابان اورینتال")
    {
        if(name_malek_khiaban_vermont==1 && name_malek_khiaban_conecticut==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_oriental==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_oriental<4)
            {
               if(tedad_khanehaye_oriental==0)
               {
                   if((tedad_khanehaye_vermont==0 || tedad_khanehaye_vermont==1) && (tedad_khanehaye_conecticut==0 || tedad_khanehaye_conecticut==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=30;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_oriental=1;
                       ui->label_68->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==1)
               {
                   if((tedad_khanehaye_vermont==1 || tedad_khanehaye_vermont==2) && (tedad_khanehaye_conecticut==1 || tedad_khanehaye_conecticut==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=60;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_oriental=2;
                       ui->label_68->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==2)
               {
                   if((tedad_khanehaye_vermont==2 || tedad_khanehaye_vermont==3) && (tedad_khanehaye_conecticut==2 || tedad_khanehaye_conecticut==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=180;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_oriental=3;
                       ui->label_68->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==3)
               {
                   if((tedad_khanehaye_vermont==3 || tedad_khanehaye_vermont==4) && (tedad_khanehaye_conecticut==3 || tedad_khanehaye_conecticut==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_oriental=4;
                       ui->label_68->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان اورینتال");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک خیابان ورمونت و هم کانکتیکات باشیدو به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    //////////
    else if(index=="خیابان ورمونت")
    {
        if(name_malek_khiaban_oriental==1 && name_malek_khiaban_conecticut==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_vermont==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_oriental<4)
            {
               if(tedad_khanehaye_vermont==0)
               {
                   if((tedad_khanehaye_oriental==0 || tedad_khanehaye_oriental==1) && (tedad_khanehaye_conecticut==0 || tedad_khanehaye_conecticut==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=30;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_vermont=1;
                       ui->label_74->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==1)
               {
                   if((tedad_khanehaye_oriental==1 || tedad_khanehaye_oriental==2) && (tedad_khanehaye_conecticut==1 || tedad_khanehaye_conecticut==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=60;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_vermont=2;
                       ui->label_74->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==2)
               {
                   if((tedad_khanehaye_oriental==2 || tedad_khanehaye_oriental==3) && (tedad_khanehaye_conecticut==2 || tedad_khanehaye_conecticut==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=180;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_vermont=3;
                       ui->label_74->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==3)
               {
                   if((tedad_khanehaye_oriental==3 || tedad_khanehaye_oriental==4) && (tedad_khanehaye_conecticut==3 || tedad_khanehaye_conecticut==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_vermont=4;
                       ui->label_74->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان ورمونت");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک خیابان اورینتال و هم کانکتیکات باشیدو به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    // '''''''''''''''''''''''''''''''''''''''''
    else if(index=="خیابان کانکتیکات")
    {
        if(name_malek_khiaban_vermont==1 && name_malek_khiaban_oriental==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_conecticut==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_conecticut<4)
            {
               if(tedad_khanehaye_conecticut==0)
               {
                   if((tedad_khanehaye_vermont==0 || tedad_khanehaye_vermont==1) && (tedad_khanehaye_oriental==0 || tedad_khanehaye_oriental==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=40;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_conecticut=1;
                       ui->label_80->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==1)
               {
                   if((tedad_khanehaye_vermont==1 || tedad_khanehaye_vermont==2) && (tedad_khanehaye_oriental==1 || tedad_khanehaye_oriental==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=60;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_conecticut=2;
                       ui->label_80->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==2)
               {
                   if((tedad_khanehaye_vermont==2 || tedad_khanehaye_vermont==3) && (tedad_khanehaye_oriental==2 || tedad_khanehaye_oriental==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_conecticut=3;
                       ui->label_80->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==3)
               {
                   if((tedad_khanehaye_vermont==3 || tedad_khanehaye_vermont==4) && (tedad_khanehaye_oriental==3 || tedad_khanehaye_oriental==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=150;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_conecticut=4;
                       ui->label_80->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان کانکتیکات");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک خیابان ورمونت و هم اورینتال باشیدو به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    //0000000000000000000000000000000
    else if(index=="قلعه چارلز")
    {
        if(name_malek_khiaban_stats==1 && name_malek_khiaban_virginia==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_charls==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_charls<4)
            {
               if(tedad_khanehaye_qale_charls==0)
               {
                   if((tedad_khanehaye_stats==0 || tedad_khanehaye_stats==1) && (tedad_khanehaye_virginia==0 || tedad_khanehaye_virginia==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=50;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_charls=1;
                       ui->label_86->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==1)
               {
                   if((tedad_khanehaye_stats==1 || tedad_khanehaye_stats==2) && (tedad_khanehaye_virginia==1 || tedad_khanehaye_virginia==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=100;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_charls=2;
                       ui->label_86->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==2)
               {
                   if((tedad_khanehaye_stats==2 || tedad_khanehaye_stats==3) && (tedad_khanehaye_virginia==2 || tedad_khanehaye_virginia==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=300;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_charls=3;
                       ui->label_86->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==3)
               {
                   if((tedad_khanehaye_stats==3 || tedad_khanehaye_stats==4) && (tedad_khanehaye_virginia==3 || tedad_khanehaye_virginia==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_charls=4;
                       ui->label_86->setText(QString::number(4));
                       ui->comboBox_63->addItem("قلعه چارلز");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک خیابان استیتس و هم ویرجینیا باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }
    //***************************************************************

    else if(index=="خیابان استیتس")
    {
        if(name_malek_qale_charls==1 && name_malek_khiaban_virginia==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_stats==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_stats<4)
            {
               if(tedad_khanehaye_stats==0)
               {
                   if((tedad_khanehaye_qale_charls==0 || tedad_khanehaye_qale_charls==1) && (tedad_khanehaye_virginia==0 || tedad_khanehaye_virginia==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=50;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_stats=1;
                       ui->label_92->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==1)
               {
                   if((tedad_khanehaye_qale_charls==1 || tedad_khanehaye_qale_charls==2) && (tedad_khanehaye_virginia==1 || tedad_khanehaye_virginia==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=100;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_stats=2;
                       ui->label_92->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==2)
               {
                   if((tedad_khanehaye_qale_charls==2 || tedad_khanehaye_qale_charls==3) && (tedad_khanehaye_virginia==2 || tedad_khanehaye_virginia==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=300;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_stats=3;
                       ui->label_92->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==3)
               {
                   if((tedad_khanehaye_qale_charls==3 || tedad_khanehaye_qale_charls==4) && (tedad_khanehaye_virginia==3 || tedad_khanehaye_virginia==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_stats=4;
                       ui->label_92->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان استیتس");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک قلعه چارلز و هم ویرجینیا باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }

    else if(index=="خیابان ویرجینیا")
    {
        if(name_malek_qale_charls==1 && name_malek_khiaban_stats==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_virginia==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_virginia<4)
            {
               if(tedad_khanehaye_virginia==0)
               {
                   if((tedad_khanehaye_qale_charls==0 || tedad_khanehaye_qale_charls==1) && (tedad_khanehaye_stats==0 || tedad_khanehaye_stats==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=60;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_virginia=1;
                       ui->label_98->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==1)
               {
                   if((tedad_khanehaye_qale_charls==1 || tedad_khanehaye_qale_charls==2) && (tedad_khanehaye_stats==1 || tedad_khanehaye_stats==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=120;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_virginia=2;
                       ui->label_98->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==2)
               {
                   if((tedad_khanehaye_qale_charls==2 || tedad_khanehaye_qale_charls==3) && (tedad_khanehaye_stats==2 || tedad_khanehaye_stats==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=320;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_virginia=3;
                       ui->label_98->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==3)
               {
                   if((tedad_khanehaye_qale_charls==3 || tedad_khanehaye_qale_charls==4) && (tedad_khanehaye_stats==3 || tedad_khanehaye_stats==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_virginia=4;
                       ui->label_98->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان ویرجینیا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک قلعه چارلز و هم استیتس باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }
    ////////////////////////////************************-----------------
    else if(index=="قلعه جیمز")
    {
        if(name_malek_khiaban_tenesi==1 && name_malek_khiaban_newyork==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_jims==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_jims<4)
            {
               if(tedad_khanehaye_qale_jims==0)
               {
                   if((tedad_khanehaye_tenesi==0 || tedad_khanehaye_tenesi==1) && (tedad_khanehaye_newyork==0 || tedad_khanehaye_newyork==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=70;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_jims=1;
                       ui->label_104->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==1)
               {
                   if((tedad_khanehaye_tenesi==1 || tedad_khanehaye_tenesi==2) && (tedad_khanehaye_newyork==1 || tedad_khanehaye_newyork==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_jims=2;
                       ui->label_104->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==2)
               {
                   if((tedad_khanehaye_tenesi==2 || tedad_khanehaye_tenesi==3) && (tedad_khanehaye_newyork==2 || tedad_khanehaye_newyork==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=350;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_jims=3;
                       ui->label_104->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==3)
               {
                   if((tedad_khanehaye_tenesi==3 || tedad_khanehaye_tenesi==4) && (tedad_khanehaye_newyork==3 || tedad_khanehaye_newyork==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_qale_jims=4;
                       ui->label_104->setText(QString::number(4));
                       ui->comboBox_63->addItem("قلعه جیمز");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک تنسی و هم نیویورک باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }

    else if(index=="خیابان تنسی")
    {
        if(name_malek_qale_jims==1 && name_malek_khiaban_newyork==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_tenesi==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_tenesi<4)
            {
               if(tedad_khanehaye_tenesi==0)
               {
                   if((tedad_khanehaye_qale_jims==0 || tedad_khanehaye_qale_jims==1) && (tedad_khanehaye_newyork==0 || tedad_khanehaye_newyork==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=70;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_tenesi=1;
                       ui->label_110->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==1)
               {
                   if((tedad_khanehaye_qale_jims==1 || tedad_khanehaye_qale_jims==2) && (tedad_khanehaye_newyork==1 || tedad_khanehaye_newyork==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_tenesi=2;
                       ui->label_110->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==2)
               {
                   if((tedad_khanehaye_qale_jims==2 || tedad_khanehaye_qale_jims==3) && (tedad_khanehaye_newyork==2 || tedad_khanehaye_newyork==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=350;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_tenesi=3;
                       ui->label_110->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==3)
               {
                   if((tedad_khanehaye_qale_jims==3 || tedad_khanehaye_qale_jims==4) && (tedad_khanehaye_newyork==3 || tedad_khanehaye_newyork==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_tenesi=4;
                       ui->label_110->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان تنسی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک جیمز و هم نیویورک باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }

    else if(index=="خیابان نیویورک")
    {
        if(name_malek_qale_jims==1 && name_malek_khiaban_tenesi==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_newyork==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_newyork<4)
            {
               if(tedad_khanehaye_newyork==0)
               {
                   if((tedad_khanehaye_qale_jims==0 || tedad_khanehaye_qale_jims==1) && (tedad_khanehaye_tenesi==0 || tedad_khanehaye_tenesi==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=80;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_newyork=1;
                       ui->label_116->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==1)
               {
                   if((tedad_khanehaye_qale_jims==1 || tedad_khanehaye_qale_jims==2) && (tedad_khanehaye_tenesi==1 || tedad_khanehaye_tenesi==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=140;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_newyork=2;
                       ui->label_116->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==2)
               {
                   if((tedad_khanehaye_qale_jims==2 || tedad_khanehaye_qale_jims==3) && (tedad_khanehaye_tenesi==2 || tedad_khanehaye_tenesi==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=380;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_newyork=3;
                       ui->label_116->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==3)
               {
                   if((tedad_khanehaye_qale_jims==3 || tedad_khanehaye_qale_jims==4) && (tedad_khanehaye_tenesi==3 || tedad_khanehaye_tenesi==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_newyork=4;
                       ui->label_116->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان نیویورک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک جیمز و هم تنسی باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }
    //=======================================================================
    else if(index=="خیابان کنتاکی")
    {
        if(name_malek_khiaban_indiana==1 && name_malek_khiaban_ilinois==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_kentucky==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_kentucky<4)
            {
               if(tedad_khanehaye_kentucky==0)
               {
                   if((tedad_khanehaye_indiana==0 || tedad_khanehaye_indiana==1) && (tedad_khanehaye_ilinois==0 || tedad_khanehaye_ilinois==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=90;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_kentucky=1;
                       ui->label_122->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==1)
               {
                   if((tedad_khanehaye_indiana==1 || tedad_khanehaye_indiana==2) && (tedad_khanehaye_ilinois==1 || tedad_khanehaye_ilinois==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=160;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_kentucky=2;
                       ui->label_122->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==2)
               {
                   if((tedad_khanehaye_indiana==2 || tedad_khanehaye_indiana==3) && (tedad_khanehaye_ilinois==2 || tedad_khanehaye_ilinois==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=450;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_kentucky=3;
                       ui->label_122->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==3)
               {
                   if((tedad_khanehaye_indiana==3 || tedad_khanehaye_indiana==4) && (tedad_khanehaye_ilinois==3 || tedad_khanehaye_ilinois==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_kentucky=4;
                       ui->label_122->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان کنتاکی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک ایندیانا و هم ایلی نویز باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }

    else if(index=="خیابان ایندیانا")
    {
        if(name_malek_khiaban_kentucky==1 && name_malek_khiaban_ilinois==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_indiana==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_indiana<4)
            {
               if(tedad_khanehaye_indiana==0)
               {
                   if((tedad_khanehaye_kentucky==0 || tedad_khanehaye_kentucky==1) && (tedad_khanehaye_ilinois==0 || tedad_khanehaye_ilinois==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=90;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_indiana=1;
                       ui->label_128->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==1)
               {
                   if((tedad_khanehaye_kentucky==1 || tedad_khanehaye_kentucky==2) && (tedad_khanehaye_ilinois==1 || tedad_khanehaye_ilinois==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=160;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_indiana=2;
                       ui->label_128->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==2)
               {
                   if((tedad_khanehaye_kentucky==2 || tedad_khanehaye_kentucky==3) && (tedad_khanehaye_ilinois==2 || tedad_khanehaye_ilinois==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=450;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_indiana=3;
                       ui->label_128->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==3)
               {
                   if((tedad_khanehaye_kentucky==3 || tedad_khanehaye_kentucky==4) && (tedad_khanehaye_ilinois==3 || tedad_khanehaye_ilinois==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_indiana=4;
                       ui->label_128->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان ایندیانا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک کنتاکی و هم ایلی نویز باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }
    //[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[::::::::
    else if(index=="خیابان ایلینویز")
    {
        if(name_malek_khiaban_kentucky==1 && name_malek_khiaban_indiana==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_ilinois==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_ilinois<4)
            {
               if(tedad_khanehaye_ilinois==0)
               {
                   if((tedad_khanehaye_kentucky==0 || tedad_khanehaye_kentucky==1) && (tedad_khanehaye_indiana==0 || tedad_khanehaye_indiana==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=100;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ilinois=1;
                       ui->label_134->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==1)
               {
                   if((tedad_khanehaye_kentucky==1 || tedad_khanehaye_kentucky==2) && (tedad_khanehaye_indiana==1 || tedad_khanehaye_indiana==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ilinois=2;
                       ui->label_134->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==2)
               {
                   if((tedad_khanehaye_kentucky==2 || tedad_khanehaye_kentucky==3) && (tedad_khanehaye_indiana==2 || tedad_khanehaye_indiana==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=450;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ilinois=3;
                       ui->label_134->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==3)
               {
                   if((tedad_khanehaye_kentucky==3 || tedad_khanehaye_kentucky==4) && (tedad_khanehaye_indiana==3 || tedad_khanehaye_indiana==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ilinois=4;
                       ui->label_134->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان ایلینویز");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک کنتاکی و هم ایندیانا باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }

    //'''''''''''''''''''''''
    else if(index=="خیابان آتلانتیک")
    {
        if(name_malek_khiaban_ventor==1 && name_malek_khiaban_marvin==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_atlantic==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_atlantic<4)
            {
               if(tedad_khanehaye_atlantic==0)
               {
                   if((tedad_khanehaye_ventor==0 || tedad_khanehaye_ventor==1) && (tedad_khanehaye_marvin==0 || tedad_khanehaye_marvin==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=110;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_atlantic=1;
                       ui->label_140->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==1)
               {
                   if((tedad_khanehaye_ventor==1 || tedad_khanehaye_ventor==2) && (tedad_khanehaye_marvin==1 || tedad_khanehaye_marvin==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=220;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_atlantic=2;
                       ui->label_140->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==2)
               {
                   if((tedad_khanehaye_ventor==2 || tedad_khanehaye_ventor==3) && (tedad_khanehaye_marvin==2 || tedad_khanehaye_marvin==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=470;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_atlantic=3;
                       ui->label_140->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==3)
               {
                   if((tedad_khanehaye_ventor==3 || tedad_khanehaye_ventor==4) && (tedad_khanehaye_marvin==3 || tedad_khanehaye_marvin==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_atlantic=4;
                       ui->label_140->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان آتلانتیک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک ونتور و هم ماروین باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }

    else if(index=="خیابان ونتور")
    {
        if(name_malek_khiaban_atlantic==1 && name_malek_khiaban_marvin==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_ventor==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_ventor<4)
            {
               if(tedad_khanehaye_ventor==0)
               {
                   if((tedad_khanehaye_atlantic==0 || tedad_khanehaye_atlantic==1) && (tedad_khanehaye_marvin==0 || tedad_khanehaye_marvin==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=110;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ventor=1;
                       ui->label_146->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==1)
               {
                   if((tedad_khanehaye_atlantic==1 || tedad_khanehaye_atlantic==2) && (tedad_khanehaye_marvin==1 || tedad_khanehaye_marvin==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=220;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ventor=2;
                       ui->label_146->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==2)
               {
                   if((tedad_khanehaye_atlantic==2 || tedad_khanehaye_atlantic==3) && (tedad_khanehaye_marvin==2 || tedad_khanehaye_marvin==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=470;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ventor=3;
                       ui->label_146->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==3)
               {
                   if((tedad_khanehaye_atlantic==3 || tedad_khanehaye_atlantic==4) && (tedad_khanehaye_marvin==3 || tedad_khanehaye_marvin==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_ventor=4;
                       ui->label_146->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان ونتور");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک آتلانتیک و هم ماروین باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }

    else if(index=="باغ ماروین")
    {
        if(name_malek_khiaban_atlantic==1 && name_malek_khiaban_ventor==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_marvin==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_marvin<4)
            {
               if(tedad_khanehaye_marvin==0)
               {
                   if((tedad_khanehaye_atlantic==0 || tedad_khanehaye_atlantic==1) && (tedad_khanehaye_ventor==0 || tedad_khanehaye_ventor==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=120;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_marvin=1;
                       ui->label_152->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==1)
               {
                   if((tedad_khanehaye_atlantic==1 || tedad_khanehaye_atlantic==2) && (tedad_khanehaye_ventor==1 || tedad_khanehaye_ventor==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=240;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_marvin=2;
                       ui->label_152->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==2)
               {
                   if((tedad_khanehaye_atlantic==2 || tedad_khanehaye_atlantic==3) && (tedad_khanehaye_ventor==2 || tedad_khanehaye_ventor==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=490;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_marvin=3;
                       ui->label_152->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==3)
               {
                   if((tedad_khanehaye_atlantic==3 || tedad_khanehaye_atlantic==4) && (tedad_khanehaye_ventor==3 || tedad_khanehaye_ventor==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=175;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_marvin=4;
                       ui->label_152->setText(QString::number(4));
                       ui->comboBox_63->addItem("باغ ماروین");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک آتلانتیک و هم ونتور باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }

    else if(index=="خیابان پاسیفیک")
    {
        if(name_malek_khiaban_northcarolina==1 && name_malek_khiaban_pensilvania==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_pacific==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_pacific<4)
            {
               if(tedad_khanehaye_pacific==0)
               {
                   if((tedad_khanehaye_northcarolina==0 || tedad_khanehaye_northcarolina==1) && (tedad_khanehaye_pensilvania==0 || tedad_khanehaye_pensilvania==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pacific=1;
                       ui->label_158->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==1)
               {
                   if((tedad_khanehaye_northcarolina==1 || tedad_khanehaye_northcarolina==2) && (tedad_khanehaye_pensilvania==1 || tedad_khanehaye_pensilvania==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=260;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pacific=2;
                       ui->label_158->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==2)
               {
                   if((tedad_khanehaye_northcarolina==2 || tedad_khanehaye_northcarolina==3) && (tedad_khanehaye_pensilvania==2 || tedad_khanehaye_pensilvania==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=510;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pacific=3;
                       ui->label_158->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==3)
               {
                   if((tedad_khanehaye_northcarolina==3 || tedad_khanehaye_northcarolina==4) && (tedad_khanehaye_pensilvania==3 || tedad_khanehaye_pensilvania==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pacific=4;
                       ui->label_158->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان پاسیفیک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک  خیابان کارولینای شمالی و هم خیابان پنسیلوانیا باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }

    else if(index=="خیابان کارولینای شمالی")
    {
        if(name_malek_khiaban_pacific==1 && name_malek_khiaban_pensilvania==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_northcarolina==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_northcarolina<4)
            {
               if(tedad_khanehaye_northcarolina==0)
               {
                   if((tedad_khanehaye_pacific==0 || tedad_khanehaye_pacific==1) && (tedad_khanehaye_pensilvania==0 || tedad_khanehaye_pensilvania==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=130;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_northcarolina=1;
                       ui->label_164->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==1)
               {
                   if((tedad_khanehaye_pacific==1 || tedad_khanehaye_pacific==2) && (tedad_khanehaye_pensilvania==1 || tedad_khanehaye_pensilvania==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=260;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_northcarolina=2;
                       ui->label_164->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==2)
               {
                   if((tedad_khanehaye_pacific==2 || tedad_khanehaye_pacific==3) && (tedad_khanehaye_pensilvania==2 || tedad_khanehaye_pensilvania==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=510;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_northcarolina=3;
                       ui->label_164->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==3)
               {
                   if((tedad_khanehaye_pacific==3 || tedad_khanehaye_pacific==4) && (tedad_khanehaye_pensilvania==3 || tedad_khanehaye_pensilvania==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_northcarolina=4;
                       ui->label_164->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان کارولینای شمالی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک  خیابان پاسیفیک و هم خیابان پنسیلوانیا باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }
    else if(index=="خیابان پنسیلوانیا")
    {
        if(name_malek_khiaban_pacific==1 && name_malek_khiaban_northcarolina==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_pensilvania==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_pensilvania<4)
            {
               if(tedad_khanehaye_pensilvania==0)
               {
                   if((tedad_khanehaye_pacific==0 || tedad_khanehaye_pacific==1) && (tedad_khanehaye_northcarolina==0 || tedad_khanehaye_northcarolina==1))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=150;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pensilvania=1;
                       ui->label_170->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==1)
               {
                   if((tedad_khanehaye_pacific==1 || tedad_khanehaye_pacific==2) && (tedad_khanehaye_northcarolina==1 || tedad_khanehaye_northcarolina==2))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=300;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pensilvania=2;
                       ui->label_170->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==2)
               {
                   if((tedad_khanehaye_pacific==2 || tedad_khanehaye_pacific==3) && (tedad_khanehaye_northcarolina==2 || tedad_khanehaye_northcarolina==3))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=550;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pensilvania=3;
                       ui->label_170->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==3)
               {
                   if((tedad_khanehaye_pacific==3 || tedad_khanehaye_pacific==4) && (tedad_khanehaye_northcarolina==3 || tedad_khanehaye_northcarolina==4))
                   {
                       moneyp1=ui->lineEdit->text().toInt();
                       moneyp1-=200;
                       ui->lineEdit->setText(QString::number(moneyp1));
                       tedad_khanehaye_pensilvania=4;
                       ui->label_170->setText(QString::number(4));
                       ui->comboBox_63->addItem("خیابان پنسیلوانیا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک  خیابان پاسیفیک و هم خیابان کارولینای شمالی باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::khanesazi_p2(QString index)
{
    double moneyp2;
    if(index=="خیابان مدیترانه")
    {
        if(name_malek_khiaban_baltic==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre
            if(tedad_khanehaye_meditarane==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_meditarane<4)
            {
                if(tedad_khanehaye_meditarane==0)
                {
                    if(tedad_khanehaye_baltic==0||tedad_khanehaye_baltic==1)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=10;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_meditarane=1;
                        ui->label_48->setText(QString::number(1));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==1)
                {
                    if(tedad_khanehaye_baltic==1||tedad_khanehaye_baltic==2)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=20;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_meditarane=2;
                        ui->label_48->setText(QString::number(2));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==2)
                {
                    if(tedad_khanehaye_baltic==2||tedad_khanehaye_baltic==3)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=60;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_meditarane=3;
                        ui->label_48->setText(QString::number(3));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_meditarane==3)
                {
                    if(tedad_khanehaye_baltic==3||tedad_khanehaye_baltic==4)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=70;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_meditarane=4;
                        ui->label_48->setText(QString::number(4));
                        ui->comboBox_64->addItem("خیابان مدیترانه");
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
            }
        }
        else if(name_malek_khiaban_baltic!=2)
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید مالک خیابان بالتیک هم باشید و به اصطلاح انحصار رنگ قهوه ای را داشته باشید تا بتوانید در مدیترانه یا بالتیک خانه بسازید لطفا بعد از خرید بالتیک تلاش کنید");
        }
    }
    ////
    else if(index=="خیابان بالتیک")
    {
        if(name_malek_khiaban_meditarane==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre
            if(tedad_khanehaye_baltic==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_baltic<4)
            {
                if(tedad_khanehaye_baltic==0)
                {
                    if(tedad_hotelhaye_meditarane==0 || tedad_khanehaye_meditarane==1)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=20;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_baltic=1;
                        ui->label_50->setText(QString::number(1));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_baltic==1)
                {
                    if(tedad_khanehaye_meditarane==1 || tedad_khanehaye_meditarane==2)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=40;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_baltic=2;
                        ui->label_50->setText(QString::number(2));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_baltic==2)
                {
                    if(tedad_khanehaye_meditarane==2||tedad_khanehaye_meditarane==3)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=120;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_baltic=3;
                        ui->label_50->setText(QString::number(3));
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
                else if(tedad_khanehaye_baltic==3)
                {
                    if(tedad_khanehaye_meditarane==3||tedad_khanehaye_meditarane==4)
                    {
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=180;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                        tedad_khanehaye_baltic=4;
                        ui->label_50->setText(QString::number(4));
                        ui->comboBox_64->addItem("خیابان بالتیک");
                    }
                    else {
                        QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                    }
                }
            }
        }
        else if(name_malek_khiaban_meditarane!=2)
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید مالک خیابان مدیترانه هم باشید و به اصطلاح انحصار رنگ قهوه ای را داشته باشید تا بتوانید در مدیترانه یا بالتیک خانه بسازید لطفا بعد از خرید مدیترانه تلاش کنید");
        }
    }
    else if(index=="قلعه پارک")
    {
        if(name_malek_khiaban_boardwalk==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_park==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_park<4)
            {
               if(tedad_khanehaye_qale_park==0)
               {
                   if(tedad_khanehaye_boardwalk==0 || tedad_khanehaye_boardwalk==1)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_park=1;
                       ui->label_60->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==1)
               {
                   if(tedad_khanehaye_boardwalk==1 || tedad_khanehaye_boardwalk==2)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=325;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_park=2;
                       ui->label_60->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==2)
               {
                   if(tedad_khanehaye_boardwalk==2||tedad_khanehaye_boardwalk==3)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=600;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_park=3;
                       ui->label_60->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_park==3)
               {
                   if(tedad_khanehaye_boardwalk==3||tedad_khanehaye_boardwalk==4)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_park=4;
                       ui->label_60->setText(QString::number(4));
                       ui->comboBox_64->addItem("قلعه پارک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else if(name_malek_khiaban_boardwalk!=2)
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید مالک خیابان بوردواک هم باشید و به اصطلاح انحصار رنگ آبی را داشته باشید تا بتوانید در قلعه پارک یا بوردواک خانه بسازید لطفا بعد از خرید بوردواک تلاش کنید");
        }
    }
    else if(index=="خیابان بوردواک")
    {
        if(name_malek_qale_park==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_boardwalk==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_boardwalk<4)
            {
               if(tedad_khanehaye_boardwalk==0)
               {
                   if(tedad_khanehaye_qale_park==0 || tedad_khanehaye_qale_park==1)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_boardwalk=1;
                       ui->label_62->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==1)
               {
                   if(tedad_khanehaye_qale_park==1 || tedad_khanehaye_qale_park==2)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=400;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_boardwalk=2;
                       ui->label_62->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==2)
               {
                   if(tedad_khanehaye_qale_park==2||tedad_khanehaye_qale_park==3)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=800;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_boardwalk=3;
                       ui->label_62->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_boardwalk==3)
               {
                   if(tedad_khanehaye_qale_park==3||tedad_khanehaye_qale_park==4)
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=300;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_boardwalk=4;
                       ui->label_62->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان بوردواک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else if(name_malek_qale_park!=2)
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید مالک قلعه پارک هم باشید و به اصطلاح انحصار رنگ آبی را داشته باشید تا بتوانید در قلعه پارک یا بوردواک خانه بسازید لطفا بعد از خرید قلعه پارک تلاش کنید");
        }
    }
    else if(index=="خیابان اورینتال")
    {
        if(name_malek_khiaban_vermont==2 && name_malek_khiaban_conecticut==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_oriental==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_oriental<4)
            {
               if(tedad_khanehaye_oriental==0)
               {
                   if((tedad_khanehaye_vermont==0 || tedad_khanehaye_vermont==1) && (tedad_khanehaye_conecticut==0 || tedad_khanehaye_conecticut==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=30;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_oriental=1;
                       ui->label_68->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==1)
               {
                   if((tedad_khanehaye_vermont==1 || tedad_khanehaye_vermont==2) && (tedad_khanehaye_conecticut==1 || tedad_khanehaye_conecticut==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=60;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_oriental=2;
                       ui->label_68->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==2)
               {
                   if((tedad_khanehaye_vermont==2 || tedad_khanehaye_vermont==3) && (tedad_khanehaye_conecticut==2 || tedad_khanehaye_conecticut==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=180;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_oriental=3;
                       ui->label_68->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_oriental==3)
               {
                   if((tedad_khanehaye_vermont==3 || tedad_khanehaye_vermont==4) && (tedad_khanehaye_conecticut==3 || tedad_khanehaye_conecticut==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_oriental=4;
                       ui->label_68->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان اورینتال");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن2  شما باید هم مالک خیابان ورمونت و هم کانکتیکات باشید  و به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    ///
    else if(index=="خیابان ورمونت")
    {
        if(name_malek_khiaban_oriental==2 && name_malek_khiaban_conecticut==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_vermont==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_oriental<4)
            {
               if(tedad_khanehaye_vermont==0)
               {
                   if((tedad_khanehaye_oriental==0 || tedad_khanehaye_oriental==1) && (tedad_khanehaye_conecticut==0 || tedad_khanehaye_conecticut==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=30;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_vermont=1;
                       ui->label_74->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==1)
               {
                   if((tedad_khanehaye_oriental==1 || tedad_khanehaye_oriental==2) && (tedad_khanehaye_conecticut==1 || tedad_khanehaye_conecticut==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=60;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_vermont=2;
                       ui->label_74->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==2)
               {
                   if((tedad_khanehaye_oriental==2 || tedad_khanehaye_oriental==3) && (tedad_khanehaye_conecticut==2 || tedad_khanehaye_conecticut==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=180;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_vermont=3;
                       ui->label_74->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_vermont==3)
               {
                   if((tedad_khanehaye_oriental==3 || tedad_khanehaye_oriental==4) && (tedad_khanehaye_conecticut==3 || tedad_khanehaye_conecticut==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_vermont=4;
                       ui->label_74->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان ورمونت");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک خیابان اورینتال و هم کانکتیکات باشیدو به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    else if(index=="خیابان کانکتیکات")
    {
        if(name_malek_khiaban_vermont==2 && name_malek_khiaban_oriental==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_conecticut==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_conecticut<4)
            {
               if(tedad_khanehaye_conecticut==0)
               {
                   if((tedad_khanehaye_vermont==0 || tedad_khanehaye_vermont==1) && (tedad_khanehaye_oriental==0 || tedad_khanehaye_oriental==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=40;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_conecticut=1;
                       ui->label_80->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==1)
               {
                   if((tedad_khanehaye_vermont==1 || tedad_khanehaye_vermont==2) && (tedad_khanehaye_oriental==1 || tedad_khanehaye_oriental==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=60;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_conecticut=2;
                       ui->label_80->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==2)
               {
                   if((tedad_khanehaye_vermont==2 || tedad_khanehaye_vermont==3) && (tedad_khanehaye_oriental==2 || tedad_khanehaye_oriental==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_conecticut=3;
                       ui->label_80->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_conecticut==3)
               {
                   if((tedad_khanehaye_vermont==3 || tedad_khanehaye_vermont==4) && (tedad_khanehaye_oriental==3 || tedad_khanehaye_oriental==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=150;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_conecticut=4;
                       ui->label_80->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان کانکتیکات");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک خیابان ورمونت و هم اورینتال باشیدو به اصطلاح انحصار رنگ یاسی را داشته باشید تا بتوانید در ورمونت کانکتیکات و اورینتال خانه بسازید لطفا بعد از خرید همه رنگهای یاسی تلاش کنید");
        }
    }
    else if(index=="قلعه چارلز")
    {
        if(name_malek_khiaban_stats==2 && name_malek_khiaban_virginia==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_charls==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_charls<4)
            {
               if(tedad_khanehaye_qale_charls==0)
               {
                   if((tedad_khanehaye_stats==0 || tedad_khanehaye_stats==1) && (tedad_khanehaye_virginia==0 || tedad_khanehaye_virginia==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=50;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_charls=1;
                       ui->label_86->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==1)
               {
                   if((tedad_khanehaye_stats==1 || tedad_khanehaye_stats==2) && (tedad_khanehaye_virginia==1 || tedad_khanehaye_virginia==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=100;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_charls=2;
                       ui->label_86->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==2)
               {
                   if((tedad_khanehaye_stats==2 || tedad_khanehaye_stats==3) && (tedad_khanehaye_virginia==2 || tedad_khanehaye_virginia==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=300;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_charls=3;
                       ui->label_86->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_charls==3)
               {
                   if((tedad_khanehaye_stats==3 || tedad_khanehaye_stats==4) && (tedad_khanehaye_virginia==3 || tedad_khanehaye_virginia==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_charls=4;
                       ui->label_86->setText(QString::number(4));
                       ui->comboBox_64->addItem("قلعه چارلز");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک خیابان استیتس و هم ویرجینیا باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }
    else if(index=="خیابان استیتس")
    {
        if(name_malek_qale_charls==2 && name_malek_khiaban_virginia==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_stats==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_stats<4)
            {
               if(tedad_khanehaye_stats==0)
               {
                   if((tedad_khanehaye_qale_charls==0 || tedad_khanehaye_qale_charls==1) && (tedad_khanehaye_virginia==0 || tedad_khanehaye_virginia==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=50;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_stats=1;
                       ui->label_92->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==1)
               {
                   if((tedad_khanehaye_qale_charls==1 || tedad_khanehaye_qale_charls==2) && (tedad_khanehaye_virginia==1 || tedad_khanehaye_virginia==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=100;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_stats=2;
                       ui->label_92->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==2)
               {
                   if((tedad_khanehaye_qale_charls==2 || tedad_khanehaye_qale_charls==3) && (tedad_khanehaye_virginia==2 || tedad_khanehaye_virginia==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=300;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_stats=3;
                       ui->label_92->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_stats==3)
               {
                   if((tedad_khanehaye_qale_charls==3 || tedad_khanehaye_qale_charls==4) && (tedad_khanehaye_virginia==3 || tedad_khanehaye_virginia==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_stats=4;
                       ui->label_92->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان استیتس");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک قلعه چارلز و هم ویرجینیا باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }
    else if(index=="خیابان ویرجینیا")
    {
        if(name_malek_qale_charls==2 && name_malek_khiaban_stats==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_virginia==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_virginia<4)
            {
               if(tedad_khanehaye_virginia==0)
               {
                   if((tedad_khanehaye_qale_charls==0 || tedad_khanehaye_qale_charls==1) && (tedad_khanehaye_stats==0 || tedad_khanehaye_stats==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=60;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_virginia=1;
                       ui->label_98->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==1)
               {
                   if((tedad_khanehaye_qale_charls==1 || tedad_khanehaye_qale_charls==2) && (tedad_khanehaye_stats==1 || tedad_khanehaye_stats==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=120;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_virginia=2;
                       ui->label_98->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==2)
               {
                   if((tedad_khanehaye_qale_charls==2 || tedad_khanehaye_qale_charls==3) && (tedad_khanehaye_stats==2 || tedad_khanehaye_stats==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=320;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_virginia=3;
                       ui->label_98->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_virginia==3)
               {
                   if((tedad_khanehaye_qale_charls==3 || tedad_khanehaye_qale_charls==4) && (tedad_khanehaye_stats==3 || tedad_khanehaye_stats==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_virginia=4;
                       ui->label_98->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان ویرجینیا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک قلعه چارلز و هم استیتس باشیدو به اصطلاح انحصار رنگ صورتی را داشته باشید تا بتوانید در چارلز استیتس و ویرجینیا خانه بسازید لطفا بعد از خرید همه رنگهای صورتی تلاش کنید");
        }
    }
    else if(index=="قلعه جیمز")
    {
        if(name_malek_khiaban_tenesi==2 && name_malek_khiaban_newyork==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_qale_jims==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_qale_jims<4)
            {
               if(tedad_khanehaye_qale_jims==0)
               {
                   if((tedad_khanehaye_tenesi==0 || tedad_khanehaye_tenesi==1) && (tedad_khanehaye_newyork==0 || tedad_khanehaye_newyork==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=70;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_jims=1;
                       ui->label_104->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==1)
               {
                   if((tedad_khanehaye_tenesi==1 || tedad_khanehaye_tenesi==2) && (tedad_khanehaye_newyork==1 || tedad_khanehaye_newyork==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_jims=2;
                       ui->label_104->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==2)
               {
                   if((tedad_khanehaye_tenesi==2 || tedad_khanehaye_tenesi==3) && (tedad_khanehaye_newyork==2 || tedad_khanehaye_newyork==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=350;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_jims=3;
                       ui->label_104->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_qale_jims==3)
               {
                   if((tedad_khanehaye_tenesi==3 || tedad_khanehaye_tenesi==4) && (tedad_khanehaye_newyork==3 || tedad_khanehaye_newyork==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_qale_jims=4;
                       ui->label_104->setText(QString::number(4));
                       ui->comboBox_64->addItem("قلعه جیمز");

                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک تنسی و هم نیویورک باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }
    else if(index=="خیابان تنسی")
    {
        if(name_malek_qale_jims==2 && name_malek_khiaban_newyork==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_tenesi==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_tenesi<4)
            {
               if(tedad_khanehaye_tenesi==0)
               {
                   if((tedad_khanehaye_qale_jims==0 || tedad_khanehaye_qale_jims==1) && (tedad_khanehaye_newyork==0 || tedad_khanehaye_newyork==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=70;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_tenesi=1;
                       ui->label_110->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==1)
               {
                   if((tedad_khanehaye_qale_jims==1 || tedad_khanehaye_qale_jims==2) && (tedad_khanehaye_newyork==1 || tedad_khanehaye_newyork==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_tenesi=2;
                       ui->label_110->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==2)
               {
                   if((tedad_khanehaye_qale_jims==2 || tedad_khanehaye_qale_jims==3) && (tedad_khanehaye_newyork==2 || tedad_khanehaye_newyork==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=350;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_tenesi=3;
                       ui->label_110->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_tenesi==3)
               {
                   if((tedad_khanehaye_qale_jims==3 || tedad_khanehaye_qale_jims==4) && (tedad_khanehaye_newyork==3 || tedad_khanehaye_newyork==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_tenesi=4;
                       ui->label_110->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان تنسی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک جیمز و هم نیویورک باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }
    else if(index=="خیابان نیویورک")
    {
        if(name_malek_qale_jims==2 && name_malek_khiaban_tenesi==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_newyork==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_newyork<4)
            {
               if(tedad_khanehaye_newyork==0)
               {
                   if((tedad_khanehaye_qale_jims==0 || tedad_khanehaye_qale_jims==1) && (tedad_khanehaye_tenesi==0 || tedad_khanehaye_tenesi==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=80;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_newyork=1;
                       ui->label_116->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==1)
               {
                   if((tedad_khanehaye_qale_jims==1 || tedad_khanehaye_qale_jims==2) && (tedad_khanehaye_tenesi==1 || tedad_khanehaye_tenesi==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=140;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_newyork=2;
                       ui->label_116->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==2)
               {
                   if((tedad_khanehaye_qale_jims==2 || tedad_khanehaye_qale_jims==3) && (tedad_khanehaye_tenesi==2 || tedad_khanehaye_tenesi==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=380;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_newyork=3;
                       ui->label_116->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_newyork==3)
               {
                   if((tedad_khanehaye_qale_jims==3 || tedad_khanehaye_qale_jims==4) && (tedad_khanehaye_tenesi==3 || tedad_khanehaye_tenesi==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_newyork=4;
                       ui->label_116->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان نیویورک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک جیمز و هم تنسی باشیدو به اصطلاح انحصار رنگ نارنجی را داشته باشید تا بتوانید در جیمز تنسی و نیویورک خانه بسازید لطفا بعد از خرید همه رنگهای نارنجی تلاش کنید");
        }
    }

    else if(index=="خیابان کنتاکی")
    {
        if(name_malek_khiaban_indiana==2 && name_malek_khiaban_ilinois==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_kentucky==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_kentucky<4)
            {
               if(tedad_khanehaye_kentucky==0)
               {
                   if((tedad_khanehaye_indiana==0 || tedad_khanehaye_indiana==1) && (tedad_khanehaye_ilinois==0 || tedad_khanehaye_ilinois==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=90;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_kentucky=1;
                       ui->label_122->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==1)
               {
                   if((tedad_khanehaye_indiana==1 || tedad_khanehaye_indiana==2) && (tedad_khanehaye_ilinois==1 || tedad_khanehaye_ilinois==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=160;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_kentucky=2;
                       ui->label_122->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==2)
               {
                   if((tedad_khanehaye_indiana==2 || tedad_khanehaye_indiana==3) && (tedad_khanehaye_ilinois==2 || tedad_khanehaye_ilinois==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=450;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_kentucky=3;
                       ui->label_122->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_kentucky==3)
               {
                   if((tedad_khanehaye_indiana==3 || tedad_khanehaye_indiana==4) && (tedad_khanehaye_ilinois==3 || tedad_khanehaye_ilinois==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_kentucky=4;
                       ui->label_122->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان کنتاکی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک ایندیانا و هم ایلی نویز باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }
    else if(index=="خیابان ایندیانا")
    {
        if(name_malek_khiaban_kentucky==2 && name_malek_khiaban_ilinois==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_indiana==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_indiana<4)
            {
               if(tedad_khanehaye_indiana==0)
               {
                   if((tedad_khanehaye_kentucky==0 || tedad_khanehaye_kentucky==1) && (tedad_khanehaye_ilinois==0 || tedad_khanehaye_ilinois==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=90;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_indiana=1;
                       ui->label_128->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==1)
               {
                   if((tedad_khanehaye_kentucky==1 || tedad_khanehaye_kentucky==2) && (tedad_khanehaye_ilinois==1 || tedad_khanehaye_ilinois==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=160;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_indiana=2;
                       ui->label_128->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==2)
               {
                   if((tedad_khanehaye_kentucky==2 || tedad_khanehaye_kentucky==3) && (tedad_khanehaye_ilinois==2 || tedad_khanehaye_ilinois==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=450;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_indiana=3;
                       ui->label_128->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_indiana==3)
               {
                   if((tedad_khanehaye_kentucky==3 || tedad_khanehaye_kentucky==4) && (tedad_khanehaye_ilinois==3 || tedad_khanehaye_ilinois==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_indiana=4;
                       ui->label_128->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان ایندیانا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک کنتاکی و هم ایلی نویز باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }

    else if(index=="خیابان ایلینویز")
    {
        if(name_malek_khiaban_kentucky==2 && name_malek_khiaban_indiana==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_ilinois==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_ilinois<4)
            {
               if(tedad_khanehaye_ilinois==0)
               {
                   if((tedad_khanehaye_kentucky==0 || tedad_khanehaye_kentucky==1) && (tedad_khanehaye_indiana==0 || tedad_khanehaye_indiana==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=100;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ilinois=1;
                       ui->label_134->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==1)
               {
                   if((tedad_khanehaye_kentucky==1 || tedad_khanehaye_kentucky==2) && (tedad_khanehaye_indiana==1 || tedad_khanehaye_indiana==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ilinois=2;
                       ui->label_134->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==2)
               {
                   if((tedad_khanehaye_kentucky==2 || tedad_khanehaye_kentucky==3) && (tedad_khanehaye_indiana==2 || tedad_khanehaye_indiana==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=450;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ilinois=3;
                       ui->label_134->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ilinois==3)
               {
                   if((tedad_khanehaye_kentucky==3 || tedad_khanehaye_kentucky==4) && (tedad_khanehaye_indiana==3 || tedad_khanehaye_indiana==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ilinois=4;
                       ui->label_134->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان ایلینویز");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک کنتاکی و هم ایندیانا باشیدو به اصطلاح انحصار رنگ قرمز را داشته باشید تا بتوانید در کنتاکی ایندیانا و ایلی نویز خانه بسازید لطفا بعد از خرید همه رنگهای قرمز تلاش کنید");
        }
    }

    else if(index=="خیابان آتلانتیک")
    {
        if(name_malek_khiaban_ventor==2 && name_malek_khiaban_marvin==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_atlantic==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_atlantic<4)
            {
               if(tedad_khanehaye_atlantic==0)
               {
                   if((tedad_khanehaye_ventor==0 || tedad_khanehaye_ventor==1) && (tedad_khanehaye_marvin==0 || tedad_khanehaye_marvin==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=110;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_atlantic=1;
                       ui->label_140->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==1)
               {
                   if((tedad_khanehaye_ventor==1 || tedad_khanehaye_ventor==2) && (tedad_khanehaye_marvin==1 || tedad_khanehaye_marvin==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=220;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_atlantic=2;
                       ui->label_140->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==2)
               {
                   if((tedad_khanehaye_ventor==2 || tedad_khanehaye_ventor==3) && (tedad_khanehaye_marvin==2 || tedad_khanehaye_marvin==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=470;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_atlantic=3;
                       ui->label_140->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_atlantic==3)
               {
                   if((tedad_khanehaye_ventor==3 || tedad_khanehaye_ventor==4) && (tedad_khanehaye_marvin==3 || tedad_khanehaye_marvin==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_atlantic=4;
                       ui->label_140->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان آتلانتیک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک ونتور و هم ماروین باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }


    else if(index=="خیابان ونتور")
    {
        if(name_malek_khiaban_atlantic==2 && name_malek_khiaban_marvin==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_ventor==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_ventor<4)
            {
               if(tedad_khanehaye_ventor==0)
               {
                   if((tedad_khanehaye_atlantic==0 || tedad_khanehaye_atlantic==1) && (tedad_khanehaye_marvin==0 || tedad_khanehaye_marvin==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=110;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ventor=1;
                       ui->label_146->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==1)
               {
                   if((tedad_khanehaye_atlantic==1 || tedad_khanehaye_atlantic==2) && (tedad_khanehaye_marvin==1 || tedad_khanehaye_marvin==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=220;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ventor=2;
                       ui->label_146->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==2)
               {
                   if((tedad_khanehaye_atlantic==2 || tedad_khanehaye_atlantic==3) && (tedad_khanehaye_marvin==2 || tedad_khanehaye_marvin==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=470;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ventor=3;
                       ui->label_146->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_ventor==3)
               {
                   if((tedad_khanehaye_atlantic==3 || tedad_khanehaye_atlantic==4) && (tedad_khanehaye_marvin==3 || tedad_khanehaye_marvin==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_ventor=4;
                       ui->label_146->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان ونتور");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک آتلانتیک و هم ماروین باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }

    else if(index=="باغ ماروین")
    {
        if(name_malek_khiaban_atlantic==2 && name_malek_khiaban_ventor==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_marvin==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_marvin<4)
            {
               if(tedad_khanehaye_marvin==0)
               {
                   if((tedad_khanehaye_atlantic==0 || tedad_khanehaye_atlantic==1) && (tedad_khanehaye_ventor==0 || tedad_khanehaye_ventor==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=120;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_marvin=1;
                       ui->label_152->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==1)
               {
                   if((tedad_khanehaye_atlantic==1 || tedad_khanehaye_atlantic==2) && (tedad_khanehaye_ventor==1 || tedad_khanehaye_ventor==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=240;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_marvin=2;
                       ui->label_152->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==2)
               {
                   if((tedad_khanehaye_atlantic==2 || tedad_khanehaye_atlantic==3) && (tedad_khanehaye_ventor==2 || tedad_khanehaye_ventor==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=490;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_marvin=3;
                       ui->label_152->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_marvin==3)
               {
                   if((tedad_khanehaye_atlantic==3 || tedad_khanehaye_atlantic==4) && (tedad_khanehaye_ventor==3 || tedad_khanehaye_ventor==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=175;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_marvin=4;
                       ui->label_152->setText(QString::number(4));
                       ui->comboBox_64->addItem("باغ ماروین");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک آتلانتیک و هم ونتور باشیدو به اصطلاح انحصار رنگ زرد را داشته باشید تا بتوانید در آتلانتیک و ونتور و ماروین خانه بسازید لطفا بعد از خرید همه رنگهای زرد تلاش کنید");
        }
    }
    else if(index=="خیابان پاسیفیک")
    {
        if(name_malek_khiaban_northcarolina==2 && name_malek_khiaban_pensilvania==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_pacific==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_pacific<4)
            {
               if(tedad_khanehaye_pacific==0)
               {
                   if((tedad_khanehaye_northcarolina==0 || tedad_khanehaye_northcarolina==1) && (tedad_khanehaye_pensilvania==0 || tedad_khanehaye_pensilvania==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pacific=1;
                       ui->label_158->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==1)
               {
                   if((tedad_khanehaye_northcarolina==1 || tedad_khanehaye_northcarolina==2) && (tedad_khanehaye_pensilvania==1 || tedad_khanehaye_pensilvania==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=260;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pacific=2;
                       ui->label_158->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==2)
               {
                   if((tedad_khanehaye_northcarolina==2 || tedad_khanehaye_northcarolina==3) && (tedad_khanehaye_pensilvania==2 || tedad_khanehaye_pensilvania==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=510;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pacific=3;
                       ui->label_158->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pacific==3)
               {
                   if((tedad_khanehaye_northcarolina==3 || tedad_khanehaye_northcarolina==4) && (tedad_khanehaye_pensilvania==3 || tedad_khanehaye_pensilvania==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pacific=4;
                       ui->label_158->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان پاسیفیک");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک  خیابان کارولینای شمالی و هم خیابان پنسیلوانیا باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }

    else if(index=="خیابان کارولینای شمالی")
    {
        if(name_malek_khiaban_pacific==2 && name_malek_khiaban_pensilvania==2)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_northcarolina==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_northcarolina<4)
            {
               if(tedad_khanehaye_northcarolina==0)
               {
                   if((tedad_khanehaye_pacific==0 || tedad_khanehaye_pacific==1) && (tedad_khanehaye_pensilvania==0 || tedad_khanehaye_pensilvania==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=130;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_northcarolina=1;
                       ui->label_164->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==1)
               {
                   if((tedad_khanehaye_pacific==1 || tedad_khanehaye_pacific==2) && (tedad_khanehaye_pensilvania==1 || tedad_khanehaye_pensilvania==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=260;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_northcarolina=2;
                       ui->label_164->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==2)
               {
                   if((tedad_khanehaye_pacific==2 || tedad_khanehaye_pacific==3) && (tedad_khanehaye_pensilvania==2 || tedad_khanehaye_pensilvania==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=510;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_northcarolina=3;
                       ui->label_164->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_northcarolina==3)
               {
                   if((tedad_khanehaye_pacific==3 || tedad_khanehaye_pacific==4) && (tedad_khanehaye_pensilvania==3 || tedad_khanehaye_pensilvania==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_northcarolina=4;
                       ui->label_164->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان کارولینای شمالی");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 2 شما باید هم مالک  خیابان پاسیفیک و هم خیابان پنسیلوانیا باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }
    else if(index=="خیابان پنسیلوانیا")
    {
        if(name_malek_khiaban_pacific==1 && name_malek_khiaban_northcarolina==1)
        {
            //mitoone khune bezase chon enhesare in rang ro dre

            if(tedad_khanehaye_pensilvania==4)
                QMessageBox::information(this," "," در هر خیابان حداکثر 4 خانه می توانید بسازید!");
            else if(tedad_khanehaye_pensilvania<4)
            {
               if(tedad_khanehaye_pensilvania==0)
               {
                   if((tedad_khanehaye_pacific==0 || tedad_khanehaye_pacific==1) && (tedad_khanehaye_northcarolina==0 || tedad_khanehaye_northcarolina==1))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=150;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pensilvania=1;
                       ui->label_170->setText(QString::number(1));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==1)
               {
                   if((tedad_khanehaye_pacific==1 || tedad_khanehaye_pacific==2) && (tedad_khanehaye_northcarolina==1 || tedad_khanehaye_northcarolina==2))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=300;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pensilvania=2;
                       ui->label_170->setText(QString::number(2));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==2)
               {
                   if((tedad_khanehaye_pacific==2 || tedad_khanehaye_pacific==3) && (tedad_khanehaye_northcarolina==2 || tedad_khanehaye_northcarolina==3))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=550;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pensilvania=3;
                       ui->label_170->setText(QString::number(3));
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
               else if(tedad_khanehaye_pensilvania==3)
               {
                   if((tedad_khanehaye_pacific==3 || tedad_khanehaye_pacific==4) && (tedad_khanehaye_northcarolina==3 || tedad_khanehaye_northcarolina==4))
                   {
                       moneyp2=ui->lineEdit_2->text().toInt();
                       moneyp2-=200;
                       ui->lineEdit_2->setText(QString::number(moneyp2));
                       tedad_khanehaye_pensilvania=4;
                       ui->label_170->setText(QString::number(4));
                       ui->comboBox_64->addItem("خیابان پنسیلوانیا");
                   }
                   else {
                       QMessageBox::warning(this," "," ساخت و ساز خانه ها باید به صورت یکنواخت و به تعداد مساوی باشد!");
                   }
               }
            }

        }
        else
        {
            QMessageBox::information(this," ","بازیکن 1 شما باید هم مالک  خیابان پاسیفیک و هم خیابان کارولینای شمالی باشیدو به اصطلاح انحصار رنگ سبز را داشته باشید تا بتوانید در پاسیفیک و کارولینای شمالی و پنسیلوانیا خانه بسازید لطفا بعد از خرید همه رنگهای سبز تلاش کنید");
        }
    }

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_park_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=350;//gheymate kharide istgah reading
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_park=100;
            name_malek_qale_park=1;
            ui->label_51->show();
            ui->comboBox_20->addItem("قلعه پارک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 قلعه پارک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_35->show();
        } break;
        }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_park_p2(int index)
{

    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=350;//gheymate kharide istgah reading
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_park=100;
            name_malek_qale_park=2;
            ui->label_52->show();
            ui->comboBox_21->addItem("قلعه پارک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 قلعه پارک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_35->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_boardwalk_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=400;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_boardwalk=100;
            name_malek_khiaban_boardwalk=1;
            ui->label_55->show();
            ui->comboBox_20->addItem("خیابان بوردواک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان بوردواک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_38->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_boardwalk_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=400;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_boardwalk=100;
            name_malek_khiaban_boardwalk=2;
            ui->label_56->show();
            ui->comboBox_21->addItem("خیابان بوردواک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان بوردواک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_38->show();
        } break;
        }


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_oriental_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=100;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_oriental=100;
            name_malek_khiaban_oriental=1;
            ui->label_63->show();
            ui->comboBox_20->addItem("خیابان اورینتال");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان اورینتال را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_41->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::select_kharid_ya_mozayede_khiaban_oriental_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=100;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_oriental=100;
            name_malek_khiaban_oriental=2;
            ui->label_64->show();
            ui->comboBox_21->addItem("خیابان اورینتال");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان اورینتال را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_41->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_vermont_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=100;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_vermont=100;
            name_malek_khiaban_vermont=1;
            ui->label_69->show();
            ui->comboBox_20->addItem("خیابان ورمونت");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان ورمونت را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_44->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_vermont_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=100;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_vermont=100;
            name_malek_khiaban_vermont=2;
            ui->label_70->show();
            ui->comboBox_21->addItem("خیابان ورمونت");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان ورمونت را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_44->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_conecticut_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=120;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_conecticut=100;
            name_malek_khiaban_conecticut=1;
            ui->label_75->show();
            ui->comboBox_20->addItem("خیابان کانکتیکات");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان خیابان کانکتیکات را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_47->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_conecticut_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=120;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_conecticut=100;
            name_malek_khiaban_conecticut=2;
            ui->label_76->show();
            ui->comboBox_21->addItem("خیابان کانکتیکات");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان کانکتیکات را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_47->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_charls_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=140;//gheymate kharide
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_charls=100;
            name_malek_qale_charls=1;
            ui->label_81->show();
            ui->comboBox_20->addItem("قلعه چارلز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 قلعه چارلز را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_50->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_charls_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=140;//gheymate kharide istgah reading
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_charls=100;
            name_malek_qale_charls=2;
            ui->label_82->show();
            ui->comboBox_21->addItem("قلعه چارلز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 قلعه چارلز را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_50->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_stats_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=140;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_stats=100;
            name_malek_khiaban_stats=1;
            ui->label_87->show();
            ui->comboBox_20->addItem("خیابان استیتس");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1 خیابان استیتس را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_53->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_stats_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=140;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_stats=100;
            name_malek_khiaban_stats=2;
            ui->label_88->show();
            ui->comboBox_21->addItem("خیابان استیتس");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان استیتس را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_53->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_virginia_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=160;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_virginia=100;
            name_malek_khiaban_virginia=1;
            ui->label_93->show();
            ui->comboBox_20->addItem("خیابان ویرجینیا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان ویرجینیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_56->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_virginia_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=160;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_virginia=100;
            name_malek_khiaban_virginia=2;
            ui->label_94->show();
            ui->comboBox_21->addItem("خیابان ویرجینیا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان ویرجینیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_56->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_jims_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=180;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_jims=100;
            name_malek_qale_jims=1;
            ui->label_99->show();
            ui->comboBox_20->addItem("قلعه جیمز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  قلعه جیمز را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_59->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_qale_jims_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=180;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_jims=100;
            name_malek_qale_jims=2;
            ui->label_100->show();
            ui->comboBox_21->addItem("قلعه جیمز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 قلعه جیمز را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_59->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_tenesi_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=180;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_tenesi=100;
            name_malek_khiaban_tenesi=1;
            ui->label_105->show();
            ui->comboBox_20->addItem("خیابان تنسی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان تنسی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_62->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_tenesi_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=180;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_tenesi=100;
            name_malek_khiaban_tenesi=2;
            ui->label_106->show();
            ui->comboBox_21->addItem("خیابان تنسی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان تنسی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_62->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_newyork_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=200;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_newyork=100;
            name_malek_khiaban_newyork=1;
            ui->label_111->show();
            ui->comboBox_20->addItem("خیابان نیویورک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان نیویورک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_65->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_newyork_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=200;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_newyork=100;
            name_malek_khiaban_newyork=2;
            ui->label_112->show();
            ui->comboBox_21->addItem("خیابان نیویورک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان نیویورک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_65->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_kentucky_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=220;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_kentucky=100;
            name_malek_khiaban_kentucky=1;
            ui->label_117->show();
            ui->comboBox_20->addItem("خیابان کنتاکی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان کنتاکی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_68->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::select_kharid_ya_mozayede_khiaban_kentucky_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=220;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_kentucky=100;
            name_malek_khiaban_kentucky=2;
            ui->label_118->show();
            ui->comboBox_21->addItem("خیابان کنتاکی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان کنتاکی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_68->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_indiana_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=220;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_indiana=100;
            name_malek_khiaban_indiana=1;
            ui->label_123->show();
            ui->comboBox_20->addItem("خیابان ایندیانا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان ایندیانا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_71->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_indiana_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=220;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_indiana=100;
            name_malek_khiaban_indiana=2;
            ui->label_124->show();
            ui->comboBox_21->addItem("خیابان ایندیانا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان ایندیانا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_71->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_ilinois_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=240;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_ilinois=100;
            name_malek_khiaban_ilinois=1;
            ui->label_129->show();
            ui->comboBox_20->addItem("خیابان ایلینویز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان ایلینویز را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_74->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_ilinois_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=240;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_ilinois=100;
            name_malek_khiaban_ilinois=2;
            ui->label_130->show();
            ui->comboBox_21->addItem("خیابان ایلینویز");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان ایلینویزا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_74->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_atlantic_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=260;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_atlantic=100;
            name_malek_khiaban_atlantic=1;
            ui->label_135->show();
            ui->comboBox_20->addItem("خیابان آتلانتیک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان آتلانتیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_77->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_atlantic_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=260;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_atlantic=100;
            name_malek_khiaban_atlantic=2;
            ui->label_136->show();
            ui->comboBox_21->addItem("خیابان آتلانتیک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان آتلانتیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_77->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_ventor_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=260;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_ventor=100;
            name_malek_khiaban_ventor=1;
            ui->label_141->show();
            ui->comboBox_20->addItem("خیابان ونتور");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان ونتور را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_80->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_ventor_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=260;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_ventor=100;
            name_malek_khiaban_ventor=2;
            ui->label_142->show();
            ui->comboBox_21->addItem("خیابان ونتور");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان ونتور را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_80->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_marvin_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=280;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_marvin=100;
            name_malek_khiaban_marvin=1;
            ui->label_147->show();
            ui->comboBox_20->addItem("باغ ماروین");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  باغ ماروین را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_83->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_marvin_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=280;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_marvin=100;
            name_malek_khiaban_marvin=2;
            ui->label_148->show();
            ui->comboBox_21->addItem("باغ ماروین");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 باغ ماروین را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_83->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_pasific_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=300;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_pacific=100;
            name_malek_khiaban_pacific=1;
            ui->label_153->show();
            ui->comboBox_20->addItem("خیابان پاسیفیک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان پاسیفیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_86->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_pacific_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=300;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_pacific=100;
            name_malek_khiaban_pacific=2;
            ui->label_154->show();
            ui->comboBox_21->addItem("خیابان پاسیفیک");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان پاسیفیک را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_86->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_northcarolina_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=300;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_northcarolina=100;
            name_malek_khiaban_northcarolina=1;
            ui->label_159->show();
            ui->comboBox_20->addItem("خیابان کارولینای شمالی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان کارولینای شمالی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_89->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_northcarolina_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=300;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_northcarolina=100;
            name_malek_khiaban_northcarolina=2;
            ui->label_160->show();
            ui->comboBox_21->addItem("خیابان کارولینای شمالی");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان کارولینای شمالی را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_89->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_pensilvania_p1(int index)
{
    double moneyp1;
        switch (index)
        {
        case 0:
        {
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=320;//gheymate kharid
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_pensilvania=100;
            name_malek_khiaban_pensilvania=1;
            ui->label_165->show();
            ui->comboBox_20->addItem("خیابان پنسیلوانیا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 1  خیابان پنسیلوانیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_92->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::select_kharid_ya_mozayede_khiaban_pensilvania_p2(int index)
{
    double moneyp2;
        switch (index)
        {
        case 0:
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=320;//gheymate kharid
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_pensilvania=100;
            name_malek_khiaban_pensilvania=2;
            ui->label_166->show();
            ui->comboBox_21->addItem("خیابان پنسیلوانیا");
        } break;
        case 1:
        {
            QMessageBox::information(this,"مزایده!","بازیکن 2 خیابان پنسیلوانیا را که مالک نداشت را نخرید و بانک آن را به مزایده می گذارد لطفا در کادر ظاهر شده هرکس قیمت پیشنهادی خود را وارد کند");
            ui->groupBox_92->show();
        } break;
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::hotelsazi_p1(QString index)
{
    double moneyp1;

    if(index=="خیابان مدیترانه")
    {
        if(tedad_hotelhaye_meditarane==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_meditarane= 0;
            ui->label_48->setText(QString::number(0));
            moneyp1-=90;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_meditarane=1;
            ui->label_174->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان بالتیک")
    {
        if(tedad_hotelhaye_baltic==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_baltic= 0;
            ui->label_50->setText(QString::number(0));
            moneyp1-=130;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_baltic=1;
            ui->label_176->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه پارک")
    {
        if(tedad_hotelhaye_qale_park==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_qale_park= 0;
            ui->label_60->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_qale_park=1;
            ui->label_178->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان بوردواک")
    {
        if(tedad_hotelhaye_boardwalk==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_boardwalk= 0;
            ui->label_62->setText(QString::number(0));
            moneyp1-=300;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_boardwalk=1;
            ui->label_180->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان اورینتال")
    {
        if(tedad_hotelhaye_oriental==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_oriental= 0;
            ui->label_68->setText(QString::number(0));
            moneyp1-=150;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_oriental=1;
            ui->label_182->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ورمونت")
    {
        if(tedad_hotelhaye_vermont==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_vermont= 0;
            ui->label_74->setText(QString::number(0));
            moneyp1-=150;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_vermont=1;
            ui->label_184->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کانکتیکات")
    {
        if(tedad_hotelhaye_conecticut==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_conecticut= 0;
            ui->label_80->setText(QString::number(0));
            moneyp1-=150;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_conecticut=1;
            ui->label_186->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه چارلز")
    {
        if(tedad_hotelhaye_qale_charls==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_qale_charls= 0;
            ui->label_86->setText(QString::number(0));
            moneyp1-=125;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_qale_charls=1;
            ui->label_188->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان استیتس")
    {
        if(tedad_hotelhaye_stats==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_stats= 0;
            ui->label_92->setText(QString::number(0));
            moneyp1-=125;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_stats=1;
            ui->label_190->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ویرجینیا")
    {
        if(tedad_hotelhaye_virginia==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_virginia= 0;
            ui->label_98->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_virginia=1;
            ui->label_192->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه جیمز")
    {
        if(tedad_hotelhaye_qale_jims==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_qale_jims= 0;
            ui->label_104->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_qale_jims=1;
            ui->label_194->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان تنسی")
    {
        if(tedad_hotelhaye_tenesi==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_tenesi= 0;
            ui->label_110->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_tenesi=1;
            ui->label_196->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان نیویورک")
    {
        if(tedad_hotelhaye_newyork==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_newyork= 0;
            ui->label_116->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_newyork=1;
            ui->label_198->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کنتاکی")
    {
        if(tedad_hotelhaye_kentucky==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_kentucky= 0;
            ui->label_122->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_kentucky=1;
            ui->label_200->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ایندیانا")
    {
        if(tedad_hotelhaye_indiana==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_indiana= 0;
            ui->label_128->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_indiana=1;
            ui->label_202->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ایلینویز")
    {
        if(tedad_hotelhaye_ilinois==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_ilinois= 0;
            ui->label_134->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_ilinois=1;
            ui->label_204->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان آتلانتیک")
    {
        if(tedad_hotelhaye_atlantic==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_atlantic= 0;
            ui->label_140->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_atlantic=1;
            ui->label_206->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ونتور")
    {
        if(tedad_hotelhaye_ventor==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_ventor= 0;
            ui->label_146->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_ventor=1;
            ui->label_208->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="باغ ماروین")
    {
        if(tedad_hotelhaye_marvin==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_marvin= 0;
            ui->label_152->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_marvin=1;
            ui->label_210->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان پاسیفیک")
    {
        if(tedad_hotelhaye_pacific==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_pacific= 0;
            ui->label_158->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_pacific=1;
            ui->label_212->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کارولینای شمالی")
    {
        if(tedad_hotelhaye_northcarolina==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_northcarolina= 0;
            ui->label_164->setText(QString::number(0));
            moneyp1-=175;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_northcarolina=1;
            ui->label_214->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان پنسیلوانیا")
    {
        if(tedad_hotelhaye_pensilvania==0)
        {
            moneyp1=ui->lineEdit->text().toInt();
            tedad_khanehaye_pensilvania= 0;
            ui->label_170->setText(QString::number(0));
            moneyp1-=200;
            ui->lineEdit->setText(QString::number(moneyp1));
            tedad_hotelhaye_pensilvania=1;
            ui->label_216->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::hotelsazi_p2(QString index)
{
    double moneyp2;

    if(index=="خیابان مدیترانه")
    {
        if(tedad_hotelhaye_meditarane==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_meditarane= 0;
            ui->label_48->setText(QString::number(0));
            moneyp2-=90;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_meditarane=1;
            ui->label_174->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان بالتیک")
    {
        if(tedad_hotelhaye_baltic==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_baltic= 0;
            ui->label_50->setText(QString::number(0));
            moneyp2-=130;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_baltic=1;
            ui->label_176->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه پارک")
    {
        if(tedad_hotelhaye_qale_park==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_qale_park= 0;
            ui->label_60->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_qale_park=1;
            ui->label_178->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان بوردواک")
    {
        if(tedad_hotelhaye_boardwalk==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_boardwalk= 0;
            ui->label_62->setText(QString::number(0));
            moneyp2-=300;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_boardwalk=1;
            ui->label_180->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان اورینتال")
    {
        if(tedad_hotelhaye_oriental==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_oriental= 0;
            ui->label_68->setText(QString::number(0));
            moneyp2-=150;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_oriental=1;
            ui->label_182->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ورمونت")
    {
        if(tedad_hotelhaye_vermont==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_vermont= 0;
            ui->label_74->setText(QString::number(0));
            moneyp2-=150;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_vermont=1;
            ui->label_184->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کانکتیکات")
    {
        if(tedad_hotelhaye_conecticut==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_conecticut= 0;
            ui->label_80->setText(QString::number(0));
            moneyp2-=150;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_conecticut=1;
            ui->label_186->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه چارلز")
    {
        if(tedad_hotelhaye_qale_charls==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_qale_charls= 0;
            ui->label_86->setText(QString::number(0));
            moneyp2-=125;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_qale_charls=1;
            ui->label_188->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان استیتس")
    {
        if(tedad_hotelhaye_stats==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_stats= 0;
            ui->label_92->setText(QString::number(0));
            moneyp2-=125;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_stats=1;
            ui->label_190->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ویرجینیا")
    {
        if(tedad_hotelhaye_virginia==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_virginia= 0;
            ui->label_98->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_virginia=1;
            ui->label_192->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="قلعه جیمز")
    {
        if(tedad_hotelhaye_qale_jims==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_qale_jims= 0;
            ui->label_104->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_qale_jims=1;
            ui->label_194->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان تنسی")
    {
        if(tedad_hotelhaye_tenesi==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_tenesi= 0;
            ui->label_110->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_tenesi=1;
            ui->label_196->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان نیویورک")
    {
        if(tedad_hotelhaye_newyork==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_newyork= 0;
            ui->label_116->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_newyork=1;
            ui->label_198->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کنتاکی")
    {
        if(tedad_hotelhaye_kentucky==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_kentucky= 0;
            ui->label_122->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_kentucky=1;
            ui->label_200->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ایندیانا")
    {
        if(tedad_hotelhaye_indiana==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_indiana= 0;
            ui->label_128->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_indiana=1;
            ui->label_202->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ایلینویز")
    {
        if(tedad_hotelhaye_ilinois==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_ilinois= 0;
            ui->label_134->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_ilinois=1;
            ui->label_204->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان آتلانتیک")
    {
        if(tedad_hotelhaye_atlantic==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_atlantic= 0;
            ui->label_140->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_atlantic=1;
            ui->label_206->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان ونتور")
    {
        if(tedad_hotelhaye_ventor==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_ventor= 0;
            ui->label_146->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_ventor=1;
            ui->label_208->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="باغ ماروین")
    {
        if(tedad_hotelhaye_marvin==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_marvin= 0;
            ui->label_152->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_marvin=1;
            ui->label_210->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان پاسیفیک")
    {
        if(tedad_hotelhaye_pacific==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_pacific= 0;
            ui->label_158->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_pacific=1;
            ui->label_212->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان کارولینای شمالی")
    {
        if(tedad_hotelhaye_northcarolina==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_northcarolina= 0;
            ui->label_164->setText(QString::number(0));
            moneyp2-=175;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_northcarolina=1;
            ui->label_214->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
    else if(index=="خیابان پنسیلوانیا")
    {
        if(tedad_hotelhaye_pensilvania==0)
        {
            moneyp2=ui->lineEdit_2->text().toInt();
            tedad_khanehaye_pensilvania= 0;
            ui->label_170->setText(QString::number(0));
            moneyp2-=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            tedad_hotelhaye_pensilvania=1;
            ui->label_216->setText(QString::number(1));
        }
        else {
            QMessageBox::warning(this," ","در هر خیابان مجاز به ساخت حداکثر یک هتل هستید!");
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::see_sanad(int index)
{

    switch (index)
    {
    case 0:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad0.jpg);");
    break;
    case 1:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad1.jpg);");
    break;
    case 2:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad2.jpg);");
    break;
    case 3:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad3.jpg);");
    break;
    case 4:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad4.jpg);");
    break;
    case 5:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad5.jpg);");
    break;
    case 6:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad6.jpg);");
    break;
    case 7:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad7.jpg);");
    break;
    case 8:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad8.jpg);");
    break;
    case 9:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad9.jpg);");
    break;
    case 10:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad10.jpg);");
    break;
    case 11:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad11.jpg);");
    break;
    case 12:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad12.jpg);");
    break;
    case 13:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad13.jpg);");
    break;
    case 14:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad14.jpg);");
    break;
    case 15:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad15.jpg);");
    break;
    case 16:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad16.jpg);");
    break;
    case 17:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad17.jpg);");
    break;
    case 18:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad18.jpg);");
    break;
    case 19:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad19.jpg);");
    break;
    case 20:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad20.jpg);");
    break;
    case 21:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad21.jpg);");
    break;
    case 22:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad22.jpg);");
    break;
    case 23:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad23.jpg);");
    break;
    case 24:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad24.jpg);");
    break;
    case 25:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad25.jpg);");
    break;
    case 26:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad26.jpg);");
    break;
    case 27:
        ui->lblsanad->setStyleSheet("image: url(:/new/prefix1/sanad27.jpg);");
    break;


    }


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::khorojazzendan_p1(int index)
{
    double moneyp1;
    switch (index) {
    case 0:
    {
      moneyp1=ui->lineEdit->text().toInt();
      moneyp1-=50;
      ui->lineEdit->setText(QString::number(moneyp1));
      injail_p1=-1;//az zendan kharej shod
      QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
     ui->groupBox_96->hide();
      ui->tasrizip1_pushButton->setEnabled(true);
    } break;
    case 1:
    {
      if(chancekhorojazzendanp1==1)
      {
          chancekhorojazzendanp1=-1;
          ui->label_218->setText("ندارد");
          injail_p1=-1;
          QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
          ui->groupBox_96->hide();
          ui->tasrizip1_pushButton->setEnabled(true);
      }
      else {
          QMessageBox::warning(this," ","بازیکن 1 شما کارت شانس خروج از زندان ندارید ! راه دیگری را برای خروج از زندان امتحان کنید!");
      }

    }break;
    case 2:
    {
        if(chestkhorojazzendanp1==1)
        {
            chestkhorojazzendanp1=-1;
            ui->label_224->setText("ندارد");
            injail_p1=-1;
            QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
            ui->groupBox_96->hide();
            ui->tasrizip1_pushButton->setEnabled(true);
        }
        else {
            QMessageBox::warning(this," ","بازیکن 1 شما کارت انجمن خروج از زندان ندارید ! راه دیگری را برای خروج از زندان امتحان کنید!");
        }

    }break;
    case 3:
    {
        ui->groupBox_96->hide();
        ui->groupBox_98->show();
    }break;

    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::khorojazzendan_p2(int index)
{
    double moneyp2;
    switch (index) {
    case 0:
    {
      moneyp2=ui->lineEdit_2->text().toInt();
      moneyp2-=50;
      ui->lineEdit_2->setText(QString::number(moneyp2));
      injail_p2=-1;//az zendan kharej shod
      QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
      ui->groupBox_97->hide();
      ui->tasrizip2_pushButton->setEnabled(true);
    } break;
    case 1:
    {
      if(chancekhorojazzendanp2==2)
      {
          chancekhorojazzendanp2=-1;
          ui->label_219->setText("ندارد");
          injail_p2=-1;
          QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
          ui->groupBox_97->hide();
          ui->tasrizip2_pushButton->setEnabled(true);
      }
      else {
          QMessageBox::warning(this," ","بازیکن 2 شما کارت شانس خروج از زندان ندارید ! راه دیگری را برای خروج از زندان امتحان کنید!");
      }

    }break;
    case 2:
    {
        if(chestkhorojazzendanp2==2)
        {
            chestkhorojazzendanp2=-1;
            ui->label_225->setText("ندارد");
           injail_p2=-1;
            QMessageBox::information(this," ", " از زندان  ازاد شدید حالا تاس بریزید!");
            ui->groupBox_97->hide();
            ui->tasrizip1_pushButton->setEnabled(true);
        }
        else {
            QMessageBox::warning(this," ","بازیکن 2 شما کارت انجمن خروج از زندان ندارید ! راه دیگری را برای خروج از زندان امتحان کنید!");
        }

    }break;
    case 3:
    {
        ui->groupBox_97->hide();
        ui->groupBox_99->show();
    }break;

    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::taqire_theme_bazi(int index)
{
    switch (index)
    {
    case 0://theme khakestari
    {
        bazi2nafare::setStyleSheet("background-color: rgb(217, 217, 217);");
    }break;
    case 1://theme sorkhabi
    {
        bazi2nafare::setStyleSheet("background-color: rgb(170, 0, 0);");
    }break;
    case 2://theme ghahvei
    {
        bazi2nafare::setStyleSheet("background-color: rgb(170, 85, 0);");
    }break;
    case 3://theme sabz
    {
        bazi2nafare::setStyleSheet("background-color: rgb(170, 255, 0);");
    }break;
    case 4://theme banafsh
    {
        bazi2nafare::setStyleSheet("background-color: rgb(170, 85, 127);");
    }break;
    case 5://theme sorkhabi
    {
        bazi2nafare::setStyleSheet("background-color: rgb(170, 170, 127);");
    }break;
    case 6://theme soorati
    {
        bazi2nafare::setStyleSheet("background-color: rgb(255, 0, 0);");
    }break;
    case 7://theme narenji
    {
        bazi2nafare::setStyleSheet("background-color: rgb(255, 85, 0);");
    }break;
    case 8://theme zard
    {
        bazi2nafare::setStyleSheet("background-color: rgb(255, 255, 0);");
    }break;
    case 9://theme abi kam hal
    {
        bazi2nafare::setStyleSheet("background-color: rgb(157, 213, 255);");
    }break;

    case 10://theme pish farz
    {
        bazi2nafare::setStyleSheet("");
    }break;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::on_start_pushButton_clicked()
{

    ui->mohrep1->show();
    ui->mohrep2->show();


    int d11, d12, fd1, d21, d22, fd2;



        d11 =(rand()%6)+1;
        d12 =(rand()%6)+1;

        d21 =(rand()%6)+1;
        d22 =(rand()%6)+1;

        fd1 = d11 + d12;
        fd2 = d21 + d22;
      //image: url(:/new/prefix1/dice1.bmp);

       // url11 = ;
        ui->lbl11->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d11) + ".bmp);");

        /////

        //url12 = ;
        ui->lbl12->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d12) + ".bmp);");


         /////


        //url21 = ;
        ui->lbl21->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d21) + ".bmp);");

        /////


        //url22 = ;
        ui->lbl22->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d22) + ".bmp);");



           if(fd1>fd2)
           {
            ui->start_pushButton->hide(); //bara inke bade shoroe bazi dige in button ro hei click nkne o beham berizash
            QMessageBox::information(this,"نوبت کیست ؟","بازیکن 1 مجموع دوتاس شما بیشتر شده پس شما شروع کنید!");
            ui->tasrizip1_pushButton->setEnabled(true);
           }
           if(fd2>fd1)
           {
            ui->start_pushButton->hide(); //bara inke bade shoroe bazi dige in button ro hei click nkne o beham berizash
            QMessageBox::information(this,"نوبت کیست ؟","بازیکن 2 مجموع دو تاس شما بیشتر شده پس شما شروع کنید");
            ui->tasrizip2_pushButton->setEnabled(true);
           }
           if(fd1==fd2)
           {
            QMessageBox::information(this,"نوبت کیست ؟","مجموع دوتاس هردویتان برابر شده دوباره روی شروع بازی کلیک کنید");
           }

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::on_tasrizip1_pushButton_clicked()
{
    int moneyp1;

    int d11, d12, fd1;
    d11 =(rand()%6)+1;
    d12 =(rand()%6)+1;
    fd1 = d11 + d12;
    ui->lbl11->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d11) + ".bmp);");
    ui->lbl12->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d12) + ".bmp);");
    ui->tasrizip1_pushButton->setEnabled(false);
    if(d11==d12&&tasdoobl1==2)
    {
        QMessageBox::warning(this,"هشدار","بار سومه که جفت تاس اوردی و خطری هستی پس میری زندان");
        ui->mohrep1->move(60,660);
        cel1=10;
        tasdoobl1=0;
        ui->tasrizip2_pushButton->setEnabled(true);
    }
    else {


        if((cel1+fd1)<=39)
        {
            ob1.player[0]=ob1.definecell[cel1+fd1];
            //move kone
            int x, y;
            x = ob1.find_x_mokhtasat(ob1.definecell[cel1+fd1]);
            y = ob1.find_y_mokhtasat(ob1.definecell[cel1+fd1]);
            ui->mohrep1->move(x,y);//x => x maghsad  y => y maghsad
            cel1+=fd1;
            f(ob1.player[0],1);
        }
        else if((cel1+fd1)>=40)
        {
            cel1 = ((cel1+fd1)%40);
            ob1.player[0]=ob1.definecell[cel1];
            //move kone
            int x, y;
            x = ob1.find_x_mokhtasat(ob1.definecell[cel1]);
            y = ob1.find_y_mokhtasat(ob1.definecell[cel1]);
            ui->mohrep1->move(x,y);//x => x maghsad  y => y maghsad
            f(ob1.player[0],1);


            QMessageBox::information(this,"خبر خوش","بازیکن 1 شما خانه ی  go را رد کرده اید یا روی آن هستید پس 200 دلار به حساب شما واریز شد .");
            //bia be bankesh 200 dolar ezafe kon chon reside be go ya az go rad shde

            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1+=200;
            ui->lineEdit->setText(QString::number(moneyp1));

            ui->pushButton->click();


        }

       // az akhare akhar :
        if(d11==d12)//joft tas
        {
            tasdoobl1++;
            QMessageBox::information(this,"خوش خبری!" ," جفت تاس آورده اید پس باز هم نوبت شماست تا تاس بریزید!");
            ui->tasrizip1_pushButton->setEnabled(true);
        }
        else {
            // inja age p2 dar zendan bud aval azad she o baz push buttonesh faal shee
            if(injail_p2==2)
            {
                QMessageBox::warning(this," ","بازیکن 2 شما در زندانید اول ازاد شید بعد تاس بریزید در باکس ظاهر شده انتخاب کنید می خواهید چطور ازاد شوید ");
                ui->groupBox_97->show();
            }
           else{

                ui->tasrizip2_pushButton->setEnabled(true);
            }
        }
    }

    tasdoobl2=0; //bara inke age bara p2 ghbalan 2 shode alan doobl omad nare zendan

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::on_tasrizip2_pushButton_clicked()
{

    int moneyp2;
    int d21, d22, fd2;
    d21 =(rand()%6)+1;
    d22 =(rand()%6)+1;
    fd2 = d21 + d22;
    ui->lbl21->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d21) + ".bmp);");
    ui->lbl22->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(d22) + ".bmp);");
    ui->tasrizip2_pushButton->setEnabled(false);


    if(d21==d22&&tasdoobl2==2)
    {
        QMessageBox::warning(this,"هشدار","بار سومه که جفت تاس اوردی و خطری هستی پس میری زندان");
        ui->mohrep2->move(60,660);
        cel2=10;
        tasdoobl2=0;
        ui->tasrizip1_pushButton->setEnabled(true);
    }
    else {


        if((cel2+fd2)<=39)
        {
            ob2.player[1]=ob2.definecell[cel2+fd2];
            //move kone
            int x, y;
            x = ob2.find_x_mokhtasat(ob2.definecell[cel2+fd2]);
            y = ob2.find_y_mokhtasat(ob2.definecell[cel2+fd2]);
            ui->mohrep2->move(x,y);//x => x maghsad  y => y maghsad
            cel2+=fd2;
            f(ob2.player[1],2);
        }
        else if((cel2+fd2)>=40)
        {
            cel2 = ((cel2+fd2)%40);
            ob2.player[1]=ob2.definecell[cel2];
            //move kone
            int x, y;
            x = ob2.find_x_mokhtasat(ob2.definecell[cel2]);
            y = ob2.find_y_mokhtasat(ob2.definecell[cel2]);
            ui->mohrep2->move(x,y);//x => x maghsad  y => y maghsad
            f(ob2.player[1],2);
            //bia be bankesh 200 dolar ezafe kon chon reside be go ya az go rad shde

            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2+=200;
            ui->lineEdit_2->setText(QString::number(moneyp2));

            QMessageBox::information(this,"خبر خوش","بازیکن 2 شما خانه ی  go را رد کرده اید یا روی آن هستید پس 200 دلار به حساب شما واریز شد .");

            ui->pushButton->click();


        }

       // az akhare akhar :
        if(d21==d22)//joft tas
        {
            tasdoobl2++;
            QMessageBox::information(this,"خوش خبری!" ," جفت تاس آورده اید پس باز هم نوبت شماست تا تاس بریزید!");
            ui->tasrizip2_pushButton->setEnabled(true);
        }
        else {
            // inja age p1 dar zendan bud aval azad she o baz push buttonesh faal shee
            if(injail_p1==1)
            {
                QMessageBox::warning(this," ","بازیکن 1 شما در زندانید اول ازاد شید بعد تاس بریزید در باکس ظاهر شده انتخاب کنید می خواهید چطور ازاد شوید ");
                ui->groupBox_96->show();
            }
            else
            {
                 ui->tasrizip1_pushButton->setEnabled(true);
            }

        }
    }


    tasdoobl1=0; //bara inke age bara p1 ghbalan 2 shode ya 1 alan doobl omad nare zendan o az harekate ghablsh mostql bashe
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::f(QString c, int j)
{
    //QString kartexitjail="";
    double moneyp1, moneyp2;
    int tas;
    cells ob;
    /*if(c==ob.definecell[0])*/
     ///////////////////////////////////////////////////////////////////////////////////
    if (c==ob.definecell[1])// khiabane meditarane
    {
        if(j==1)
        {
            if(malek_khiaban_meditarane==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان مدیترانه","خیابان مدیترانه مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_26->show();
            }
            else if(malek_khiaban_meditarane==100)// khiaban malek drd
            {
                if(name_malek_khiaban_meditarane==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_meditarane==0 && tedad_hotelhaye_meditarane==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_meditarane>0 && tedad_hotelhaye_meditarane==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_meditarane*50;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_meditarane==0 && tedad_hotelhaye_meditarane>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_meditarane*50) + (tedad_hotelhaye_meditarane* 4*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_meditarane>0 && tedad_hotelhaye_meditarane>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_meditarane*50) + (tedad_hotelhaye_meditarane* 4*50) + (tedad_khanehaye_meditarane*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_meditarane==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_baltic!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ قهوه ای همین یک خیابان را دارد و مالکیت بالتیک را هنوز کسب نکرده پس 2 دلار جریمه بدهید");

                        moneyp1-=2;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_baltic==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ قهوه ای را دارد یعنی هم مالک مدیترانه است و هم بالتیک پس 4 دلار جریمه بدهید");

                        moneyp1-=4;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_meditarane==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان مدیترانه","خیابان مدیترانه مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_27->show();
            }
            else if(malek_khiaban_meditarane==100)//khiaban malek drd
            {
                if(name_malek_khiaban_meditarane==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_meditarane==0 && tedad_hotelhaye_meditarane==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_meditarane>0 && tedad_hotelhaye_meditarane==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_meditarane*50;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_meditarane==0 && tedad_hotelhaye_meditarane>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_meditarane*50) + (tedad_hotelhaye_meditarane* 4*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_meditarane>0 && tedad_hotelhaye_meditarane>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_meditarane*50) + (tedad_hotelhaye_meditarane*4*50) + (tedad_khanehaye_meditarane*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_meditarane==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_baltic!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ قهوه ای همین یک خیابان را دارد و مالکیت بالتیک را هنوز کسب نکرده پس 2 دلار جریمه بدهید");

                        moneyp2-=2;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_baltic==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ قهوه ای را دارد یعنی هم مالک مدیترانه است و هم بالتیک پس 4 دلار جریمه بدهید");

                        moneyp2-=4;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////
    if (c==ob.definecell[2]) //community chest
    {
        QMessageBox::information(this,"کارت انجمنتو امتحان کن!","اگه بازیکن 1 هستی یا2  تایپ کن 1 یا تایپ کن 2 و بعد روی کارت انجمن خود را امتحان کنید بزنید");
        ui->groupBox_4->setEnabled(true);
    }
    ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[3]) //khiabane baltic
    {
        if(j==1)
        {
            if(malek_khiaban_baltic==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان بالتیک","خیابان بالتیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_29->show();
            }
            else if(malek_khiaban_baltic==100)// khiaban malek drd
            {
                if(name_malek_khiaban_baltic==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_baltic==0 && tedad_hotelhaye_baltic==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_baltic>0 && tedad_hotelhaye_baltic==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_baltic*50;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_baltic==0 && tedad_hotelhaye_baltic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_baltic*50) + (tedad_hotelhaye_baltic* 4*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_baltic>0 && tedad_hotelhaye_baltic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_baltic*50) + (tedad_hotelhaye_baltic* 4*50) + (tedad_khanehaye_baltic*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_baltic==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_meditarane!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ قهوه ای همین یک خیابان را دارد و مالکیت مدیترانه را هنوز کسب نکرده پس 4 دلار جریمه بدهید");

                        moneyp1-=4;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_meditarane==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ قهوه ای را دارد یعنی هم مالک مدیترانه است و هم بالتیک پس 8 دلار جریمه بدهید");

                        moneyp1-=8;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_baltic==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان بالتیک","خیابان بالتیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_30->show();
            }
            else if(malek_khiaban_baltic==100)//khiaban malek drd
            {
                if(name_malek_khiaban_baltic==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_baltic==0 && tedad_hotelhaye_baltic==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_baltic>0 && tedad_hotelhaye_baltic==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_baltic*50;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_baltic==0 && tedad_hotelhaye_baltic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_baltic*50) + (tedad_hotelhaye_baltic* 4*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_baltic>0 && tedad_hotelhaye_baltic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_baltic*50) + (tedad_hotelhaye_baltic* 4*50) + (tedad_khanehaye_baltic*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_baltic==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_meditarane!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ قهوه ای همین یک خیابان را دارد و مالکیت مدیترانه را هنوز کسب نکرده پس 4 دلار جریمه بدهید");

                        moneyp2-=4;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_meditarane==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ قهوه ای را دارد یعنی هم مالک مدیترانه است و هم بالتیک پس 8 دلار جریمه بدهید");

                        moneyp2-=8;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[4])//دریافت مالیات همان income tax
    {
        QMessageBox::information(this,"دریافت مالیات","در منویی که باز شده انتخاب کنید که 200 دلار می دهید و یا 10 درصد از سرمایه تان را!");
        if(j==1)
            ui->groupBox_5->show();
        else if(j==2)
            ui->groupBox_6->show();

    }
    ///////////////////////////////////////////////////////////////////////////////////
   else if (c==ob.definecell[5]) //istgah reading
    {

        if(j==1)
        {
            if(malek_istgah_reading==99)//yani istgahe reading malek ndre
            {
                QMessageBox::information(this,"ایستگاه ردینگ","ایستگاه ردینگ مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_13->show();
            }
            else if(malek_istgah_reading==100)//yani istgahe reading malek dre
            {
                if(name_malek_istgah_reading==1) //sud migiram
                {
           //1
                    if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah drm ooon setaye dg male mn nis
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=25;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //2
                    else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah drm reding o pensilvania
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah drm reading o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if((name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1))//2 ta istgah drm reading o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //3
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline!=1) //3ta istgah drm reading o pensilvania o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_shortline==1 && name_malek_istgah_bo!=1)//3ta istgah drm reading o pensilvania o short line
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1)//3ta istgah drm reading o bo o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //4
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=200;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                else if(name_malek_istgah_reading==2)//zarar midam
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=25;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline!=2) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_shortline==2 && name_malek_istgah_bo!=2)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=100;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                }
            }
        }
       ////////////////////////////////////
        else if(j==2)
        {
            if(malek_istgah_reading==99)
            {
                QMessageBox::information(this,"ایستگاه ردینگ","ایستگاه ردینگ مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_14->show();
            }
            else if(malek_istgah_reading==100)
            {
                if(name_malek_istgah_reading==2) //sud bgire
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah drm ooon setaye dg male mn nis
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah drm reding o pensilvania
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah drm reading o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2))//2 ta istgah drm reading o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline!=2) //3ta istgah drm reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_shortline==2 && name_malek_istgah_bo!=2)//3ta istgah drm reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2)//3ta istgah drm reading o bo o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=200;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
                else if(name_malek_istgah_reading==1)// zarar bede
                {
                    //1
                             if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline!=1) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_shortline==1 && name_malek_istgah_bo!=1)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
            }
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[6]) //oriental
    {
        if(j==1)
        {
            if(malek_khiaban_oriental==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان اورینتال","خیابان اورینتال مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_39->show();
            }
            else if(malek_khiaban_oriental==100)// khiaban malek drd
            {
                if(name_malek_khiaban_oriental==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_oriental==0 && tedad_hotelhaye_oriental==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_oriental>0 && tedad_hotelhaye_oriental==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_oriental*50;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_oriental==0 && tedad_hotelhaye_oriental>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_oriental*50) + (tedad_hotelhaye_oriental* 4*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_oriental>0 && tedad_hotelhaye_oriental>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_oriental*50) + (tedad_hotelhaye_oriental* 4*50) + (tedad_khanehaye_oriental*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_oriental==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_vermont!=2 || name_malek_khiaban_conecticut!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ یاسی همین یک خیابان را دارد و مالکیت ورمونت و یا کانکتیکات یا هردو را هنوز کسب نکرده پس 6 دلار جریمه بدهید");

                        moneyp1-=6;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_vermont==2 && name_malek_khiaban_conecticut==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ یاسی را دارد یعنی هم مالک ورمونت است و هم کانکتیکات پس 12 دلار جریمه بدهید");

                        moneyp1-=12;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_oriental==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان اورینتال","خیابان اورینتال مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_40->show();
            }
            else if(malek_khiaban_oriental==100)//khiaban malek drd
            {
                if(name_malek_khiaban_oriental==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_oriental==0 && tedad_hotelhaye_oriental==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_oriental>0 && tedad_hotelhaye_oriental==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_oriental*50;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_oriental==0 && tedad_hotelhaye_oriental>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_oriental*50) + (tedad_hotelhaye_oriental* 4*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_oriental>0 && tedad_hotelhaye_oriental>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_oriental*50) + (tedad_hotelhaye_oriental*4*50) + (tedad_khanehaye_oriental*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_oriental==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_vermont!=1 || name_malek_khiaban_conecticut!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ یاسی همین یک خیابان را دارد و هنوز مالکیت ورمونت و یا کانکتیکات یا هردو را هنوز کسب نکرده پس 6 دلار جریمه بدهید");

                        moneyp2-=6;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_vermont==1 && name_malek_khiaban_conecticut==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ یاسی را دارد یعنی هم مالک ورمونت  است و هم کانکتیکات پس 12 دلار جریمه بدهید");

                        moneyp2-=12;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[7]) //chance
    {
        QMessageBox::information(this,"شانستو امتحان کن !","اگه بازیکن 1 هستی یا2  تایپ کن 1 یا تایپ کن 2 و بعد روی شانس خود را امتحان کنید بزنید");
        ui->groupBox_3->setEnabled(true);

    }
     ///////////////////////////////////////////////////////////////////////////////////

    else if (c==ob.definecell[8]) //vermont
    {
        if(j==1)
        {
            if(malek_khiaban_vermont==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان ورمونت","خیابان ورمونت مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_42->show();
            }
            else if(malek_khiaban_vermont==100)// khiaban malek drd
            {
                if(name_malek_khiaban_vermont==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_vermont==0 && tedad_hotelhaye_vermont==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_vermont>0 && tedad_hotelhaye_vermont==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_vermont*50;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_vermont==0 && tedad_hotelhaye_vermont>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_vermont*50) + (tedad_hotelhaye_vermont* 4*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_vermont>0 && tedad_hotelhaye_vermont>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_vermont*50) + (tedad_hotelhaye_vermont* 4*50) + (tedad_khanehaye_vermont*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_vermont==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_oriental!=2 || name_malek_khiaban_conecticut!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ یاسی همین یک خیابان را دارد و مالکیت اورینتال و یا کانکتیکات یا هردو را هنوز کسب نکرده پس 6 دلار جریمه بدهید");

                        moneyp1-=6;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_oriental==2 && name_malek_khiaban_conecticut==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ یاسی را دارد یعنی هم مالک اورینتال است و هم کانکتیکات پس 12 دلار جریمه بدهید");

                        moneyp1-=12;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_vermont==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان ورمونت","خیابان ورمونت مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_43->show();
            }
            else if(malek_khiaban_vermont==100)//khiaban malek drd
            {
                if(name_malek_khiaban_vermont==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_vermont==0 && tedad_hotelhaye_vermont==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_vermont>0 && tedad_hotelhaye_vermont==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_vermont*50;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_vermont==0 && tedad_hotelhaye_vermont>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_vermont*50) + (tedad_hotelhaye_vermont* 4*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_vermont>0 && tedad_hotelhaye_vermont>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_vermont*50) + (tedad_hotelhaye_vermont*4*50) + (tedad_khanehaye_vermont*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_vermont==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_oriental!=1 || name_malek_khiaban_conecticut!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ یاسی همین یک خیابان را دارد و هنوز مالکیت اورینتال و یا کانکتیکات یا هردو را هنوز کسب نکرده پس 6 دلار جریمه بدهید");

                        moneyp2-=6;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_oriental==1 && name_malek_khiaban_conecticut==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ یاسی را دارد یعنی هم مالک اورینتال است و هم کانکتیکات پس 12 دلار جریمه بدهید");

                        moneyp2-=12;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
    /////////////////////////////////////////////////////////////////////////++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if (c==ob.definecell[9]) //conecticut
    {
        if(j==1)
        {
            if(malek_khiaban_conecticut==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان کانکتیکات","خیابان کانکتیکات مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_45->show();
            }
            else if(malek_khiaban_conecticut==100)// khiaban malek drd
            {
                if(name_malek_khiaban_conecticut==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_conecticut==0 && tedad_hotelhaye_conecticut==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_conecticut>0 && tedad_hotelhaye_conecticut==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_conecticut*50;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_conecticut==0 && tedad_hotelhaye_conecticut>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_conecticut*50) + (tedad_hotelhaye_conecticut* 4*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_conecticut>0 && tedad_hotelhaye_conecticut>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_conecticut*50) + (tedad_hotelhaye_conecticut* 4*50) + (tedad_khanehaye_conecticut*50));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_conecticut==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_oriental!=2 || name_malek_khiaban_vermont!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ یاسی همین یک خیابان را دارد و مالکیت اورینتال و یا ورمونت یا هردو را هنوز کسب نکرده پس 8 دلار جریمه بدهید");

                        moneyp1-=8;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_oriental==2 && name_malek_khiaban_vermont==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ یاسی را دارد یعنی هم مالک اورینتال است و هم ورمونت پس 16 دلار جریمه بدهید");

                        moneyp1-=16;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_conecticut==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان کانکتیکات","خیابان کانکتیکات مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_46->show();
            }
            else if(malek_khiaban_conecticut==100)//khiaban malek drd
            {
                if(name_malek_khiaban_conecticut==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_conecticut==0 && tedad_hotelhaye_conecticut==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_conecticut>0 && tedad_hotelhaye_conecticut==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_conecticut*50;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_conecticut==0 && tedad_hotelhaye_conecticut>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_conecticut*50) + (tedad_hotelhaye_conecticut* 4*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_conecticut>0 && tedad_hotelhaye_conecticut>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_conecticut*50) + (tedad_hotelhaye_conecticut*4*50) + (tedad_khanehaye_conecticut*50));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_conecticut==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_oriental!=1 || name_malek_khiaban_vermont!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ یاسی همین یک خیابان را دارد و هنوز مالکیت اورینتال و یا ورمونت یا هردو را هنوز کسب نکرده پس 8 دلار جریمه بدهید");

                        moneyp2-=8;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_vermont==1 && name_malek_khiaban_oriental==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ یاسی را دارد یعنی هم مالک اورینتال است و هم ورمونت پس 16 دلار جریمه بدهید");

                        moneyp2-=16;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

     /////////////////////////////////////////////////////////////////////////++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /*else if(c==ob.definecell[10])
    {

    }*/ // inja etefaqi nmiofte moqe tas rizi bayad barresi she
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[11]) //qale charls
    {
        if(j==1)
        {
            if(malek_qale_charls==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"قلعه چارلز","قلعه چارلز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_48->show();
            }
            else if(malek_qale_charls==100)// khiaban malek drd
            {
                if(name_malek_qale_charls==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_qale_charls==0 && tedad_hotelhaye_qale_charls==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_charls>0 && tedad_hotelhaye_qale_charls==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_qale_charls*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_charls==0 && tedad_hotelhaye_qale_charls>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_charls*100) + (tedad_hotelhaye_qale_charls* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_charls>0 && tedad_hotelhaye_qale_charls>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_charls*100) + (tedad_hotelhaye_qale_charls* 4*100) + (tedad_khanehaye_qale_charls*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_qale_charls==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_stats!=2 || name_malek_khiaban_virginia!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ صورتی همین یک خیابان را دارد و مالکیت استیتس و یا ویرجینیا یا هردو را هنوز کسب نکرده پس 10 دلار جریمه بدهید");

                        moneyp1-=10;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_stats==2 && name_malek_khiaban_virginia==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ صورتی را دارد یعنی هم مالک استیتس است و هم ویرجینیا پس 20 دلار جریمه بدهید");

                        moneyp1-=20;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_qale_charls==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"قلعه چارلز","قلعه چارلز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_49->show();
            }
            else if(malek_qale_charls==100)//khiaban malek drd
            {
                if(name_malek_qale_charls==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_qale_charls==0 && tedad_hotelhaye_qale_charls==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_charls>0 && tedad_hotelhaye_qale_charls==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_qale_charls*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_charls==0 && tedad_hotelhaye_qale_charls>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_charls*100) + (tedad_hotelhaye_qale_charls* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_charls>0 && tedad_hotelhaye_qale_charls>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_charls*100) + (tedad_hotelhaye_qale_charls*4*100) + (tedad_khanehaye_qale_charls*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_qale_charls==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_stats!=1 || name_malek_khiaban_virginia!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ صورتی همین یک خیابان را دارد و هنوز مالکیت استیتس و یا ویرجینیا یا هردو را هنوز کسب نکرده پس 10 دلار جریمه بدهید");

                        moneyp2-=10;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_stats==1 && name_malek_khiaban_virginia==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ صورتی را دارد یعنی هم مالک استیتس است و هم ویرجینیا پس 20 دلار جریمه بدهید");

                        moneyp2-=20;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[12]) //sherkate bargh
    {
        if(j==1)
        {
            if(malek_sherkate_bargh==99) // yani sherkate bargh malek nadare pas mishe malekesh shd ya be mozayede gozasht
            {
                QMessageBox::information(this,"شرکت برق!","شرکت برق مالک ندارد انتخاب کنید که می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_7->show();
            }
            else if(malek_sherkate_bargh==100)//yani sherkate bargh malek dre age p1 malekeshe sud bgire age p2 malekeshe sud bede b p2
            {
                /*if(name_maleke_bargh==1)//yani mohre1 varede sherkate barghi shde k malekesh khdshe pas poolash ziad mishe
                {

                }*/ //ino az ostad porsidam bad biam virayesh knm ya nknm
                if(name_maleke_bargh==2)//yani mohre1 varede sherkate barghi shde k malekesh player 2 hast pas vorood gheire mojaz dashte o bayad jarime bede b player2
                {
                    QMessageBox::warning(this,"ورود غیر مجازی به شرکت برق!","بازیکن 1 شما ورود غیر مجازی به شرکت برقی که مملوک بازیکن 2 هست داشته اید پس باید جریمه بدهید");
                    tas = (rand()%6)+1;
                    ui->label_13->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(tas) + ".bmp);");
                    ui->label_13->show();
                    //tas rikhte she o namayesh dade bshe
                    if(name_maleke_ab==2)//player 2 maleke sherkate ab ham bashe
                    {
                        QMessageBox::information(this,"","بازیکن 2 علاوه بر شرکت برق، مالک شرکت آب هم هست پش 10 برابر عدد تاس باید جریمه بدهید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=(10*tas);
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_maleke_ab!=2)//player 2 maleke sherkate ab nabashe
                    {
                        QMessageBox::information(this,"","بازیکن 2 فقط مالک شرکت برق هست پش 4 برابر عدد تاس باید جریمه بدهید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=(4*tas);
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }

            }
        }
        else if(j==2)
        {
            if(malek_sherkate_bargh==99) // yani sherkate bargh malek nadare pas mishe malekesh shd ya be mozayede gozasht
            {
                QMessageBox::information(this,"شرکت برق!","شرکت برق مالک ندارد انتخاب کنید که می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_8->show();
            }
            else if(malek_sherkate_bargh==100)//yani sherkate bargh malek dre age p2 malekeshe sud bgire age p1 malekeshe sud bede b p1
            {
                /*if(name_maleke_bargh==2)//yani mohre2 varede sherkate barghi shde k malekesh khdshe pas poolash ziad mishe
                {

                }*/ //ino az ostad porsidam bad biam virayesh knm ya nknm
                if(name_maleke_bargh==1)//yani mohre2 varede sherkate barghi shde k malekesh player 1 hast pas vorood gheire mojaz dashte o bayad jarime bede b player1
                {
                    QMessageBox::warning(this,"ورود غیر مجازی به شرکت برق!","بازیکن 2 شما ورود غیر مجازی به شرکت برقی که مملوک بازیکن 1 هست داشته اید پس باید جریمه بدهید");
                    tas = (rand()%6)+1;
                    //namayeshe tas
                    ui->label_13->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(tas) + ".bmp);");
                    ui->label_13->show();
                    if(name_maleke_ab==1)//player 1 maleke sherkate ab ham bashe
                    {
                        QMessageBox::information(this,"","بازیکن 1 علاوه بر شرکت برق، مالک شرکت آب هم هست پش 10 برابر عدد تاس باید جریمه بدهید");
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=(10*tas);
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                    else if(name_maleke_ab!=1)//player 1 maleke sherkate ab ham nabashe
                    {
                        QMessageBox::information(this,"","بازیکن 1 فقط مالک شرکت برق هست پش 4 برابر عدد تاس باید جریمه بدهید");
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=(4*tas);
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    else if (c==ob.definecell[13]) //states
    {
        if(j==1)
        {
            if(malek_khiaban_stats==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان استیتس","خیابان استیتس مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_51->show();
            }
            else if(malek_khiaban_stats==100)// khiaban malek drd
            {
                if(name_malek_khiaban_stats==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_stats==0 && tedad_hotelhaye_stats==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_stats>0 && tedad_hotelhaye_stats==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_stats*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_stats==0 && tedad_hotelhaye_stats>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_stats*100) + (tedad_hotelhaye_stats* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_stats>0 && tedad_hotelhaye_stats>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_stats*100) + (tedad_hotelhaye_stats* 4*100) + (tedad_khanehaye_stats*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_stats==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_qale_charls!=2 || name_malek_khiaban_virginia!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ صورتی همین یک خیابان را دارد و مالکیت قلعه چارلز و یا ویرجینیا یا هردو را هنوز کسب نکرده پس 10 دلار جریمه بدهید");

                        moneyp1-=10;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_qale_charls==2 && name_malek_khiaban_virginia==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ صورتی را دارد یعنی هم مالک قلعه چارلز است و هم ویرجینیا پس 20 دلار جریمه بدهید");

                        moneyp1-=20;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_stats==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان استیتس","خیابان استیتس مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_52->show();
            }
            else if(malek_khiaban_stats==100)//khiaban malek drd
            {
                if(name_malek_khiaban_stats==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_stats==0 && tedad_hotelhaye_stats==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_stats>0 && tedad_hotelhaye_stats==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_stats*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_stats==0 && tedad_hotelhaye_stats>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_stats*100) + (tedad_hotelhaye_stats* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_stats>0 && tedad_hotelhaye_stats>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_stats*100) + (tedad_hotelhaye_stats*4*100) + (tedad_khanehaye_stats*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_stats==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_qale_charls!=1 || name_malek_khiaban_virginia!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ صورتی همین یک خیابان را دارد و هنوز مالکیت قلعه چارلز و یا ویرجینیا یا هردو را هنوز کسب نکرده پس 10 دلار جریمه بدهید");

                        moneyp2-=10;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_qale_charls==1 && name_malek_khiaban_virginia==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ صورتی را دارد یعنی هم مالک چارلز است و هم ویرجینیا پس 20 دلار جریمه بدهید");

                        moneyp2-=20;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   else if (c==ob.definecell[14]) //virginia
    {
        if(j==1)
        {
            if(malek_khiaban_virginia==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان ویرجینیا","خیابان ویرجینیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_54->show();
            }
            else if(malek_khiaban_virginia==100)// khiaban malek drd
            {
                if(name_malek_khiaban_virginia==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_virginia==0 && tedad_hotelhaye_virginia==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_virginia>0 && tedad_hotelhaye_virginia==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_virginia*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_virginia==0 && tedad_hotelhaye_virginia>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_virginia*100) + (tedad_hotelhaye_virginia* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_virginia>0 && tedad_hotelhaye_virginia>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_virginia*100) + (tedad_hotelhaye_virginia* 4*100) + (tedad_khanehaye_virginia*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_virginia==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_qale_charls!=2 || name_malek_khiaban_stats!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ صورتی همین یک خیابان را دارد و مالکیت قلعه چارلز و یا استیتس یا هردو را هنوز کسب نکرده پس 12 دلار جریمه بدهید");

                        moneyp1-=12;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_qale_charls==2 && name_malek_khiaban_stats==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ صورتی را دارد یعنی هم مالک قلعه چارلز است و هم استیتس پس 24 دلار جریمه بدهید");

                        moneyp1-=24;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_virginia==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان ویرجینیا","خیابان ویرجینیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_55->show();
            }
            else if(malek_khiaban_virginia==100)//khiaban malek drd
            {
                if(name_malek_khiaban_virginia==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_virginia==0 && tedad_hotelhaye_virginia==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_virginia>0 && tedad_hotelhaye_virginia==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_virginia*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_virginia==0 && tedad_hotelhaye_virginia>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_virginia*100) + (tedad_hotelhaye_virginia* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_virginia>0 && tedad_hotelhaye_virginia>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_virginia*100) + (tedad_hotelhaye_virginia*4*100) + (tedad_khanehaye_virginia*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_virginia==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_qale_charls!=1 || name_malek_khiaban_stats!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ صورتی همین یک خیابان را دارد و هنوز مالکیت قلعه چارلز و یا استیتس یا هردو را هنوز کسب نکرده پس 12 دلار جریمه بدهید");

                        moneyp2-=12;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_qale_charls==1 && name_malek_khiaban_stats==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ صورتی را دارد یعنی هم مالک چارلز است و هم استیتس پس 24 دلار جریمه بدهید");

                        moneyp2-=24;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[15]) //isgahe pensilvania
    {
        if(j==1)
        {
            if(malek_istgah_pensilvania==99)//yani istgahe pensilvania malek ndre
            {
                QMessageBox::information(this,"ایستگاه پنسیلوانیا","ایستگاه پنسیلوانیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_16->show();
            }
            else if(malek_istgah_pensilvania==100)//yani istgahe pensilvania malek dre
            {
                if(name_malek_istgah_pensilvania==1) //sud migiram
                {
           //1
                    if(name_malek_istgah_reading!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah drm ooon setaye dg male mn nis
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=25;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //2
                    else if((name_malek_istgah_reading==1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah drm reding o pensilvania
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah drm reading o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if((name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1 && name_malek_istgah_bo!=1))//2 ta istgah drm reading o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //3
                    else if(name_malek_istgah_reading==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline!=1) //3ta istgah drm reading o pensilvania o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ و بی اند او  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_reading==1 && name_malek_istgah_shortline==1 && name_malek_istgah_bo!=1)//3ta istgah drm reading o pensilvania o short line
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1)//3ta istgah drm reading o bo o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //4
                    else if(name_malek_istgah_reading==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ بی اند او و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=200;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                else if(name_malek_istgah_pensilvania==2)//zarar midam
                {
                    //1
                             if(name_malek_istgah_reading!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=25;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //2
                             else if((name_malek_istgah_reading==2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلارجریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2 && name_malek_istgah_bo!=2))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //3
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline!=2) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه ردینگ و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_shortline==2 && name_malek_istgah_bo!=2)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //4
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=100;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                }
            }
        }
       ////////////////////////////////////
        else if(j==2)
        {
            if(malek_istgah_pensilvania==99)
            {
                QMessageBox::information(this,"ایستگاه پنسیلوانیا","ایستگاه پنسیلوانیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_17->show();
            }
            else if(malek_istgah_pensilvania==100)
            {
                if(name_malek_istgah_pensilvania==2) //sud bgire
                {
                    //1
                             if(name_malek_istgah_reading!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah drm ooon setaye dg male mn nis
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_reading==2 && name_malek_istgah_bo!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah drm reding o pensilvania
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah drm reading o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2 && name_malek_istgah_bo!=2))//2 ta istgah drm reading o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline!=2) //3ta istgah drm reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ و بی اند او  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_shortline==2 && name_malek_istgah_bo!=2)//3ta istgah drm reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2)//3ta istgah drm reading o bo o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_bo==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ بی اند او و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=200;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
                else if(name_malek_istgah_pensilvania==1)// zarar bede
                {
                    //1
                             if(name_malek_istgah_reading!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_reading==1 && name_malek_istgah_bo!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلارجریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1 && name_malek_istgah_bo!=1))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_reading==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline!=1) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه ردینگ و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==1 && name_malek_istgah_shortline==1 && name_malek_istgah_bo!=1)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_reading==1 && name_malek_istgah_bo==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ بی اند او و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
            }
        }
    }



    ///////////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[16]) //qale jims
    {
        if(j==1)
        {
            if(malek_qale_jims==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"قلعه جیمزا","قلعه جیمز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_57->show();
            }
            else if(malek_qale_jims==100)// khiaban malek drd
            {
                if(name_malek_qale_jims==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_qale_jims==0 && tedad_hotelhaye_qale_jims==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_jims>0 && tedad_hotelhaye_qale_jims==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_qale_jims*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_jims==0 && tedad_hotelhaye_qale_jims>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_jims*100) + (tedad_hotelhaye_qale_jims* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_jims>0 && tedad_hotelhaye_qale_jims>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_jims*100) + (tedad_hotelhaye_qale_jims* 4*100) + (tedad_khanehaye_qale_jims*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_qale_jims==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_tenesi!=2 || name_malek_khiaban_newyork!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ نارنجی همین یک خیابان را دارد و مالکیت تنسی و یا نیویورک یا هردو را هنوز کسب نکرده پس 14 دلار جریمه بدهید");

                        moneyp1-=14;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_tenesi==2 && name_malek_khiaban_newyork==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ نارنجی را دارد یعنی هم مالک تنسی است و هم نیویورک پس 28 دلار جریمه بدهید");

                        moneyp1-=28;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_qale_jims==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"قلعه جیمز","قلعه جیمز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_58->show();
            }
            else if(malek_qale_jims==100)//khiaban malek drd
            {
                if(name_malek_qale_jims==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_qale_jims==0 && tedad_hotelhaye_qale_jims==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_jims>0 && tedad_hotelhaye_qale_jims==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_qale_jims*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_jims==0 && tedad_hotelhaye_qale_jims>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_jims*100) + (tedad_hotelhaye_qale_jims* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_jims>0 && tedad_hotelhaye_qale_jims>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_jims*100) + (tedad_hotelhaye_qale_jims*4*100) + (tedad_khanehaye_qale_jims*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_qale_jims==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_tenesi!=1 || name_malek_khiaban_newyork!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ نارنجی همین یک خیابان را دارد و هنوز مالکیت تنسی و یا نیویورک یا هردو را هنوز کسب نکرده پس 14 دلار جریمه بدهید");

                        moneyp2-=14;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_tenesi==1 && name_malek_khiaban_newyork==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ نارنجی را دارد یعنی هم مالک تنسی است و هم نیویورک پس 28 دلار جریمه بدهید");

                        moneyp2-=28;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[17]) //community chest
    {
        QMessageBox::information(this,"کارت انجمنتو امتحان کن!","اگه بازیکن 1 هستی یا2  تایپ کن 1 یا تایپ کن 2 و بعد روی کارت انجمن خود را امتحان کنید بزنید");
        ui->groupBox_4->setEnabled(true);
    }
     ///////////////////////////////////////////////////////////////////////////////////
   else if (c==ob.definecell[18]) //tenesse
    {
        if(j==1)
        {
            if(malek_khiaban_tenesi==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان تنسی","خیابان تنسی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_60->show();
            }
            else if(malek_khiaban_tenesi==100)// khiaban malek drd
            {
                if(name_malek_khiaban_tenesi==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_tenesi==0 && tedad_hotelhaye_tenesi==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_tenesi>0 && tedad_hotelhaye_tenesi==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_tenesi*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_tenesi==0 && tedad_hotelhaye_tenesi>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_tenesi*100) + (tedad_hotelhaye_tenesi* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_tenesi>0 && tedad_hotelhaye_tenesi>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_tenesi*100) + (tedad_hotelhaye_tenesi* 4*100) + (tedad_khanehaye_tenesi*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_tenesi==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_qale_jims!=2 || name_malek_khiaban_newyork!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ نارنجی همین یک خیابان را دارد و مالکیت جیمز و یا نیویورک یا هردو را هنوز کسب نکرده پس 14 دلار جریمه بدهید");

                        moneyp1-=14;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_qale_jims==2 && name_malek_khiaban_newyork==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ نارنجی را دارد یعنی هم مالک جیمز است و هم نیویورک پس 28 دلار جریمه بدهید");

                        moneyp1-=28;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_tenesi==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان تنسی","خیابان تنسی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_61->show();
            }
            else if(malek_khiaban_tenesi==100)//khiaban malek drd
            {
                if(name_malek_khiaban_tenesi==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_tenesi==0 && tedad_hotelhaye_tenesi==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_tenesi>0 && tedad_hotelhaye_tenesi==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_tenesi*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_tenesi==0 && tedad_hotelhaye_tenesi>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_tenesi*100) + (tedad_hotelhaye_tenesi* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_tenesi>0 && tedad_hotelhaye_tenesi>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_tenesi*100) + (tedad_hotelhaye_tenesi*4*100) + (tedad_khanehaye_tenesi*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_tenesi==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_qale_jims!=1 || name_malek_khiaban_newyork!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ نارنجی همین یک خیابان را دارد و هنوز مالکیت جیمز و یا نیویورک یا هردو را هنوز کسب نکرده پس 14 دلار جریمه بدهید");

                        moneyp2-=14;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_tenesi==1 && name_malek_khiaban_newyork==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ نارنجی را دارد یعنی هم مالک جیمز است و هم نیویورک پس 28 دلار جریمه بدهید");

                        moneyp2-=28;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
   //``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
   else if (c==ob.definecell[19]) //new york
   {
        if(j==1)
        {
            if(malek_khiaban_newyork==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان نیویورک","خیابان نیویورک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_63->show();
            }
            else if(malek_khiaban_newyork==100)// khiaban malek drd
            {
                if(name_malek_khiaban_newyork==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_newyork==0 && tedad_hotelhaye_newyork==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_newyork>0 && tedad_hotelhaye_newyork==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_newyork*100;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_newyork==0 && tedad_hotelhaye_newyork>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_newyork*100) + (tedad_hotelhaye_newyork* 4*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_newyork>0 && tedad_hotelhaye_newyork>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_newyork*100) + (tedad_hotelhaye_newyork* 4*100) + (tedad_khanehaye_newyork*100));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_newyork==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_qale_jims!=2 || name_malek_khiaban_tenesi!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ نارنجی همین یک خیابان را دارد و مالکیت جیمز و یا تنسی یا هردو را هنوز کسب نکرده پس 16 دلار جریمه بدهید");

                        moneyp1-=16;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_qale_jims==2 && name_malek_khiaban_tenesi==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ نارنجی را دارد یعنی هم مالک جیمز است و هم تنسی پس 32 دلار جریمه بدهید");

                        moneyp1-=32;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_newyork==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان نیویورک","خیابان نیویورک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_64->show();
            }
            else if(malek_khiaban_newyork==100)//khiaban malek drd
            {
                if(name_malek_khiaban_newyork==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_newyork==0 && tedad_hotelhaye_newyork==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_newyork>0 && tedad_hotelhaye_newyork==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_newyork*100;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_newyork==0 && tedad_hotelhaye_newyork>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_newyork*100) + (tedad_hotelhaye_newyork* 4*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_newyork>0 && tedad_hotelhaye_newyork>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_newyork*100) + (tedad_hotelhaye_newyork*4*100) + (tedad_khanehaye_newyork*100));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_newyork==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_qale_jims!=1 || name_malek_khiaban_tenesi!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ نارنجی همین یک خیابان را دارد و هنوز مالکیت جیمز و یا تنسی یا هردو را هنوز کسب نکرده پس 16 دلار جریمه بدهید");

                        moneyp2-=16;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_tenesi==1 && name_malek_khiaban_tenesi==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ نارنجی را دارد یعنی هم مالک جیمز است و هم تنسی پس 32 دلار جریمه بدهید");

                        moneyp2-=32;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
   }
///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[20])
    {
        QMessageBox::information(this," ","از یک پارکینگ  مجانی لذت ببر!");
    }
///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[21]) //kentucky
    {
        if(j==1)
        {
            if(malek_khiaban_kentucky==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان کنتاکی","خیابان کنتاکی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_66->show();
            }
            else if(malek_khiaban_kentucky==100)// khiaban malek drd
            {
                if(name_malek_khiaban_kentucky==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_kentucky==0 && tedad_hotelhaye_kentucky==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_kentucky>0 && tedad_hotelhaye_kentucky==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_kentucky*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_kentucky==0 && tedad_hotelhaye_kentucky>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_kentucky*150) + (tedad_hotelhaye_kentucky* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_kentucky>0 && tedad_hotelhaye_kentucky>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_kentucky*150) + (tedad_hotelhaye_kentucky* 4*150) + (tedad_khanehaye_kentucky*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_kentucky==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_indiana!=2 || name_malek_khiaban_ilinois!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ قرمز همین یک خیابان را دارد و مالکیت ایندیانا و یا ایلی نویز یا هردو را هنوز کسب نکرده پس 18 دلار جریمه بدهید");

                        moneyp1-=18;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_indiana==2 && name_malek_khiaban_ilinois==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ قرمز را دارد یعنی هم مالک ایندیانا است و هم ایلی نویز پس 36 دلار جریمه بدهید");

                        moneyp1-=36;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_kentucky==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان کنتاکی","خیابان کنتاکی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_67->show();
            }
            else if(malek_khiaban_kentucky==100)//khiaban malek drd
            {
                if(name_malek_khiaban_kentucky==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_kentucky==0 && tedad_hotelhaye_kentucky==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_kentucky>0 && tedad_hotelhaye_kentucky==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_kentucky*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_kentucky==0 && tedad_hotelhaye_kentucky>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_kentucky*150) + (tedad_hotelhaye_kentucky* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_kentucky>0 && tedad_hotelhaye_kentucky>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_kentucky*150) + (tedad_hotelhaye_kentucky*4*150) + (tedad_khanehaye_kentucky*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_kentucky==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_indiana!=1 || name_malek_khiaban_ilinois!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ قرمز همین یک خیابان را دارد و هنوز مالکیت ایندیانا  و یا ایلی نویز یا هردو را هنوز کسب نکرده پس 18 دلار جریمه بدهید");

                        moneyp2-=18;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_indiana==1 && name_malek_khiaban_ilinois==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ قرمز را دارد یعنی هم مالک ایندیانا است و هم ایلی نویز پس 36 دلار جریمه بدهید");

                        moneyp2-=36;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[22]) //chance
    {
        QMessageBox::information(this,"شانستو امتحان کن !","روی کارت شانس روی صفحه بازی بزن تا ببینیم شانست چیه ؟");
        ui->groupBox_3->setEnabled(true);
    }
     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[23]) //indiana
    {
        if(j==1)
        {
            if(malek_khiaban_indiana==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان ایندیانا","خیابان ایندیانا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_69->show();
            }
            else if(malek_khiaban_indiana==100)// khiaban malek drd
            {
                if(name_malek_khiaban_indiana==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_indiana==0 && tedad_hotelhaye_indiana==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_indiana>0 && tedad_hotelhaye_indiana==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_indiana*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_indiana==0 && tedad_hotelhaye_indiana>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_indiana*150) + (tedad_hotelhaye_indiana* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_indiana>0 && tedad_hotelhaye_indiana>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_indiana*150) + (tedad_hotelhaye_indiana* 4*150) + (tedad_khanehaye_indiana*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_indiana==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_kentucky!=2 || name_malek_khiaban_ilinois!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ قرمز همین یک خیابان را دارد و مالکیت کنتاکی و یا ایلی نویز یا هردو را هنوز کسب نکرده پس 18 دلار جریمه بدهید");

                        moneyp1-=18;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_kentucky==2 && name_malek_khiaban_ilinois==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ قرمز را دارد یعنی هم مالک کنتاکی است و هم ایلی نویز پس 36 دلار جریمه بدهید");

                        moneyp1-=36;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_indiana==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان ایندیانا","خیابان ایندیانا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_70->show();
            }
            else if(malek_khiaban_indiana==100)//khiaban malek drd
            {
                if(name_malek_khiaban_indiana==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_indiana==0 && tedad_hotelhaye_indiana==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_indiana>0 && tedad_hotelhaye_indiana==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_indiana*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_indiana==0 && tedad_hotelhaye_indiana>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_indiana*150) + (tedad_hotelhaye_indiana* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_indiana>0 && tedad_hotelhaye_indiana>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_indiana*150) + (tedad_hotelhaye_indiana*4*150) + (tedad_khanehaye_indiana*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_indiana==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_kentucky!=1 || name_malek_khiaban_ilinois!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ قرمز همین یک خیابان را دارد و هنوز مالکیت کنتاکی  و یا ایلی نویز یا هردو را هنوز کسب نکرده پس 18 دلار جریمه بدهید");

                        moneyp2-=18;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_indiana==1 && name_malek_khiaban_ilinois==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ قرمز را دارد یعنی هم مالک کنتاکی است و هم ایلی نویز پس 36 دلار جریمه بدهید");

                        moneyp2-=36;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

 ///////////////////////////////////////////////////////////////////////////////////

  else if (c==ob.definecell[24]) //ilinois
    {
        if(j==1)
        {
            if(malek_khiaban_ilinois==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان ایلینویز","خیابان ایلینویز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_72->show();
            }
            else if(malek_khiaban_ilinois==100)// khiaban malek drd
            {
                if(name_malek_khiaban_ilinois==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_ilinois==0 && tedad_hotelhaye_ilinois==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_ilinois>0 && tedad_hotelhaye_ilinois==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_ilinois*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_ilinois==0 && tedad_hotelhaye_ilinois>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_ilinois*150) + (tedad_hotelhaye_ilinois* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_ilinois>0 && tedad_hotelhaye_ilinois>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_ilinois*150) + (tedad_hotelhaye_ilinois* 4*150) + (tedad_khanehaye_ilinois*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_ilinois==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_indiana!=2 || name_malek_khiaban_kentucky!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ قرمز همین یک خیابان را دارد و مالکیت ایندیانا و یا کنتاکی یا هردو را هنوز کسب نکرده پس 20 دلار جریمه بدهید");

                        moneyp1-=20;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_indiana==2 && name_malek_khiaban_kentucky==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ قرمز را دارد یعنی هم مالک ایندیانا است و هم کنتاکی پس 40 دلار جریمه بدهید");

                        moneyp1-=40;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_ilinois==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان ایلینویز","خیابان ایلینویز مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_73->show();
            }
            else if(malek_khiaban_ilinois==100)//khiaban malek drd
            {
                if(name_malek_khiaban_ilinois==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_ilinois==0 && tedad_hotelhaye_ilinois==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_ilinois>0 && tedad_hotelhaye_ilinois==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_ilinois*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_ilinois==0 && tedad_hotelhaye_ilinois>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_ilinois*150) + (tedad_hotelhaye_ilinois* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_ilinois>0 && tedad_hotelhaye_ilinois>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_ilinois*150) + (tedad_hotelhaye_ilinois*4*150) + (tedad_khanehaye_ilinois*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_ilinois==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_indiana!=1 || name_malek_khiaban_kentucky!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ قرمز همین یک خیابان را دارد و هنوز مالکیت ایندیانا  و یا کنتاکی یا هردو را هنوز کسب نکرده پس 20 دلار جریمه بدهید");

                        moneyp2-=20;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_indiana==1 && name_malek_khiaban_kentucky==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ قرمز را دارد یعنی هم مالک ایندیانا است و هم کنتاکی پس 40 دلار جریمه بدهید");

                        moneyp2-=40;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[25]) //isga bando
    {
        if(j==1)
        {
            if(malek_istgah_bo==99)
            {
                QMessageBox::information(this,"ایستگاه بی اند او","ایستگاه بی اند او مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_19->show();
            }
            else if(malek_istgah_bo==100)
            {
                if(name_malek_istgah_bo==1) //sud migiram
                {
           //1
                    if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah drm ooon setaye dg male mn nis
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=25;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //2
                    else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah drm bo o pensilvania
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah drm reading o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if((name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1))//2 ta istgah drm bo o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //3
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_shortline!=1) //3ta istgah drm reading o pensilvania o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1)//3ta istgah drm reading o pensilvania o short line
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_reading==1 && name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1)//3ta istgah drm reading o bo o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ  و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //4
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا ردینگ و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=200;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                else if(name_malek_istgah_bo==2)//zarar midam
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=25;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلار جریمه میدهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_shortline!=2) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا ردینگ و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=100;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                }
            }
        }

        //ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp
        else if(j==2)
        {
            if(malek_istgah_bo==99)
            {
                QMessageBox::information(this,"ایستگاه بی اند او","ایستگاه بی اند او مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_20->show();
            }
            else if(malek_istgah_bo==100)
            {
                if(name_malek_istgah_bo==2) //sud bgire
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2) //faqat 1 istgah drm ooon setaye dg male mn nis
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_reading!=2 && name_malek_istgah_shortline!=2)) // 2 ta istgah drm reding o pensilvania
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_shortline!=2)// 2 ta istgah drm reading o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2))//2 ta istgah drm reading o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_shortline!=2) //3ta istgah drm reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_shortline==2 && name_malek_istgah_reading!=2)//3ta istgah drm reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==2 && name_malek_istgah_shortline==2 && name_malek_istgah_pensilvania!=2)//3ta istgah drm reading o bo o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_shortline==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا ردینگ و شورت لاین  هم هستید پس 200 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=200;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
                else if(name_malek_istgah_bo==1)// zarar bede
                {
                    //1
                             if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_reading!=1 && name_malek_istgah_shortline!=1)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_shortline!=1)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلار جریمه میدهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه شورت لاین هم هست پس 50 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_shortline!=1) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_shortline==1 && name_malek_istgah_reading!=1)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_reading==1 && name_malek_istgah_shortline==1 && name_malek_istgah_pensilvania!=1)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه ردینگ و شورت لاین  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_shortline==1) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا ردینگ و شورت لاین  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
            }
            }


    }
//////////////////////////////////////////////////////

    else if (c==ob.definecell[26]) // atlantic
    {
        if(j==1)
        {
            if(malek_khiaban_atlantic==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان آتلانتیک","خیابان آتلانتیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_75->show();
            }
            else if(malek_khiaban_atlantic==100)// khiaban malek drd
            {
                if(name_malek_khiaban_atlantic==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_atlantic==0 && tedad_hotelhaye_atlantic==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_atlantic>0 && tedad_hotelhaye_atlantic==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_atlantic*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_atlantic==0 && tedad_hotelhaye_atlantic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_atlantic*150) + (tedad_hotelhaye_atlantic* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_atlantic>0 && tedad_hotelhaye_atlantic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_atlantic*150) + (tedad_hotelhaye_atlantic* 4*150) + (tedad_khanehaye_atlantic*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_atlantic==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_ventor!=2 || name_malek_khiaban_marvin!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ زرد همین یک خیابان را دارد و مالکیت ونتور و یا ماروین یا هردو را هنوز کسب نکرده پس 22 دلار جریمه بدهید");

                        moneyp1-=22;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_ventor==2 && name_malek_khiaban_marvin==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ زرد را دارد یعنی هم مالک ونتور است و هم ماروین پس 44 دلار جریمه بدهید");

                        moneyp1-=44;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_atlantic==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان آتلانتیک","خیابان آتلانتیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_76->show();
            }
            else if(malek_khiaban_atlantic==100)//khiaban malek drd
            {
                if(name_malek_khiaban_atlantic==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_atlantic==0 && tedad_hotelhaye_atlantic==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_atlantic>0 && tedad_hotelhaye_atlantic==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_atlantic*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_atlantic==0 && tedad_hotelhaye_atlantic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_atlantic*150) + (tedad_hotelhaye_atlantic* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_atlantic>0 && tedad_hotelhaye_atlantic>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_atlantic*150) + (tedad_hotelhaye_atlantic*4*150) + (tedad_khanehaye_atlantic*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_atlantic==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_ventor!=1 || name_malek_khiaban_marvin!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ زرد همین یک خیابان را دارد و هنوز مالکیت ونتور  و یا ماروین یا هردو را هنوز کسب نکرده پس 22 دلار جریمه بدهید");

                        moneyp2-=22;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_ventor==1 && name_malek_khiaban_marvin==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ زرد را دارد یعنی هم مالک ونتور است و هم ماروین پس 44 دلار جریمه بدهید");

                        moneyp2-=44;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    else if (c==ob.definecell[27]) //ventor
    {
        if(j==1)
        {
            if(malek_khiaban_ventor==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان ونتور","خیابان ونتور مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_78->show();
            }
            else if(malek_khiaban_ventor==100)// khiaban malek drd
            {
                if(name_malek_khiaban_ventor==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_ventor==0 && tedad_hotelhaye_ventor==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_ventor>0 && tedad_hotelhaye_ventor==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_ventor*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_ventor==0 && tedad_hotelhaye_ventor>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_ventor*150) + (tedad_hotelhaye_ventor* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_ventor>0 && tedad_hotelhaye_ventor>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_ventor*150) + (tedad_hotelhaye_ventor* 4*150) + (tedad_khanehaye_ventor*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_ventor==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_atlantic!=2 || name_malek_khiaban_marvin!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ زرد همین یک خیابان را دارد و مالکیت آتلاتنیک و یا ماروین یا هردو را هنوز کسب نکرده پس 22 دلار جریمه بدهید");

                        moneyp1-=22;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_atlantic==2 && name_malek_khiaban_marvin==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ زرد را دارد یعنی هم مالک آتلاتنیک است و هم ماروین پس 44 دلار جریمه بدهید");

                        moneyp1-=44;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_ventor==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان ونتور","خیابان ونتور مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_79->show();
            }
            else if(malek_khiaban_ventor==100)//khiaban malek drd
            {
                if(name_malek_khiaban_ventor==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_ventor==0 && tedad_hotelhaye_ventor==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_ventor>0 && tedad_hotelhaye_ventor==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_ventor*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_ventor==0 && tedad_hotelhaye_ventor>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_ventor*150) + (tedad_hotelhaye_ventor* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_ventor>0 && tedad_hotelhaye_ventor>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_ventor*150) + (tedad_hotelhaye_ventor*4*150) + (tedad_khanehaye_ventor*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_ventor==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_atlantic!=1 || name_malek_khiaban_marvin!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ زرد همین یک خیابان را دارد و هنوز مالکیت آتلانتیک  و یا ماروین یا هردو را هنوز کسب نکرده پس 22 دلار جریمه بدهید");

                        moneyp2-=22;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_atlantic==1 && name_malek_khiaban_marvin==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ زرد را دارد یعنی هم مالک آتلانتیک است و هم ماروین پس 44 دلار جریمه بدهید");

                        moneyp2-=44;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------
    else if (c==ob.definecell[28]) //sherkate ab
    {
        if(j==1)
        {
            if(malek_sherkate_ab==99) // yani sherkate ab malek nadare pas mishe malekesh shd ya be mozayede gozasht
            {
                QMessageBox::information(this,"شرکت آب!","شرکت آب مالک ندارد انتخاب کنید که می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_10->show();
            }
            else if(malek_sherkate_ab==100)//yani sherkate ab malek dre age p1 malekeshe hichi age p2 malekeshe sud bede b p2
            {
                /*if(name_maleke_ab==1)//yani mohre1 varede sherkate abi shde k malekesh khdshe pas poolash ziad mishe
                {

                }*/ //ino az ostad porsidam bad biam virayesh knm ya nknm
                if(name_maleke_ab==2)//yani mohre1 varede sherkate barghi shde k malekesh player 2 hast pas vorood gheire mojaz dashte o bayad jarime bede b player2
                {
                    QMessageBox::warning(this,"ورود غیر مجازی به شرکت آب!","بازیکن 1 شما ورود غیر مجازی به شرکت آبی که مملوک بازیکن 2 هست داشته اید پس باید جریمه بدهید");
                    tas = (rand()%6)+1;
                    ui->label_16->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(tas) + ".bmp);");
                    ui->label_16->show();
                    //tas rikhte she o namayesh dade bshe
                    if(name_maleke_bargh==2)//player 2 maleke sherkate bargh ham bashe
                    {
                        QMessageBox::information(this,"","بازیکن 2 علاوه بر شرکت آب، مالک شرکت برق هم هست پش 10 برابر عدد تاس باید جریمه بدهید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=(10*tas);
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_maleke_bargh!=2)//player 2 maleke sherkate bargh nabashe
                    {
                        QMessageBox::information(this,"","بازیکن 2 فقط مالک شرکت آب هست پش 4 برابر عدد تاس باید جریمه بدهید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1-=(4*tas);
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }

            }
        }
        else if(j==2)
        {
            if(malek_sherkate_ab==99) // yani sherkate ab malek nadare pas mishe malekesh shd ya be mozayede gozasht
            {
                QMessageBox::information(this,"شرکت آب!","شرکت آب مالک ندارد انتخاب کنید که می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_11->show();
            }
            else if(malek_sherkate_ab==100)//yani sherkate abi malek dre age p2 malekeshe sud bgire age p1 malekeshe sud bede b p1
            {
                /*if(name_maleke_ab==2)//yani mohre2 varede sherkate barghi shde k malekesh khdshe pas poolash ziad mishe
                {

                }*/ //ino az ostad porsidam bad biam virayesh knm ya nknm
                if(name_maleke_ab==1)//yani mohre2 varede sherkate barghi shde k malekesh player 1 hast pas vorood gheire mojaz dashte o bayad jarime bede b player1
                {
                    QMessageBox::warning(this,"ورود غیر مجازی به شرکت آب!","بازیکن 2 شما ورود غیر مجازی به شرکت آبی که مملوک بازیکن 1 هست داشته اید پس باید جریمه بدهید");
                    tas = (rand()%6)+1;
                    //namayeshe tas
                    ui->label_16->setStyleSheet("image: url(:/new/prefix1/dice" + QString::number(tas) + ".bmp);");
                    ui->label_16->show();
                    if(name_maleke_bargh==1)//player 1 maleke sherkate bargh ham bashe
                    {
                        QMessageBox::information(this,"","بازیکن 1 علاوه بر شرکت آب، مالک شرکت برق هم هست پش 10 برابر عدد تاس باید جریمه بدهید");
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=(10*tas);
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                    else if(name_maleke_bargh!=1)//player 1 maleke sherkate bargh nabashe
                    {
                        QMessageBox::information(this,"","بازیکن 1 فقط مالک شرکت آب هست پش 4 برابر عدد تاس باید جریمه بدهید");
                        moneyp2=ui->lineEdit_2->text().toInt();
                        moneyp2-=(4*tas);
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }
            }
        }
    }
    //----------------------------------------------------------------------------------------------------------------------------
    else if (c==ob.definecell[29]) //marvin
    {
        if(j==1)
        {
            if(malek_khiaban_marvin==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"باغ ماروین","باغ ماروین مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_81->show();
            }
            else if(malek_khiaban_marvin==100)// khiaban malek drd
            {
                if(name_malek_khiaban_marvin==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_marvin==0 && tedad_hotelhaye_marvin==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_marvin>0 && tedad_hotelhaye_marvin==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_marvin*150;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_marvin==0 && tedad_hotelhaye_marvin>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_marvin*150) + (tedad_hotelhaye_marvin* 4*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_marvin>0 && tedad_hotelhaye_marvin>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_marvin*150) + (tedad_hotelhaye_marvin* 4*150) + (tedad_khanehaye_marvin*150));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_marvin==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_atlantic!=2 || name_malek_khiaban_ventor!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ زرد همین یک خیابان را دارد و مالکیت آتلاتنیک و یا ونتور یا هردو را هنوز کسب نکرده پس 24 دلار جریمه بدهید");

                        moneyp1-=24;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_atlantic==2 && name_malek_khiaban_ventor==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ زرد را دارد یعنی هم مالک آتلاتنیک است و هم ونتور پس 48 دلار جریمه بدهید");

                        moneyp1-=48;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_marvin==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"باغ ماروین","باغ ماروین مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_82->show();
            }
            else if(malek_khiaban_marvin==100)//khiaban malek drd
            {
                if(name_malek_khiaban_marvin==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_marvin==0 && tedad_hotelhaye_marvin==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_marvin>0 && tedad_hotelhaye_marvin==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_marvin*150;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_marvin==0 && tedad_hotelhaye_marvin>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_marvin*150) + (tedad_hotelhaye_marvin* 4*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_marvin>0 && tedad_hotelhaye_marvin>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_marvin*150) + (tedad_hotelhaye_marvin*4*150) + (tedad_khanehaye_marvin*150));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_marvin==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_atlantic!=1 || name_malek_khiaban_ventor!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ زرد همین یک خیابان را دارد و هنوز مالکیت آتلانتیک  و یا ونتور یا هردو را هنوز کسب نکرده پس 24 دلار جریمه بدهید");

                        moneyp2-=24;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_atlantic==1 && name_malek_khiaban_ventor==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ زرد را دارد یعنی هم مالک آتلانتیک است و هم ونتور پس 48 دلار جریمه بدهید");

                        moneyp2-=48    ;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[30]) //go to jail
    {
        if(j==1)
        {
            QMessageBox::warning(this," چه بد شد !","به زندان منتقل شدید و200 دلار go را هم نگرفتید!!");
            ui->mohrep1->move(60,660);//bere be zendan
            //ob.player[1] = ob.definecell[10];
            cel1=10;
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
            injail_p1=1;

        }
        else if(j==2)
        {
            QMessageBox::warning(this," چه بد شد !","به زندان منتقل شدید و200 دلار go را هم نگرفتید!!");
            ui->mohrep2->move(60,660);//bere be zendan
            //ob.player[1] = ob.definecell[10];
            cel2=10;
            //age bara raftan be zendan az go rad shod 200$ nagire ke dar nazar grftm o inke nobtshm tamom she dar nazar grftm chon oon 200$ bar asare move ba tasrizi
            //rokh mide vali in fqt move sadas va pooli b hesab shakhs nmiyad
            injail_p2=2;
        }
    }
     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[31]) //pacific
    {
        if(j==1)
        {
            if(malek_khiaban_pacific==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان پاسیفیک","خیابان پاسیفیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_84->show();
            }
            else if(malek_khiaban_pacific==100)// khiaban malek drd
            {
                if(name_malek_khiaban_pacific==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_pacific==0 && tedad_hotelhaye_pacific==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_pacific>0 && tedad_hotelhaye_pacific==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_pacific*200;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_pacific==0 && tedad_hotelhaye_pacific>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_pacific*200) + (tedad_hotelhaye_pacific* 4*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_pacific>0 && tedad_hotelhaye_pacific>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_pacific*200) + (tedad_hotelhaye_pacific* 4*200) + (tedad_khanehaye_pacific*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_pacific==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_northcarolina!=2 || name_malek_khiaban_pensilvania!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ سبز همین یک خیابان را دارد و مالکیت کارولینای شمالی و یا پنسیلوانیا یا هردو را هنوز کسب نکرده پس 26 دلار جریمه بدهید");

                        moneyp1-=26;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_northcarolina==2 && name_malek_khiaban_pensilvania==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ سبز را دارد یعنی هم مالک کارولینای شمالی است و هم پنسیلوانیا پس 52 دلار جریمه بدهید");

                        moneyp1-=52;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_pacific==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان پاسیفیک","خیابان پاسیفیک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_85->show();
            }
            else if(malek_khiaban_pacific==100)//khiaban malek drd
            {
                if(name_malek_khiaban_pacific==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_pacific==0 && tedad_hotelhaye_pacific==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_pacific>0 && tedad_hotelhaye_pacific==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_pacific*200;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_pacific==0 && tedad_hotelhaye_pacific>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_pacific*200) + (tedad_hotelhaye_pacific* 4*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_pacific>0 && tedad_hotelhaye_pacific>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_pacific*200) + (tedad_hotelhaye_pacific*4*200) + (tedad_khanehaye_pacific*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_pacific==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_northcarolina!=1 || name_malek_khiaban_pensilvania!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ سبز همین یک خیابان را دارد و هنوز مالکیت کارولینای شمالی  و یا پنسیلوانیا یا هردو را هنوز کسب نکرده پس 26 دلار جریمه بدهید");

                        moneyp2-=26;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_northcarolina==1 && name_malek_khiaban_pensilvania==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ سبز را دارد یعنی هم مالک کارولینای شمالی است و هم پنسیلوانیا پس 52 دلار جریمه بدهید");

                        moneyp2-=52;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }


 ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[32]) //north carolina
    {
        if(j==1)
        {
            if(malek_khiaban_northcarolina==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان کارولینای شمالی","خیابان کارولینای شمالی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_87->show();
            }
            else if(malek_khiaban_northcarolina==100)// khiaban malek drd
            {
                if(name_malek_khiaban_northcarolina==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_northcarolina==0 && tedad_hotelhaye_northcarolina==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_northcarolina>0 && tedad_hotelhaye_northcarolina==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_northcarolina*200;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_northcarolina==0 && tedad_hotelhaye_northcarolina>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_northcarolina*200) + (tedad_hotelhaye_northcarolina* 4*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_northcarolina>0 && tedad_hotelhaye_northcarolina>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_northcarolina*200) + (tedad_hotelhaye_northcarolina* 4*200) + (tedad_khanehaye_northcarolina*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_northcarolina==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_pacific!=2 || name_malek_khiaban_pensilvania!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ سبز همین یک خیابان را دارد و مالکیت پاسیفیک و یا پنسیلوانیا یا هردو را هنوز کسب نکرده پس 26 دلار جریمه بدهید");

                        moneyp1-=26;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_pacific==2 && name_malek_khiaban_pensilvania==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ سبز را دارد یعنی هم مالک پاسیفیک است و هم پنسیلوانیا پس 52 دلار جریمه بدهید");

                        moneyp1-=52;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_northcarolina==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان کارولینای شمالی","خیابان کارولینای شمالی مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_88->show();
            }
            else if(malek_khiaban_northcarolina==100)//khiaban malek drd
            {
                if(name_malek_khiaban_northcarolina==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_northcarolina==0 && tedad_hotelhaye_northcarolina==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_northcarolina>0 && tedad_hotelhaye_northcarolina==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_northcarolina*200;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_northcarolina==0 && tedad_hotelhaye_northcarolina>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_northcarolina*200) + (tedad_hotelhaye_northcarolina* 4*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_northcarolina>0 && tedad_hotelhaye_northcarolina>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_northcarolina*200) + (tedad_hotelhaye_northcarolina*4*200) + (tedad_khanehaye_northcarolina*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_northcarolina==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_pacific!=1 || name_malek_khiaban_pensilvania!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ سبز همین یک خیابان را دارد و هنوز مالکیت پاسیفیک و یا پنسیلوانیا یا هردو را هنوز کسب نکرده پس 26 دلار جریمه بدهید");

                        moneyp2-=26;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_pacific==1 && name_malek_khiaban_pensilvania==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ سبز را دارد یعنی هم مالک پاسیفیک است و هم پنسیلوانیا پس 52 دلار جریمه بدهید");

                        moneyp2-=52;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

 ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[33])
    {
        QMessageBox::information(this,"کارت انجمنتو امتحان کن!","اگه بازیکن 1 هستی یا2  تایپ کن 1 یا تایپ کن 2 و بعد روی کارت انجمن خود را امتحان کنید بزنید");
        ui->groupBox_4->setEnabled(true);
    }
    ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[34]) //khiabane pensilvania
    {
        if(j==1)
        {
            if(malek_khiaban_pensilvania==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان پنسیلوانیا","خیابان پنسیلوانیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_90->show();
            }
            else if(malek_khiaban_pensilvania==100)// khiaban malek drd
            {
                if(name_malek_khiaban_pensilvania==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_pensilvania==0 && tedad_hotelhaye_pensilvania==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_pensilvania>0 && tedad_hotelhaye_pensilvania==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_pensilvania*200;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_pensilvania==0 && tedad_hotelhaye_pensilvania>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_pensilvania*200) + (tedad_hotelhaye_pensilvania* 4*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_pensilvania>0 && tedad_hotelhaye_pensilvania>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_pensilvania*200) + (tedad_hotelhaye_pensilvania* 4*200) + (tedad_khanehaye_pensilvania*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_pensilvania==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_northcarolina!=2 || name_malek_khiaban_pacific!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ سبز همین یک خیابان را دارد و مالکیت کارولینای شمالی و یا پاسیفیک یا هردو را هنوز کسب نکرده پس 28 دلار جریمه بدهید");

                        moneyp1-=28;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_northcarolina==2 && name_malek_khiaban_pacific==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ سبز را دارد یعنی هم مالک کارولینای شمالی است و هم پاسیفیک پس 56 دلار جریمه بدهید");

                        moneyp1-=56;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_pensilvania==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان پنسیلوانیا","خیابان پنسیلوانیا مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_91->show();
            }
            else if(malek_khiaban_pensilvania==100)//khiaban malek drd
            {
                if(name_malek_khiaban_pensilvania==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_pensilvania==0 && tedad_hotelhaye_pensilvania==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_pensilvania>0 && tedad_hotelhaye_pensilvania==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_pensilvania*200;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_pensilvania==0 && tedad_hotelhaye_pensilvania>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_pensilvania*200) + (tedad_hotelhaye_pensilvania* 4*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_pensilvania>0 && tedad_hotelhaye_pensilvania>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_pensilvania*200) + (tedad_hotelhaye_pensilvania*4*200) + (tedad_khanehaye_pensilvania*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_pensilvania==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_northcarolina!=1 || name_malek_khiaban_pacific!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ سبز همین یک خیابان را دارد و هنوز مالکیت کارولینای شمالی  و یا پاسیفیک یا هردو را هنوز کسب نکرده پس 28 دلار جریمه بدهید");

                        moneyp2-=28;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_northcarolina==1 && name_malek_khiaban_pacific==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ سبز را دارد یعنی هم مالک کارولینای شمالی است و هم پاسیفیک پس 56 دلار جریمه بدهید");

                        moneyp2-=56;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

   ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[35])
    {
        if(j==1)
        {
            if(malek_istgah_shortline==99)
            {
                QMessageBox::information(this,"ایستگاه شورت لاین","ایستگاه شورت لاین  مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_23->show();
            }
            else if(malek_istgah_shortline==100)
            {
                if(name_malek_istgah_shortline==1) //sud migiram
                {
           //1
                    if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_reading!=1) //faqat 1 istgah drm ooon setaye dg male mn nis
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=25;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //2
                    else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_bo!=1 && name_malek_istgah_reading!=1)) // 2 ta istgah drm reding o pensilvania
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1)// 2 ta istgah drm reading o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if((name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1))//2 ta istgah drm reading o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=50;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //3
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_reading!=1) //3ta istgah drm reading o pensilvania o bo
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_bo!=1)//3ta istgah drm reading o pensilvania o short line
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                    else if(name_malek_istgah_bo==1 && name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1)//3ta istgah drm reading o bo o shortline
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و ردینگ  هم هستید پس 100 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
           //4
                    else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_reading==1) //maleke har 4 istgahe
                    {
                        QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و ردینگ  هم هستید پس 200 دلار سود می کنید");
                        moneyp1=ui->lineEdit->text().toInt();
                        moneyp1+=200;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
                //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                else if(name_malek_istgah_shortline==2)//zarar midam
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_reading!=2) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=25;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_bo!=2 && name_malek_istgah_reading!=2)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if((name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=50;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_reading!=2) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_bo!=2)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=75;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_reading==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و ردینگ  هم هست پس 100 دلار جریمه می دهید");
                                 moneyp1=ui->lineEdit->text().toInt();
                                 moneyp1-=100;
                                 ui->lineEdit->setText(QString::number(moneyp1));
                             }
                }
            }
        }
        else if(j==2)
        {
            if(malek_istgah_shortline==99)
            {
                QMessageBox::information(this,"ایستگاه شورت لاین","ایستگاه شورت لاین  مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_24->show();
            }
            else if(malek_istgah_shortline==100)
            {
                if(name_malek_istgah_shortline==2) //sud bgire
                {
                    //1
                             if(name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2 && name_malek_istgah_reading!=2) //faqat 1 istgah drm ooon setaye dg male mn nis
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالکش هستید و فعلا همین یک ایستگاه را دارید پس 25 دلار سود می کنید !");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==2 && name_malek_istgah_bo!=2 && name_malek_istgah_reading!=2)) // 2 ta istgah drm reding o pensilvania
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_reading!=2)// 2 ta istgah drm reading o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2 && name_malek_istgah_bo!=2))//2 ta istgah drm reading o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هستید پس 50 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_reading!=2) //3ta istgah drm reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_reading==2 && name_malek_istgah_bo!=2)//3ta istgah drm reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==2 && name_malek_istgah_reading==2 && name_malek_istgah_pensilvania!=2)//3ta istgah drm reading o bo o shortline
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه بی اند او و ردینگ  هم هستید پس 100 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==2 && name_malek_istgah_bo==2 && name_malek_istgah_reading==2) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"خوش خبری","شما وارد ایستگاهی شده اید که مالک آن هستید و علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و ردینگ  هم هستید پس 200 دلار سود می کنید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2+=200;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
                else if(name_malek_istgah_shortline==1)// zarar bede
                {
                    //1
                             if(name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1 && name_malek_istgah_reading!=1) //faqat 1 istgah dre ooon setaye dg male oo nis
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز ","شما وارد ایستگاهی شده اید که مالکش  فعلا همین یک ایستگاه را دارد پس 25 دلار جریمه میدهید!");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=25;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //2
                             else if((name_malek_istgah_pensilvania==1 && name_malek_istgah_bo!=1 && name_malek_istgah_reading!=1)) // 2 ta istgah dre reding o pensilvania
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا هم هست پس 50 دلارجریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_reading!=1)// 2 ta istgah dre reading o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او هم هست پس 50 دلار جریمه میدهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if((name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1 && name_malek_istgah_bo!=1))//2 ta istgah dre reading o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه ردینگ هم هست پس 50 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=50;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //3
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_reading!=1) //3ta istgah dre reading o pensilvania o bo
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن  علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و بی اند او  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_reading==1 && name_malek_istgah_bo!=1)//3ta istgah dre reading o pensilvania o short line
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                             else if(name_malek_istgah_bo==1 && name_malek_istgah_reading==1 && name_malek_istgah_pensilvania!=1)//3ta istgah dre reading o bo o shortline
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه بی اند او و ردینگ  هم هست پس 75 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=75;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                    //4
                             else if(name_malek_istgah_pensilvania==1 && name_malek_istgah_bo==1 && name_malek_istgah_reading==1) //maleke har 4 istgahe
                             {
                                 QMessageBox::information(this,"ورود غیر مجاز","شما وارد ایستگاهی شده اید که مالک آن علاوه بر این ایستگاه مالک ایستگاه پنسیلوانیا بی اند او و ردینگ هم هست پس 100 دلار جریمه می دهید");
                                 moneyp2=ui->lineEdit_2->text().toInt();
                                 moneyp2-=100;
                                 ui->lineEdit_2->setText(QString::number(moneyp2));
                             }
                }
            }
        }
    }

    else if (c==ob.definecell[36])
    {
        QMessageBox::information(this,"شانستو امتحان کن !","روی کارت شانس روی صفحه بازی بزن تا ببینیم شانست چیه ؟");
        ui->groupBox_3->setEnabled(true);

    }
     ///////////////////////////////////////////////////////////////////////////////////

   else if (c==ob.definecell[37]) //qale park
   {
        if(j==1)
        {
            if(malek_qale_park==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"قلعه پارک","قلعه پارک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_33->show();
            }
            else if(malek_qale_park==100)// khiaban malek drd
            {
                if(name_malek_qale_park==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_qale_park==0 && tedad_hotelhaye_qale_park==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_park>0 && tedad_hotelhaye_qale_park==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_qale_park*200;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_park==0 && tedad_hotelhaye_qale_park>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_park*200) + (tedad_hotelhaye_qale_park* 4*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_qale_park>0 && tedad_hotelhaye_qale_park>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_qale_park*200) + (tedad_hotelhaye_qale_park* 4*200) + (tedad_khanehaye_qale_park*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_qale_park==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_khiaban_boardwalk!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ آبی همین یک خیابان را دارد و مالکیت بوردواک را هنوز کسب نکرده پس 35 دلار جریمه بدهید");

                        moneyp1-=35;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_khiaban_boardwalk==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ آبی را دارد یعنی هم مالک قلعه پارک است و هم بوردواک پس 70 دلار جریمه بدهید");

                        moneyp1-=70;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_qale_park==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"قلعه پارک","قلعه پارک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_34->show();
            }
            else if(malek_qale_park==100)//khiaban malek drd
            {
                if(name_malek_qale_park==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_qale_park==0 && tedad_hotelhaye_qale_park==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_qale_park>0 && tedad_hotelhaye_qale_park==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_qale_park*200;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_park==0 && tedad_hotelhaye_qale_park>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_park*200) + (tedad_hotelhaye_qale_park* 4*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_qale_park>0 && tedad_hotelhaye_qale_park>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_qale_park*200) + (tedad_hotelhaye_qale_park*4*200) + (tedad_khanehaye_qale_park*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_qale_park==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_khiaban_boardwalk!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ آبی همین یک خیابان را دارد و مالکیت بوردواک را هنوز کسب نکرده پس 35 دلار جریمه بدهید");

                        moneyp2-=35;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_boardwalk==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ آبی را دارد یعنی هم مالک قلعه پارک است و هم بوردواک پس 70 دلار جریمه بدهید");

                        moneyp2-=70;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
   }
     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[38]) //luxury tax
    {
        if(j==1)
        {
            QMessageBox::information(this,"مالیات بر درآمد!","وارد خانه مالیات بر درآمد شده اید  پس 75 دلار از سرمایه تان کسر می شود!");
            moneyp1 = ui->lineEdit->text().toInt();
            moneyp1-=75;
            ui->lineEdit->setText(QString::number(moneyp1));
        }
        else if(j==2)
        {
            QMessageBox::information(this,"مالیات بر درآمد!","وارد خانه مالیات بر درآمد شده اید  پس 75 دلار از سرمایه تان کسر می شود!");
            moneyp2 = ui->lineEdit_2->text().toInt();
            moneyp2-=75;
            ui->lineEdit_2->setText(QString::number(moneyp2));
        }
    }
     ///////////////////////////////////////////////////////////////////////////////////
    else if (c==ob.definecell[39]) //boardwalk
    {

        if(j==1)
        {
            if(malek_khiaban_boardwalk==99) // khiaban malek nadarad
            {
                QMessageBox::information(this,"خیابان بوردواک","خیابان بوردواک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_36->show();
            }
            else if(malek_khiaban_boardwalk==100)// khiaban malek drd
            {
                if(name_malek_khiaban_boardwalk==1) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 1  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(tedad_khanehaye_boardwalk==0 && tedad_hotelhaye_boardwalk==0)
                        QMessageBox::information(this,"","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_boardwalk>0 && tedad_hotelhaye_boardwalk==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp1+=tedad_khanehaye_boardwalk*200;
                            ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_boardwalk==0 && tedad_hotelhaye_boardwalk>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_boardwalk*200) + (tedad_hotelhaye_boardwalk* 4*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }
                    else if (tedad_khanehaye_boardwalk>0 && tedad_hotelhaye_boardwalk>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp1+=((tedad_hotelhaye_boardwalk*200) + (tedad_hotelhaye_boardwalk* 4*200) + (tedad_khanehaye_boardwalk*200));
                             ui->lineEdit->setText(QString::number(moneyp1));
                        }

                }
                else if (name_malek_khiaban_boardwalk==2) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 1 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp1=ui->lineEdit->text().toInt();
                    if(name_malek_qale_park!=2) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 فعلا از رنگ آبی همین یک خیابان را دارد و مالکیت قلعه پارک را هنوز کسب نکرده پس 50 دلار جریمه بدهید");

                        moneyp1-=50;
                        ui->lineEdit->setText(QString::number(moneyp1));

                    }
                    else if(name_malek_qale_park==2) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 2 انحصار رنگ آبی را دارد یعنی هم مالک قلعه پارک است و هم بوردواک پس 100 دلار جریمه بدهید");

                        moneyp1-=100;
                        ui->lineEdit->setText(QString::number(moneyp1));
                    }
                }
            }
        }
        else if(j==2)
        {
            if(malek_khiaban_boardwalk==99) // khiaban malek ndre
            {
                QMessageBox::information(this,"خیابان بوردواک","خیابان بوردواک مالک ندارد انتخاب کنید می خواهید مالکش شوید یا بانک آن را به مزایده بگذارد؟");
                ui->groupBox_37->show();
            }
            else if(malek_khiaban_boardwalk==100)//khiaban malek drd
            {
                if(name_malek_khiaban_boardwalk==2) // malekesh khodeshe o bayad sud begire
                {
                    QMessageBox::information(this,"خبر خوش"," بازیکن 2  شما وارد خیابانی شده اید که مالکش هستید  پس به نسبت تعداد خانه ها و هتل هایتان سود می کنید");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(tedad_khanehaye_boardwalk==0 && tedad_hotelhaye_boardwalk==0)
                        QMessageBox::information(this," ","هیچ هتل و خانه ای نساخته اید که سودش را دریافت کنید !");
                    else if (tedad_khanehaye_boardwalk>0 && tedad_hotelhaye_boardwalk==0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط خانه ساخته اید و هتل نساخته اید پس به ازای هر خانه ای که ساختید سود می گیرید");
                            moneyp2+=tedad_khanehaye_boardwalk*200;
                            ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_boardwalk==0 && tedad_hotelhaye_boardwalk>0)
                        {
                            QMessageBox::information(this," ","در این خیابان فقط هتل ساخته اید و خانه نساخته اید پس به ازای هر هتل ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_boardwalk*200) + (tedad_hotelhaye_boardwalk* 4*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                    else if (tedad_khanehaye_boardwalk>0 && tedad_hotelhaye_boardwalk>0)
                        {
                            QMessageBox::information(this," ","در این خیابان هم هتل ساخته اید و هم خانه ه پس به ازای هر هتل و خانه ای که ساختید سود می گیرید");
                            moneyp2+=((tedad_hotelhaye_boardwalk*200) + (tedad_hotelhaye_boardwalk*4*200) + (tedad_khanehaye_boardwalk*200));
                             ui->lineEdit_2->setText(QString::number(moneyp2));
                        }
                }
                else if(name_malek_khiaban_boardwalk==1) // malekesh harifeshe k bayad jarime vorod qeire mojaz bede
                {
                    QMessageBox::information(this,"ورود غیر مجاز","بازیکن 2 شما وارد خیابانی شدید که مالکش کس دیگری ست پس باید جریمه ورود غیر مجاز بدهید!");
                    moneyp2=ui->lineEdit_2->text().toInt();
                    if(name_malek_qale_park!=1) //age maleke oon khiaboone hamrangesh nabashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 فعلا از رنگ آبی همین یک خیابان را دارد و مالکیت قلعه پارک را هنوز کسب نکرده پس 50 دلار جریمه بدهید");

                        moneyp2-=50;
                        ui->lineEdit_2->setText(QString::number(moneyp2));

                    }
                    else if(name_malek_khiaban_boardwalk==1) //age maleke hamrangesh hm bashe
                    {
                        QMessageBox::information(this,"جریمه","بازیکن 1 انحصار رنگ آبی را دارد یعنی هم مالک قلعه پارک است و هم بوردواک پس 100 دلار جریمه بدهید");

                        moneyp2-=100;
                        ui->lineEdit_2->setText(QString::number(moneyp2));
                    }
                }

            }
        }
    }

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::on_chance_pushButton_clicked()
{
    if(ui->lineEdit_3->text()=="")
        QMessageBox::warning(this,"حواست رو جمع کن","باید شماره ی بازیکن وارد شود!!");
    else if(ui->lineEdit_3->text().toInt()==1||ui->lineEdit_3->text().toInt()==2)
    {
        chances ob;
        int r = rand()%16;
        int i;
        if(r==11 && (chancekhorojazzendanp1==1||chancekhorojazzendanp2==2)) //yani ye nafar kart khoroj ro dre v fqt yedone az in kart drim
        {
            while(r==11)
                r=rand()%16;
        }
        else{
            QString url = ob.chance_url(r);
            ui->label_7->setStyleSheet(url);

            i = ui->lineEdit_3->text().toInt();
            emalechance(r,i);
        }

        //az akhar :
        ui->lineEdit_3->setText("");//bara inke hardafe reset she o shomare bazikone ghabli namone

        ui->groupBox_3->setEnabled(false);
    }
    else {
        QMessageBox::warning(this,"حواستو جمع کن","یا 1 وارد کن یا 2 عدد دیگه قبول نیست !");
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::on_anjoman_pushButton_clicked()
{
    if(ui->lineEdit_4->text()=="")
        QMessageBox::warning(this,"حواست رو جمع کن","باید شماره ی بازیکن وارد شود!!");
    else if(ui->lineEdit_4->text().toInt()==1||ui->lineEdit_4->text().toInt()==2)
    {
        anjomanes ob;
        int r = rand()%16;
        int i;
        if(r==9 && (chestkhorojazzendanp1==1||chestkhorojazzendanp2==2))//yani ye nafar kart khoroj ro dre v fqt yedone az in kart drim
        {
            while(r==9)
                r=rand()%16;
        }
        else{
            QString url = ob.anjoman_url(r);
            ui->label_8->setStyleSheet(url);

            i = ui->lineEdit_4->text().toInt();
            emaleanjoman(r,i);
        }


        //az akhar :
        ui->lineEdit_4->setText("");//bara inke hardafe reset she o shomare bazikone ghabli namone

        ui->groupBox_4->setEnabled(false);
    }
    else {
        QMessageBox::warning(this,"حواستو جمع کن","یا 1 وارد کن یا 2 عدد دیگه قبول نیست !");
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::on_pushButton_2_clicked() //natijeye mozayedeye sherkate bargh
{
    int gheymatep1=ui->lineEdit_5->text().toInt();
    int gheymatep2=ui->lineEdit_6->text().toInt();
    double moneyp1, moneyp2;

    if((ui->lineEdit_5->text()=="" )|| (ui->lineEdit_6->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //sherkate bargh bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت برق","شرکت برق بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_sherkate_bargh=99;
        name_maleke_bargh=-1;
        ui->lineEdit_5->setText("");//reset bara gheymate jadid
        ui->lineEdit_6->setText("");//reset bara gheymate jadid
        ui->groupBox_9->hide();
    }
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت برق","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک شرکت برق بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_sherkate_bargh=100;
            name_maleke_bargh=1;
            ui->label_11->show();
            ui->groupBox_9->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت برق","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک شرکت برق بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_sherkate_bargh=100;
            name_maleke_bargh=2;
            ui->groupBox_9->hide();
            ui->label_12->show();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت برق","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_5->setText("");//reset bara gheymate jadid
            ui->lineEdit_6->setText("");//reset bara gheymate jadid
        }
    }
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت برق","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک شرکت برق بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_sherkate_bargh=100;
        name_maleke_bargh=2;
        ui->groupBox_9->hide();
        ui->label_12->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت برق","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک شرکت برق بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_sherkate_bargh=100;
        name_maleke_bargh=1;
        ui->groupBox_9->hide();
        ui->label_11->show();
    }
}

void bazi2nafare::on_pushButton_3_clicked()//natijeye mozayedeye sherkate ab
{
    int gheymatep1=ui->lineEdit_7->text().toInt();
    int gheymatep2=ui->lineEdit_8->text().toInt();
    double moneyp1, moneyp2;

    if((ui->lineEdit_7->text()=="" )|| (ui->lineEdit_8->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //sherkate ab bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت آب","شرکت آب بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_sherkate_ab=99;
        name_maleke_ab=-1;
        ui->lineEdit_7->setText("");//reset bara gheymate jadid
        ui->lineEdit_8->setText("");//reset bara gheymate jadid
        ui->groupBox_12->hide();
    }
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت آب","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک شرکت آب بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_sherkate_ab=100;
            name_maleke_ab=1;
            ui->label_17->show();
            ui->groupBox_12->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت آب","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک شرکت آب بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_sherkate_ab=100;
            name_maleke_ab=2;
            ui->groupBox_12->hide();
            ui->label_18->show();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده شرکت آب","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_7->setText("");//reset bara gheymate jadid
            ui->lineEdit_8->setText("");//reset bara gheymate jadid
        }
    }
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت آب","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک شرکت آب بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_sherkate_ab=100;
        name_maleke_ab=2;
        ui->groupBox_12->hide();
        ui->label_18->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده شرکت آب","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک شرکت آب بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_sherkate_ab=100;
        name_maleke_ab=1;
        ui->groupBox_12->hide();
        ui->label_17->show();
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::on_pushButton_5_clicked()
{
    int gheymatep1=ui->lineEdit_11->text().toInt();
    int gheymatep2=ui->lineEdit_12->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_11->text()=="" )|| (ui->lineEdit_12->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //istgah reading  bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","ایستگاه ردینگ بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_istgah_reading=99;
        name_malek_istgah_reading=-1;
        ui->lineEdit_11->setText("");//reset bara gheymate jadid
        ui->lineEdit_12->setText("");//reset bara gheymate jadid
        ui->groupBox_15->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه ردینگ بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_istgah_reading=100;
            name_malek_istgah_reading=1;
            ui->label_19->show();
            ui->groupBox_15->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه ردینگ بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_istgah_reading=100;
            name_malek_istgah_reading=2;
            ui->label_22->show();
            ui->groupBox_15->hide();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_11->setText("");//reset bara gheymate jadid
            ui->lineEdit_12->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه ردینگ بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_reading=100;
        name_malek_istgah_reading=2;
        ui->groupBox_15->hide();
        ui->label_22->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه ردینگ","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه ردینگ بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_reading=100;
        name_malek_istgah_reading=1;
        ui->groupBox_15->hide();
        ui->label_19->show();
    }

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void bazi2nafare::on_pushButton_6_clicked()
{
    int gheymatep1=ui->lineEdit_13->text().toInt();
    int gheymatep2=ui->lineEdit_14->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_13->text()=="" )|| (ui->lineEdit_14->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //istgah pensilvania  bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","ایستگاه پنسیلوانیا بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_istgah_pensilvania=99;
        name_malek_istgah_pensilvania=-1;
        ui->lineEdit_13->setText("");//reset bara gheymate jadid
        ui->lineEdit_14->setText("");//reset bara gheymate jadid
        ui->groupBox_18->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه پنسیلوانیا بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_istgah_pensilvania=100;
            name_malek_istgah_pensilvania=1;
            ui->label_25->show();
            ui->groupBox_18->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه پنسیلوانیا بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_istgah_pensilvania=100;
            name_malek_istgah_pensilvania=2;
            ui->label_27->show();
            ui->groupBox_18->hide();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_13->setText("");//reset bara gheymate jadid
            ui->lineEdit_14->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه پنسیلوانیا بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_pensilvania=100;
        name_malek_istgah_pensilvania=2;
        ui->groupBox_18->hide();
        ui->label_27->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه پنسیلوانیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه پنسیلوانیا بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_pensilvania=100;
        name_malek_istgah_pensilvania=1;
        ui->groupBox_18->hide();
        ui->label_25->show();
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bazi2nafare::on_pushButton_7_clicked()
{
    int gheymatep1=ui->lineEdit_15->text().toInt();
    int gheymatep2=ui->lineEdit_16->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_15->text()=="" )|| (ui->lineEdit_16->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //istgah pensilvania  bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","ایستگاه بی اند او بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_istgah_bo=99;
        name_malek_istgah_bo=-1;
        ui->lineEdit_15->setText("");//reset bara gheymate jadid
        ui->lineEdit_16->setText("");//reset bara gheymate jadid
        ui->groupBox_21->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه بی اند او بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_istgah_bo=100;
            name_malek_istgah_bo=1;
            ui->label_26->show();
            ui->groupBox_21->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه بی اند او بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_istgah_bo=100;
            name_malek_istgah_bo=2;
            ui->label_30->show();
            ui->groupBox_21->hide();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_15->setText("");//reset bara gheymate jadid
            ui->lineEdit_16->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه بی اند او بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_bo=100;
        name_malek_istgah_bo=2;
        ui->groupBox_21->hide();
        ui->label_30->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه بی اند او","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه بی اند او بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_bo=100;
        name_malek_istgah_bo=1;
        ui->groupBox_21->hide();
        ui->label_26->show();
    }
}


void bazi2nafare::on_pushButton_8_clicked()
{
    int gheymatep1=ui->lineEdit_17->text().toInt();
    int gheymatep2=ui->lineEdit_18->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_17->text()=="" )|| (ui->lineEdit_18->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) //istgah pensilvania  bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","ایستگاه شورت لاین بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_istgah_shortline=99;
        name_malek_istgah_shortline=-1;
        ui->lineEdit_17->setText("");//reset bara gheymate jadid
        ui->lineEdit_18->setText("");//reset bara gheymate jadid
        ui->groupBox_25->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه شورت لاین بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_istgah_shortline=100;
            name_malek_istgah_shortline=1;
            ui->label_33->show();
            ui->groupBox_25->hide();
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه شورت لاین بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_istgah_shortline=100;
            name_malek_istgah_shortline=2;
            ui->label_34->show();
            ui->groupBox_25->hide();
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_17->setText("");//reset bara gheymate jadid
            ui->lineEdit_18->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاهشورت لاین بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_istgah_shortline=100;
        name_malek_istgah_shortline=2;
        ui->groupBox_25->hide();
        ui->label_34->show();
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده ایستگاه شورت لاین","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک ایستگاه شورت لاین بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_istgah_shortline=100;
        name_malek_istgah_shortline=1;
        ui->groupBox_25->hide();
        ui->label_33->show();
    }
}

void bazi2nafare::on_pushButton_9_clicked()
{
    int gheymatep1=ui->lineEdit_19->text().toInt();
    int gheymatep2=ui->lineEdit_20->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_19->text()=="" )|| (ui->lineEdit_20->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","خیابان مدیترانه بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_meditarane=99;
        name_malek_khiaban_meditarane=-1;
        ui->lineEdit_19->setText("");//reset bara gheymate jadid
        ui->lineEdit_20->setText("");//reset bara gheymate jadid
        ui->groupBox_28->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان مدیترانه بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_meditarane=100;
            name_malek_khiaban_meditarane=1;
            ui->label_38->show();
            ui->groupBox_28->hide();
            ui->comboBox_20->addItem("خیابان مدیترانه");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان مدیترانه بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_meditarane=100;
            name_malek_khiaban_meditarane=2;
            ui->label_39->show();
            ui->groupBox_28->hide();
            ui->comboBox_21->addItem("خیابان مدیترانه");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_19->setText("");//reset bara gheymate jadid
            ui->lineEdit_20->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان مدیترانه بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_meditarane=100;
        name_malek_khiaban_meditarane=2;
        ui->groupBox_28->hide();
        ui->label_39->show();
        ui->comboBox_21->addItem("خیابان مدیترانه");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان مدیترانه","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان مدیترانه بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_meditarane=100;
        name_malek_khiaban_meditarane=1;
        ui->groupBox_28->hide();
        ui->label_38->show();
        ui->comboBox_20->addItem("خیابان مدیترانه");
    }
}

void bazi2nafare::on_pushButton_10_clicked()
{
    int gheymatep1=ui->lineEdit_21->text().toInt();
    int gheymatep2=ui->lineEdit_22->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_21->text()=="" )|| (ui->lineEdit_22->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","خیابان بالتیک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_baltic=99;
        name_malek_khiaban_baltic=-1;
        ui->lineEdit_21->setText("");//reset bara gheymate jadid
        ui->lineEdit_22->setText("");//reset bara gheymate jadid
        ui->groupBox_31->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بالتیک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_baltic=100;
            name_malek_khiaban_baltic=1;
            ui->label_42->show();
            ui->groupBox_31->hide();
            ui->comboBox_20->addItem("خیابان بالتیک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بالتیک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_baltic=100;
            name_malek_khiaban_baltic=2;
            ui->label_43->show();
            ui->groupBox_31->hide();
            ui->comboBox_21->addItem("خیابان بالتیک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_21->setText("");//reset bara gheymate jadid
            ui->lineEdit_22->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بالتیک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_baltic=100;
        name_malek_khiaban_baltic=2;
        ui->groupBox_31->hide();
        ui->label_43->show();
        ui->comboBox_21->addItem("خیابان بالتیک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بالتیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بالتیک  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_baltic=100;
        name_malek_khiaban_baltic=1;
        ui->groupBox_31->hide();
        ui->label_42->show();
        ui->comboBox_20->addItem("خیابان بالتیک");
    }
}

void bazi2nafare::on_pushButton_11_clicked()
{
    int gheymatep1=ui->lineEdit_23->text().toInt();
    int gheymatep2=ui->lineEdit_24->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_23->text()=="" )|| (ui->lineEdit_24->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه پارک","قلعه پارک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_qale_park=99;
        name_malek_qale_park=-1;
        ui->lineEdit_23->setText("");//reset bara gheymate jadid
        ui->lineEdit_24->setText("");//reset bara gheymate jadid
        ui->groupBox_35->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه پارک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه پارک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_park=100;
            name_malek_qale_park=1;
            ui->label_51->show();
            ui->groupBox_35->hide();
            ui->comboBox_20->addItem("قلعه پارک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه پارک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه پارک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_park=100;
            name_malek_qale_park=2;
            ui->label_52->show();
            ui->groupBox_35->hide();
            ui->comboBox_21->addItem("قلعه پارک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه پارک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_23->setText("");//reset bara gheymate jadid
            ui->lineEdit_24->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه پارک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه پارک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_qale_park=100;
        name_malek_qale_park=2;
        ui->groupBox_35->hide();
        ui->label_52->show();
        ui->comboBox_21->addItem("قلعه پارک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه پارک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه پارک  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_qale_park=100;
        name_malek_qale_park=1;
        ui->groupBox_35->hide();
        ui->label_51->show();
        ui->comboBox_20->addItem("قلعه پارک");
    }
}

void bazi2nafare::on_pushButton_12_clicked()
{
    int gheymatep1=ui->lineEdit_25->text().toInt();
    int gheymatep2=ui->lineEdit_26->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_25->text()=="" )|| (ui->lineEdit_26->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","خیابان بوردواک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_boardwalk=99;
        name_malek_khiaban_boardwalk=-1;
        ui->lineEdit_25->setText("");//reset bara gheymate jadid
        ui->lineEdit_26->setText("");//reset bara gheymate jadid
        ui->groupBox_38->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بوردواک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_boardwalk=100;
            name_malek_khiaban_boardwalk=1;
            ui->label_55->show();
            ui->groupBox_38->hide();
            ui->comboBox_20->addItem("خیابان بوردواک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بوردواک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_boardwalk=100;
            name_malek_khiaban_boardwalk=2;
            ui->label_56->show();
            ui->groupBox_38->hide();
            ui->comboBox_21->addItem("خیابان بوردواک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_25->setText("");//reset bara gheymate jadid
            ui->lineEdit_26->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بوردواک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_boardwalk=100;
        name_malek_khiaban_boardwalk=2;
        ui->groupBox_35->hide();
        ui->label_56->show();
        ui->comboBox_21->addItem("خیابان بوردواک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان بوردواک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان بوردواک  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_boardwalk=100;
        name_malek_khiaban_boardwalk=1;
        ui->groupBox_38->hide();
        ui->label_55->show();
        ui->comboBox_20->addItem("خیابان بوردواک");
    }
}

void bazi2nafare::on_pushButton_13_clicked()
{
    int gheymatep1=ui->lineEdit_27->text().toInt();
    int gheymatep2=ui->lineEdit_28->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_27->text()=="" )|| (ui->lineEdit_28->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","خیابان اورینتال بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_oriental=99;
        name_malek_khiaban_oriental=-1;
        ui->lineEdit_27->setText("");//reset bara gheymate jadid
        ui->lineEdit_28->setText("");//reset bara gheymate jadid
        ui->groupBox_41->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان اورینتال بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_oriental=100;
            name_malek_khiaban_oriental=1;
            ui->label_63->show();
            ui->groupBox_41->hide();
            ui->comboBox_20->addItem("خیابان اورینتال");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان اورینتال بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_oriental=100;
            name_malek_khiaban_oriental=2;
            ui->label_64->show();
            ui->groupBox_41->hide();
            ui->comboBox_21->addItem("خیابان اورینتال");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_27->setText("");//reset bara gheymate jadid
            ui->lineEdit_28->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان اورینتال بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_oriental=100;
        name_malek_khiaban_oriental=2;
        ui->groupBox_41->hide();
        ui->label_64->show();
        ui->comboBox_21->addItem("خیابان اورینتال");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان اورینتال","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان اورینتال  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_oriental=100;
        name_malek_khiaban_oriental=1;
        ui->groupBox_41->hide();
        ui->label_63->show();
        ui->comboBox_20->addItem("خیابان اورینتال");
    }
}

void bazi2nafare::on_pushButton_14_clicked()
{
    int gheymatep1=ui->lineEdit_29->text().toInt();
    int gheymatep2=ui->lineEdit_30->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_29->text()=="" )|| (ui->lineEdit_30->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","خیابان ورمونت بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_vermont=99;
        name_malek_khiaban_vermont=-1;
        ui->lineEdit_29->setText("");//reset bara gheymate jadid
        ui->lineEdit_30->setText("");//reset bara gheymate jadid
        ui->groupBox_44->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ورمونت بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_vermont=100;
            name_malek_khiaban_vermont=1;
            ui->label_69->show();
            ui->groupBox_44->hide();
            ui->comboBox_20->addItem("خیابان ورمونت");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ورمونت بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_vermont=100;
            name_malek_khiaban_vermont=2;
            ui->label_70->show();
            ui->groupBox_44->hide();
            ui->comboBox_21->addItem("خیابان ورمونت");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_29->setText("");//reset bara gheymate jadid
            ui->lineEdit_30->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ورمونت بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_vermont=100;
        name_malek_khiaban_vermont=2;
        ui->groupBox_44->hide();
        ui->label_70->show();
        ui->comboBox_21->addItem("خیابان ورمونت");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ورمونت","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ورمونت  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_vermont=100;
        name_malek_khiaban_vermont=1;
        ui->groupBox_44->hide();
        ui->label_69->show();
        ui->comboBox_20->addItem("خیابان ورمونت");
    }
}

void bazi2nafare::on_pushButton_15_clicked()
{
    int gheymatep1=ui->lineEdit_31->text().toInt();
    int gheymatep2=ui->lineEdit_32->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_31->text()=="" )|| (ui->lineEdit_32->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","خیابان کانکتیکات بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_conecticut=99;
        name_malek_khiaban_conecticut=-1;
        ui->lineEdit_31->setText("");//reset bara gheymate jadid
        ui->lineEdit_32->setText("");//reset bara gheymate jadid
        ui->groupBox_47->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کانکتیکات بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_conecticut=100;
            name_malek_khiaban_conecticut=1;
            ui->label_75->show();
            ui->groupBox_47->hide();
            ui->comboBox_20->addItem("خیابان کانکتیکات");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کانکتیکات بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_conecticut=100;
            name_malek_khiaban_conecticut=2;
            ui->label_76->show();
            ui->groupBox_47->hide();
            ui->comboBox_21->addItem("خیابان کانکتیکات");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_31->setText("");//reset bara gheymate jadid
            ui->lineEdit_32->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کانکتیکات بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_conecticut=100;
        name_malek_khiaban_conecticut=2;
        ui->groupBox_47->hide();
        ui->label_76->show();
        ui->comboBox_21->addItem("خیابان کانکتیکات");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کانکتیکات","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کانکتیکات بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_conecticut=100;
        name_malek_khiaban_conecticut=1;
        ui->groupBox_47->hide();
        ui->label_75->show();
        ui->comboBox_20->addItem("خیابان کانکتیکات");
    }
}

void bazi2nafare::on_pushButton_16_clicked()
{
    int gheymatep1=ui->lineEdit_33->text().toInt();
    int gheymatep2=ui->lineEdit_34->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_33->text()=="" )|| (ui->lineEdit_34->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","قلعه چارلز بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_qale_charls=99;
        name_malek_qale_charls=-1;
        ui->lineEdit_33->setText("");//reset bara gheymate jadid
        ui->lineEdit_34->setText("");//reset bara gheymate jadid
        ui->groupBox_50->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه چارلز بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_charls=100;
            name_malek_qale_charls=1;
            ui->label_81->show();
            ui->groupBox_50->hide();
            ui->comboBox_20->addItem("قلعه چارلز");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه چارلز بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_charls=100;
            name_malek_qale_charls=2;
            ui->label_82->show();
            ui->groupBox_50->hide();
            ui->comboBox_21->addItem("قلعه چارلز");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_33->setText("");//reset bara gheymate jadid
            ui->lineEdit_34->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه چارلز بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_qale_charls=100;
        name_malek_qale_charls=2;
        ui->groupBox_50->hide();
        ui->label_82->show();
        ui->comboBox_21->addItem("قلعه چارلز");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه چارلز","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه چارلز  بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_qale_charls=100;
        name_malek_qale_charls=1;
        ui->groupBox_50->hide();
        ui->label_81->show();
        ui->comboBox_20->addItem("قلعه چارلز");
    }
}

void bazi2nafare::on_pushButton_17_clicked()
{
    int gheymatep1=ui->lineEdit_35->text().toInt();
    int gheymatep2=ui->lineEdit_36->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_35->text()=="" )|| (ui->lineEdit_36->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","خیابان استیتس بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_stats=99;
        name_malek_khiaban_stats=-1;
        ui->lineEdit_35->setText("");//reset bara gheymate jadid
        ui->lineEdit_36->setText("");//reset bara gheymate jadid
        ui->groupBox_53->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان استیتس بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_stats=100;
            name_malek_khiaban_stats=1;
            ui->label_87->show();
            ui->groupBox_53->hide();
            ui->comboBox_20->addItem("خیابان استیتس");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان استیتس بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_stats=100;
            name_malek_khiaban_stats=2;
            ui->label_88->show();
            ui->groupBox_53->hide();
            ui->comboBox_21->addItem("خیابان استیتس");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_35->setText("");//reset bara gheymate jadid
            ui->lineEdit_36->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان استیتس بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_stats=100;
        name_malek_khiaban_stats=2;
        ui->groupBox_53->hide();
        ui->label_88->show();
        ui->comboBox_21->addItem("خیابان استیتس");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان استیتس","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان استیتس بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_stats=100;
        name_malek_khiaban_stats=1;
        ui->groupBox_53->hide();
        ui->label_87->show();
        ui->comboBox_20->addItem("خیابان استیتس");
    }
}

void bazi2nafare::on_pushButton_18_clicked()
{
    int gheymatep1=ui->lineEdit_37->text().toInt();
    int gheymatep2=ui->lineEdit_38->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_37->text()=="" )|| (ui->lineEdit_38->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","خیابان ویرجینیا بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_virginia=99;
        name_malek_khiaban_virginia=-1;
        ui->lineEdit_37->setText("");//reset bara gheymate jadid
        ui->lineEdit_38->setText("");//reset bara gheymate jadid
        ui->groupBox_56->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ویرجینیا بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_virginia=100;
            name_malek_khiaban_virginia=1;
            ui->label_93->show();
            ui->groupBox_56->hide();
            ui->comboBox_20->addItem("خیابان ویرجینیا");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ویرجینیا بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_virginia=100;
            name_malek_khiaban_virginia=2;
            ui->label_94->show();
            ui->groupBox_56->hide();
            ui->comboBox_21->addItem("خیابان ویرجینیا");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_37->setText("");//reset bara gheymate jadid
            ui->lineEdit_38->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ویرجینیا بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_virginia=100;
        name_malek_khiaban_virginia=2;
        ui->groupBox_56->hide();
        ui->label_94->show();
        ui->comboBox_21->addItem("خیابان ویرجینیا");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ویرجینیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ویرجینیا بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_virginia=100;
        name_malek_khiaban_virginia=1;
        ui->groupBox_56->hide();
        ui->label_93->show();
        ui->comboBox_20->addItem("خیابان ویرجینیا");
    }
}

void bazi2nafare::on_pushButton_19_clicked()
{
    int gheymatep1=ui->lineEdit_39->text().toInt();
    int gheymatep2=ui->lineEdit_40->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_39->text()=="" )|| (ui->lineEdit_40->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه جیمز","قلعه جیمز بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_qale_jims=99;
        name_malek_qale_jims=-1;
        ui->lineEdit_39->setText("");//reset bara gheymate jadid
        ui->lineEdit_40->setText("");//reset bara gheymate jadid
        ui->groupBox_59->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه جیمزا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه جیمز بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_qale_jims=100;
            name_malek_qale_jims=1;
            ui->label_99->show();
            ui->groupBox_59->hide();
            ui->comboBox_20->addItem("قلعه جیمز");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه جیمز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه جیمز بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_qale_jims=100;
            name_malek_qale_jims=2;
            ui->label_100->show();
            ui->groupBox_59->hide();
            ui->comboBox_21->addItem("قلعه جیمز");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده قلعه جیمز","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_39->setText("");//reset bara gheymate jadid
            ui->lineEdit_40->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه جیمز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک قلعه جیمز بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_qale_jims=100;
        name_malek_qale_jims=2;
        ui->groupBox_59->hide();
        ui->label_100->show();
        ui->comboBox_21->addItem("قلعه جیمز");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده قلعه جیمز","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک قلعه جیمز بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_qale_jims=100;
        name_malek_qale_jims=1;
        ui->groupBox_59->hide();
        ui->label_99->show();
        ui->comboBox_20->addItem("قلعه جیمز");
    }
}

void bazi2nafare::on_pushButton_20_clicked()
{
    int gheymatep1=ui->lineEdit_41->text().toInt();
    int gheymatep2=ui->lineEdit_42->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_41->text()=="" )|| (ui->lineEdit_42->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","خیابان تنسی بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_tenesi=99;
        name_malek_khiaban_tenesi=-1;
        ui->lineEdit_41->setText("");//reset bara gheymate jadid
        ui->lineEdit_42->setText("");//reset bara gheymate jadid
        ui->groupBox_62->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان تنسی بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_tenesi=100;
            name_malek_khiaban_tenesi=1;
            ui->label_105->show();
            ui->groupBox_62->hide();
            ui->comboBox_20->addItem("خیابان تنسی");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان تنسی بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_tenesi=100;
            name_malek_khiaban_tenesi=2;
            ui->label_106->show();
            ui->groupBox_62->hide();
            ui->comboBox_21->addItem("خیابان تنسی");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_41->setText("");//reset bara gheymate jadid
            ui->lineEdit_42->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان تنسی بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_tenesi=100;
        name_malek_khiaban_tenesi=2;
        ui->groupBox_62->hide();
        ui->label_106->show();
        ui->comboBox_21->addItem("خیابان تنسی");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان تنسی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان تنسی بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_tenesi=100;
        name_malek_khiaban_tenesi=1;
        ui->groupBox_62->hide();
        ui->label_105->show();
        ui->comboBox_20->addItem("خیابان تنسی");
    }
}

void bazi2nafare::on_pushButton_21_clicked()
{
    int gheymatep1=ui->lineEdit_43->text().toInt();
    int gheymatep2=ui->lineEdit_44->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_43->text()=="" )|| (ui->lineEdit_44->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","خیابان نیویورک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_newyork=99;
        name_malek_khiaban_newyork=-1;
        ui->lineEdit_43->setText("");//reset bara gheymate jadid
        ui->lineEdit_44->setText("");//reset bara gheymate jadid
        ui->groupBox_65->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان نیویورک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_newyork=100;
            name_malek_khiaban_newyork=1;
            ui->label_111->show();
            ui->groupBox_65->hide();
            ui->comboBox_20->addItem("خیابان نیویورک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان نیویورک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_newyork=100;
            name_malek_khiaban_newyork=2;
            ui->label_112->show();
            ui->groupBox_65->hide();
            ui->comboBox_21->addItem("خیابان نیویورک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_43->setText("");//reset bara gheymate jadid
            ui->lineEdit_44->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان نیویورک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_newyork=100;
        name_malek_khiaban_newyork=2;
        ui->groupBox_65->hide();
        ui->label_112->show();
        ui->comboBox_21->addItem("خیابان نیویورک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان نیویورک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان نیویورک بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_newyork=100;
        name_malek_khiaban_newyork=1;
        ui->groupBox_65->hide();
        ui->label_111->show();
        ui->comboBox_20->addItem("خیابان نیویورک");
    }
}

void bazi2nafare::on_pushButton_22_clicked()
{
    int gheymatep1=ui->lineEdit_45->text().toInt();
    int gheymatep2=ui->lineEdit_46->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_45->text()=="" )|| (ui->lineEdit_46->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","خیابان کنتاکی بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_kentucky=99;
        name_malek_khiaban_kentucky=-1;
        ui->lineEdit_45->setText("");//reset bara gheymate jadid
        ui->lineEdit_46->setText("");//reset bara gheymate jadid
        ui->groupBox_68->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کنتاکی بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_kentucky=100;
            name_malek_khiaban_kentucky=1;
            ui->label_117->show();
            ui->groupBox_68->hide();
            ui->comboBox_20->addItem("خیابان کنتاکی");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کنتاکی بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_kentucky=100;
            name_malek_khiaban_kentucky=2;
            ui->label_118->show();
            ui->groupBox_68->hide();
            ui->comboBox_21->addItem("خیابان کنتاکی");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_45->setText("");//reset bara gheymate jadid
            ui->lineEdit_46->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کنتاکی بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_kentucky=100;
        name_malek_khiaban_kentucky=2;
        ui->groupBox_68->hide();
        ui->label_118->show();
        ui->comboBox_21->addItem("خیابان کنتاکی");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کنتاکی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کنتاکی بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_kentucky=100;
        name_malek_khiaban_kentucky=1;
        ui->groupBox_68->hide();
        ui->label_117->show();
        ui->comboBox_20->addItem("خیابان کنتاکی");
    }
}

void bazi2nafare::on_pushButton_23_clicked()
{
    int gheymatep1=ui->lineEdit_47->text().toInt();
    int gheymatep2=ui->lineEdit_48->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_47->text()=="" )|| (ui->lineEdit_48->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","خیابان ایندیانا بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_indiana=99;
        name_malek_khiaban_indiana=-1;
        ui->lineEdit_47->setText("");//reset bara gheymate jadid
        ui->lineEdit_48->setText("");//reset bara gheymate jadid
        ui->groupBox_71->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایندیانا بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_indiana=100;
            name_malek_khiaban_indiana=1;
            ui->label_123->show();
            ui->groupBox_71->hide();
            ui->comboBox_20->addItem("خیابان ایندیانا");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایندیانا بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_indiana=100;
            name_malek_khiaban_indiana=2;
            ui->label_124->show();
            ui->groupBox_71->hide();
            ui->comboBox_21->addItem("خیابان ایندیانا");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_47->setText("");//reset bara gheymate jadid
            ui->lineEdit_48->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایندیانا بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_indiana=100;
        name_malek_khiaban_indiana=2;
        ui->groupBox_71->hide();
        ui->label_124->show();
        ui->comboBox_21->addItem("خیابان ایندیانا");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایندیانا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایندیانا بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_indiana=100;
        name_malek_khiaban_indiana=1;
        ui->groupBox_71->hide();
        ui->label_123->show();
        ui->comboBox_20->addItem("خیابان ایندیانا");
    }
}

void bazi2nafare::on_pushButton_24_clicked()
{
    int gheymatep1=ui->lineEdit_49->text().toInt();
    int gheymatep2=ui->lineEdit_50->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_49->text()=="" )|| (ui->lineEdit_50->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","خیابان ایلینویز بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_ilinois=99;
        name_malek_khiaban_ilinois=-1;
        ui->lineEdit_49->setText("");//reset bara gheymate jadid
        ui->lineEdit_50->setText("");//reset bara gheymate jadid
        ui->groupBox_74->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایلینویز بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_ilinois=100;
            name_malek_khiaban_ilinois=1;
            ui->label_129->show();
            ui->groupBox_74->hide();
            ui->comboBox_20->addItem("خیابان ایلینویز");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایلینویز بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_ilinois=100;
            name_malek_khiaban_ilinois=2;
            ui->label_130->show();
            ui->groupBox_74->hide();
            ui->comboBox_21->addItem("خیابان ایلینویز");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_49->setText("");//reset bara gheymate jadid
            ui->lineEdit_50->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایلینویز بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_ilinois=100;
        name_malek_khiaban_ilinois=2;
        ui->groupBox_74->hide();
        ui->label_130->show();
        ui->comboBox_21->addItem("خیابان ایلینویز");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ایلینویز","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ایلینویز بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_ilinois=100;
        name_malek_khiaban_ilinois=1;
        ui->groupBox_74->hide();
        ui->label_129->show();
        ui->comboBox_20->addItem("خیابان ایلینویز");
    }
}

void bazi2nafare::on_pushButton_25_clicked()
{
    int gheymatep1=ui->lineEdit_51->text().toInt();
    int gheymatep2=ui->lineEdit_52->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_51->text()=="" )|| (ui->lineEdit_52->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","خیابان آتلانتیک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_atlantic=99;
        name_malek_khiaban_atlantic=-1;
        ui->lineEdit_51->setText("");//reset bara gheymate jadid
        ui->lineEdit_52->setText("");//reset bara gheymate jadid
        ui->groupBox_77->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان آتلانتیک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_atlantic=100;
            name_malek_khiaban_atlantic=1;
            ui->label_135->show();
            ui->groupBox_77->hide();
            ui->comboBox_20->addItem("خیابان آتلانتیک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان آتلانتیک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_atlantic=100;
            name_malek_khiaban_atlantic=2;
            ui->label_136->show();
            ui->groupBox_77->hide();
            ui->comboBox_21->addItem("خیابان آتلانتیک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_51->setText("");//reset bara gheymate jadid
            ui->lineEdit_52->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان آتلانتیک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_atlantic=100;
        name_malek_khiaban_atlantic=2;
        ui->groupBox_77->hide();
        ui->label_136->show();
        ui->comboBox_21->addItem("خیابان آتلانتیک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان آتلانتیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان آتلانتیک بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_atlantic=100;
        name_malek_khiaban_atlantic=1;
        ui->groupBox_77->hide();
        ui->label_135->show();
        ui->comboBox_20->addItem("خیابان آتلانتیک");
    }
}

void bazi2nafare::on_pushButton_26_clicked()
{
    int gheymatep1=ui->lineEdit_53->text().toInt();
    int gheymatep2=ui->lineEdit_54->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_53->text()=="" )|| (ui->lineEdit_54->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","خیابان ونتوربدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_ventor=99;
        name_malek_khiaban_ventor=-1;
        ui->lineEdit_53->setText("");//reset bara gheymate jadid
        ui->lineEdit_54->setText("");//reset bara gheymate jadid
        ui->groupBox_80->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ونتور بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_ventor=100;
            name_malek_khiaban_ventor=1;
            ui->label_141->show();
            ui->groupBox_80->hide();
            ui->comboBox_20->addItem("خیابان ونتور");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ونتور بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_ventor=100;
            name_malek_khiaban_ventor=2;
            ui->label_142->show();
            ui->groupBox_80->hide();
            ui->comboBox_21->addItem("خیابان ونتور");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_53->setText("");//reset bara gheymate jadid
            ui->lineEdit_54->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ونتور بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_ventor=100;
        name_malek_khiaban_ventor=2;
        ui->groupBox_80->hide();
        ui->label_142->show();
        ui->comboBox_21->addItem("خیابان ونتور");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان ونتور","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان ونتور بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_ventor=100;
        name_malek_khiaban_ventor=1;
        ui->groupBox_80->hide();
        ui->label_141->show();
        ui->comboBox_20->addItem("خیابان ونتور");
    }
}

void bazi2nafare::on_pushButton_27_clicked()
{
    int gheymatep1=ui->lineEdit_55->text().toInt();
    int gheymatep2=ui->lineEdit_56->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_55->text()=="" )|| (ui->lineEdit_56->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده باغ ماروین","باغ ماروین بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_marvin=99;
        name_malek_khiaban_marvin=-1;
        ui->lineEdit_55->setText("");//reset bara gheymate jadid
        ui->lineEdit_56->setText("");//reset bara gheymate jadid
        ui->groupBox_83->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده باغ ماروین","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک باغ ماروین بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_marvin=100;
            name_malek_khiaban_marvin=1;
            ui->label_147->show();
            ui->groupBox_83->hide();
            ui->comboBox_20->addItem("باغ ماروین");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده باغ ماروین","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک باغ ماروین بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_marvin=100;
            name_malek_khiaban_marvin=2;
            ui->label_148->show();
            ui->groupBox_83->hide();
            ui->comboBox_21->addItem("باغ ماروین");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده باغ ماروین","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_55->setText("");//reset bara gheymate jadid
            ui->lineEdit_56->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده باغ ماروین","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک باغ ماروین بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_marvin=100;
        name_malek_khiaban_marvin=2;
        ui->groupBox_83->hide();
        ui->label_148->show();
        ui->comboBox_21->addItem("باغ ماروینر");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده باغ ماروین","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک باغ ماروین بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_marvin=100;
        name_malek_khiaban_marvin=1;
        ui->groupBox_83->hide();
        ui->label_147->show();
        ui->comboBox_20->addItem("باغ ماروین");
    }
}

void bazi2nafare::on_pushButton_28_clicked()
{
    int gheymatep1=ui->lineEdit_57->text().toInt();
    int gheymatep2=ui->lineEdit_58->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_57->text()=="" )|| (ui->lineEdit_58->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","خیابان پاسیفیک بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_pacific=99;
        name_malek_khiaban_pacific=-1;
        ui->lineEdit_57->setText("");//reset bara gheymate jadid
        ui->lineEdit_58->setText("");//reset bara gheymate jadid
        ui->groupBox_86->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پاسیفیک بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_pacific=100;
            name_malek_khiaban_pacific=1;
            ui->label_153->show();
            ui->groupBox_86->hide();
            ui->comboBox_20->addItem("خیابان پاسیفیک");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پاسیفیک بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_pacific=100;
            name_malek_khiaban_pacific=2;
            ui->label_154->show();
            ui->groupBox_86->hide();
            ui->comboBox_21->addItem("خیابان پاسیفیک");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_57->setText("");//reset bara gheymate jadid
            ui->lineEdit_58->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پاسیفیک بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_pacific=100;
        name_malek_khiaban_pacific=2;
        ui->groupBox_86->hide();
        ui->label_154->show();
        ui->comboBox_21->addItem("خیابان پاسیفیک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پاسیفیک","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پاسیفیک بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_pacific=100;
        name_malek_khiaban_pacific=1;
        ui->groupBox_86->hide();
        ui->label_153->show();
        ui->comboBox_20->addItem("خیابان پاسیفیک");
    }
}

void bazi2nafare::on_pushButton_29_clicked()
{
    int gheymatep1=ui->lineEdit_59->text().toInt();
    int gheymatep2=ui->lineEdit_60->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_59->text()=="" )|| (ui->lineEdit_60->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","خیابان کارولینای شمالی بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_northcarolina=99;
        name_malek_khiaban_northcarolina=-1;
        ui->lineEdit_59->setText("");//reset bara gheymate jadid
        ui->lineEdit_60->setText("");//reset bara gheymate jadid
        ui->groupBox_89->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کارولینای شمالی بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_northcarolina=100;
            name_malek_khiaban_northcarolina=1;
            ui->label_159->show();
            ui->groupBox_89->hide();
            ui->comboBox_20->addItem("خیابان کارولینای شمالی");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کارولینای شمالی بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_northcarolina=100;
            name_malek_khiaban_northcarolina=2;
            ui->label_160->show();
            ui->groupBox_89->hide();
            ui->comboBox_21->addItem("خیابان کارولینای شمالی");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_59->setText("");//reset bara gheymate jadid
            ui->lineEdit_60->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کارولینای شمالی بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_northcarolina=100;
        name_malek_khiaban_northcarolina=2;
        ui->groupBox_89->hide();
        ui->label_160->show();
        ui->comboBox_21->addItem("خیابان پاسیفیک");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان کارولینای شمالی","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان کارولینای شمالی بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_northcarolina=100;
        name_malek_khiaban_northcarolina=1;
        ui->groupBox_89->hide();
        ui->label_159->show();
        ui->comboBox_20->addItem("خیابان کارولینای شمالی");
    }
}

void bazi2nafare::on_pushButton_30_clicked()
{
    int gheymatep1=ui->lineEdit_61->text().toInt();
    int gheymatep2=ui->lineEdit_62->text().toInt();
    double moneyp1, moneyp2;
    if((ui->lineEdit_61->text()=="" )|| (ui->lineEdit_62->text()==""))
        QMessageBox::warning(this,"یه نفر قیمتی پیشنهاد نداده!","لطفا حتی اگر قیمتی نمیخواهید بدهید باکس خود را خالی نزارید و عددی زیر 10 یا 0 بدهید!");
    else if(gheymatep1<10 && gheymatep2<10) // bi malek mimoone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","خیابان پنسیلوانیا بدون مالک ماند چون هردو زیر 10 دلار پیشنهاد دادید!");
        malek_khiaban_pensilvania=99;
        name_malek_khiaban_pensilvania=-1;
        ui->lineEdit_60->setText("");//reset bara gheymate jadid
        ui->lineEdit_61->setText("");//reset bara gheymate jadid
        ui->groupBox_92->hide();
    }
    /////////
    else if(gheymatep1>=10 && gheymatep2>=10)
    {
        if(gheymatep1>gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پنسیلوانیا بازیکن 1 شد!");
            moneyp1=ui->lineEdit->text().toInt();
            moneyp1-=gheymatep1;
            ui->lineEdit->setText(QString::number(moneyp1));
            malek_khiaban_pensilvania=100;
            name_malek_khiaban_pensilvania=1;
            ui->label_165->show();
            ui->groupBox_92->hide();
            ui->comboBox_20->addItem("خیابان پنسیلوانیا");
        }
        else if(gheymatep2>gheymatep1)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پنسیلوانیا بازیکن 2 شد!");
            moneyp2=ui->lineEdit_2->text().toInt();
            moneyp2-=gheymatep2;
            ui->lineEdit_2->setText(QString::number(moneyp2));
            malek_khiaban_pensilvania=100;
            name_malek_khiaban_pensilvania=2;
            ui->label_166->show();
            ui->groupBox_92->hide();
            ui->comboBox_21->addItem("خیابان پنسیلوانیا");
        }
        else if (gheymatep1==gheymatep2)
        {
            QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","هردو قیمت یکسانی پیشنهاد دادید لطفا  دوباره قیمت خود را وارد کنید ");
            ui->lineEdit_61->setText("");//reset bara gheymate jadid
            ui->lineEdit_62->setText("");//reset bara gheymate jadid
        }
    }
    /////////
    else if(gheymatep1<10 && gheymatep2>=10) // pas hatman p2 malek mishe niaz b moghayese nist o p1 kamtar az 10 pishnhad dade o to mozayede shrkt nmikone
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","بازیکن 2 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پنسیلوانیا بازیکن 2 شد!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=gheymatep2;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        malek_khiaban_pensilvania=100;
        name_malek_khiaban_pensilvania=2;
        ui->groupBox_92->hide();
        ui->label_166->show();
        ui->comboBox_21->addItem("خیابان پنسیلوانیا");
    }
    else if(gheymatep2<10 && gheymatep1>=10)
    {
        QMessageBox::information(this,"نتیجه مزایده خیابان پنسیلوانیا","بازیکن 1 قیمت بالاتری را پیشنهاد داد پس مالک خیابان پنسیلوانیا بازیکن 1 شد!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=gheymatep1;
        ui->lineEdit->setText(QString::number(moneyp1));
        malek_khiaban_pensilvania=100;
        name_malek_khiaban_pensilvania=1;
        ui->groupBox_92->hide();
        ui->label_165->show();
        ui->comboBox_20->addItem("خیابان پنسیلوانیا");
    }
}



void bazi2nafare::on_pushButton_31_clicked()
{
    double moneyp1;
    int d1, d2;
    if(tedadbaretasrizip1<=2)
    {
        d1 = (rand()%6) + 1;
        d2 = (rand()%6) + 1;
        ui->label_226->setText(QString::number(d1));
        ui->label_227->setText(QString::number(d2));
        if(d1==d2)
        {
            QMessageBox::information(this," ", " شما جفت تاس اورده و از زندان خارج شدید حالا تاس بریزید!");
            injail_p1=-1;
            ui->tasrizip1_pushButton->setEnabled(true);
            tedadbaretasrizip1=0;//bara seri haye bad
            ui->groupBox_98->hide();
        }
        else
        {
            QMessageBox::warning(this," ","جفت تاس نیاوردید دوباره امتحان کنید!");
             tedadbaretasrizip1++;
        }
    }
    else if(tedadbaretasrizip1==3){

        QMessageBox::warning(this," ","به اندازه کافی تلاش کردید ولی جفت تاس نیاوردید پس 50 دلار از حسابتان کسر شد و شما از زندان ازاد شدید!");
        moneyp1=ui->lineEdit->text().toInt();
        moneyp1-=50;
        ui->lineEdit->setText(QString::number(moneyp1));
        injail_p1=-1;
        ui->tasrizip1_pushButton->setEnabled(true);

    }


}

void bazi2nafare::on_pushButton_32_clicked()
{
    double moneyp2;
    int d1, d2;
    if(tedadbaretasrizip2<=2)
    {
        d1 = (rand()%6) + 1;
        d2 = (rand()%6) + 1;
        ui->label_228->setText(QString::number(d1));
        ui->label_229->setText(QString::number(d2));
        if(d1==d2)
        {
            QMessageBox::information(this," ", " شما جفت تاس اورده و از زندان خارج شدید حالا تاس بریزید!");
            injail_p2=-1;
            ui->tasrizip2_pushButton->setEnabled(true);
            tedadbaretasrizip2=0;//bara seri haye bad
            ui->groupBox_99->hide();
        }
        else
        {
            QMessageBox::warning(this," ","جفت تاس نیاوردید دوباره امتحان کنید!");
             tedadbaretasrizip2++;
        }
    }
    else if(tedadbaretasrizip2==3){

        QMessageBox::warning(this," ","به اندازه کافی تلاش کردید ولی جفت تاس نیاوردید پس 50 دلار از حسابتان کسر شد و شما از زندان ازاد شدید!");
        moneyp2=ui->lineEdit_2->text().toInt();
        moneyp2-=50;
        ui->lineEdit_2->setText(QString::number(moneyp2));
        injail_p2=-1;
        ui->groupBox_99->hide();
        ui->tasrizip2_pushButton->setEnabled(true);

    }

}
