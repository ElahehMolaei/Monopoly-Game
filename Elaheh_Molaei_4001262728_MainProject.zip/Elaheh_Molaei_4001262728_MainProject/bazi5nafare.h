#ifndef BAZI5NAFARE_H
#define BAZI5NAFARE_H

#include <QWidget>

namespace Ui {
class bazi5nafare;
}

class bazi5nafare : public QWidget
{
    Q_OBJECT

public:
    explicit bazi5nafare(QWidget *parent = nullptr);
    ~bazi5nafare();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bazi5nafare *ui;
};

#endif // BAZI5NAFARE_H
